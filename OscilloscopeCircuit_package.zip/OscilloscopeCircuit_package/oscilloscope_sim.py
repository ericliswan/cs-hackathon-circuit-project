"""
oscilloscope_sim.py — the oscilloscope side of OscilloscopeCircuit.blend.

Run via ./launch_oscilloscope.sh, which does
    Blender OscilloscopeCircuit.blend --python toggle_buttons.py --python place_components.py --python oscilloscope_sim.py

What this script does
  * The scope screen shows the picture YOUR AC_Circuit_Solver.plot_voltage draws (file unchanged):
    the wave-gen trace always, plus the CH1 / probe trace when Breadboard_Circuit_Parser reports a
    closed, valid circuit with a measurable probe (netlist.report decides, exactly as before).
    plt.show() is swapped for fig.savefig() only for the duration of that call (matplotlib's Agg
    backend, so no window opens); the PNG is reloaded into the screen's image texture.
  * Horizontal knob  -> x_scale_mult,   CH1 vertical knob -> y_scale_mult   (1-2-5 steps; a plain
    click on the knob = back to x1).  graph_size is the screen's own aspect ratio.
  * Turning a knob: click-DRAG it up/down (mouse or trackpad), two-finger scroll over it, or the mouse
    wheel over it.  The UP/DOWN arrow keys turn the Entry knob from anywhere in the viewport.
  * Wave generator: the softkeys under the screen select Frequency / Amplitude / Phase and the Entry
    knob adjusts the selected one (click = next parameter).  The same values are sliders in the
    N-panel (View3D sidebar > Oscilloscope tab).  Any change re-solves the circuit with your backend.
  * Power button: click toggles the display (screen + readouts + LED).
  * Keys 1 / 2 / 3: overview / board / screen views.
  * place_components.py calls bpy.app.driver_namespace["bbsim_after_change"] after every placement or
    deletion; this script registers that hook so the screen follows the circuit.

Knobs whose effect plot_voltage has no parameter for (CH2 scale, CH1/CH2 position) turn but do nothing.
"""
import math
import os
import sys
import traceback

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty
from bpy_extras import view3d_utils
from mathutils import Vector

import matplotlib
matplotlib.use("Agg")               # headless renderer; must be chosen before the solver's pyplot draws

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
from blender_sim import netlist     # noqa: E402  (backend bridge: report() = your parser + solver)

# ---------------------------------------------------------------------------
# names / constants shared with build_oscilloscope_scene.py
# ---------------------------------------------------------------------------
DISPLAY_IMAGE = "OscilloscopeCircuit_display.png"     # written next to the .blend on every redraw
IMAGE_NAME = "SCOPE_display"                          # bpy.data.images entry used by the screen material
DISPLAY_MATERIAL = "SCOPE_display_mat"
LED_MATERIAL = "SCOPE_power_led"
READOUT = "SCOPE_readout"                             # FONT object on the top bezel
SOFTKEY_TEXT = {"FREQ": "SCOPE_sk_freq", "AMPL": "SCOPE_sk_ampl", "PHASE": "SCOPE_sk_phase"}
TEXT_MAT, TEXT_MAT_HI = "SCOPE_text", "SCOPE_text_hi"      # readout materials (normal / selected softkey)

GRAPH_SIZE = (7.8, 6.0)             # inches -> plot_voltage(graph_size=...); 1.3 = the screen's aspect
DPI = 128
SCALE_STEPS = (0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0)   # 1-2-5 sequence for x_scale_mult / y_scale_mult
UNITY = SCALE_STEPS.index(1.0)
KNOB_STEP_DEG = 30.0
DRAG_PX = 14                        # vertical click-drag pixels per knob step
PAN_PX = 40                         # trackpad two-finger scroll pixels per knob step
KNOBS = {"HORIZ_SCALE": "Horizontal_Knob", "CH1_SCALE": "CH1_Knob", "CH2_SCALE": "CH2_Knob",
         "CH1_POS": "CH1_Pos_Knob", "CH2_POS": "CH2_Pos_Knob", "ENTRY": "Entry_Knob"}
PARAMS = ("FREQ", "AMPL", "PHASE")
FREQ_FACTOR = 1.25                  # Entry knob: frequency steps geometrically, amplitude 0.5 V, phase 5 deg
AMPL_STEP, PHASE_STEP = 0.5, 5.0
VIEWS = {"ONE": ((30.0, -460.0, 360.0), (15.0, 60.0, 55.0)),      # overview (= CAM_main, lens 38)
         "TWO": ((0.0, -215.0, 235.0), (0.0, -12.0, 0.0))}         # board; THREE = screen, computed

_STATE = {"result": None, "warned": set()}


# ---------------------------------------------------------------------------
# your plot, rendered to a file
# ---------------------------------------------------------------------------
def solver():
    """AC_Circuit_Solver as imported by your parser (netlist.load_backend loads both, unchanged)."""
    netlist.load_backend()
    return sys.modules["AC_Circuit_Solver"]


def render_plot(path, amplitude, freq_hz, phase_deg, result, x_mult, y_mult,
                graph_size=GRAPH_SIZE, dpi=DPI):
    """Call YOUR plot_voltage and save what it draws to `path` instead of opening a window.

    Source (mag_s, omega_s, phi_s) always; output (mag_o, omega_o, phi_o) only when `result`
    (netlist.report's dict) says the circuit is closed/valid and the probe measures something.
    """
    acs = solver()
    omega = 2.0 * math.pi * float(freq_hz)
    args = [float(amplitude), omega, math.radians(float(phase_deg))]
    if result and result.get("ok"):
        args += [float(result["amp"]), omega, math.radians(float(result["phase_deg"]))]
    saved_show = acs.plt.show
    acs.plt.show = lambda *a, **k: None            # their function ends with plt.show()
    try:
        acs.plot_voltage(*args, x_scale_mult=x_mult, y_scale_mult=y_mult, graph_size=graph_size)
        fig = acs.plt.gcf()
        fig.savefig(path, dpi=dpi, facecolor=fig.get_facecolor())
    finally:
        acs.plt.show = saved_show
        acs.plt.close("all")
    return path


# ---------------------------------------------------------------------------
# scene access
# ---------------------------------------------------------------------------
def display_path():
    base = os.path.dirname(bpy.data.filepath) if bpy.data.filepath else HERE
    return os.path.join(base, DISPLAY_IMAGE)


def x_mult(scene):
    return SCALE_STEPS[scene.scope_x_step]


def y_mult(scene):
    return SCALE_STEPS[scene.scope_y_step]


def redraw():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def set_text(name, body):
    ob = bpy.data.objects.get(name)
    if ob is not None:
        ob.data.body = body


def fmt_freq(f):
    return f"{f/1000:.3g} kHz" if f >= 1000 else f"{f:.3g} Hz"


def verdict_text(result):
    """CH1 reading when the probe measures something; blank otherwise (the reason goes to the Terminal)."""
    if result and result.get("ok"):
        return f"{result['amp']:.2f} V  ∠ {result['phase_deg']:.0f}°"
    return ""


def update_readouts(scene):
    reading = verdict_text(_STATE["result"])
    set_text(READOUT, f"V ×{y_mult(scene):g}      t ×{x_mult(scene):g}" + (f"          CH1: {reading}" if reading else ""))
    values = {"FREQ": f"Frequency\n{fmt_freq(scene.bbsim_frequency)}",
              "AMPL": f"Amplitude\n{scene.bbsim_amplitude:.3g} V",
              "PHASE": f"Phase\n{scene.bbsim_phase:.3g}°"}
    hi, normal = bpy.data.materials.get(TEXT_MAT_HI), bpy.data.materials.get(TEXT_MAT)
    for key, name in SOFTKEY_TEXT.items():
        ob = bpy.data.objects.get(name)
        if ob is None:
            continue
        ob.data.body = values[key]
        mat = hi if (key == scene.scope_param and hi is not None) else normal
        if mat is not None and ob.data.materials:
            ob.data.materials[0] = mat


def refresh_display(scene, resolve=False):
    """Re-render the screen.  resolve=True runs your parser/solver again first (prints the verdict)."""
    if resolve:
        _STATE["result"] = netlist.report(scene)
    update_readouts(scene)
    if not scene.scope_power:
        return
    img = bpy.data.images.get(IMAGE_NAME)
    if img is None:
        print("[scope] no screen image in this file — build OscilloscopeCircuit.blend first")
        return
    try:
        path = render_plot(display_path(), scene.bbsim_amplitude, scene.bbsim_frequency, scene.bbsim_phase,
                           _STATE["result"], x_mult(scene), y_mult(scene))
        img.filepath = path
        img.reload()
    except Exception:
        traceback.print_exc()
    redraw()


def _emission(material_name, strength):
    mat = bpy.data.materials.get(material_name)
    if mat is not None and mat.use_nodes:
        node = mat.node_tree.nodes.get("Principled BSDF")
        if node is not None:
            node.inputs["Emission Strength"].default_value = strength


def set_power(scene, on):
    scene.scope_power = bool(on)
    for name in (READOUT, *SOFTKEY_TEXT.values()):
        ob = bpy.data.objects.get(name)
        if ob is not None:
            ob.hide_set(not on)
    _emission(LED_MATERIAL, 2.0 if on else 0.0)
    print("[scope] power", "ON" if on else "OFF")
    if on:
        refresh_display(scene)
        steps = iter([0.15, 0.35, 0.6, 0.85, 1.0])          # short glow ramp

        def ramp():
            try:
                _emission(DISPLAY_MATERIAL, next(steps))
                redraw()
                return 0.05
            except StopIteration:
                return None
        bpy.app.timers.register(ramp, first_interval=0.0)
    else:
        _emission(DISPLAY_MATERIAL, 0.0)
        redraw()


def on_circuit_changed(scene, result):
    """Hook called by place_components.py after every placement / deletion."""
    _STATE["result"] = result
    refresh_display(scene)


# ---------------------------------------------------------------------------
# knobs / buttons
# ---------------------------------------------------------------------------
def turn_knob(fn, steps):
    ob = bpy.data.objects.get(KNOBS.get(fn, ""))
    if ob is not None:
        ob.rotation_euler.rotate_axis('Z', math.radians(KNOB_STEP_DEG * steps))   # local Z = knob axis


def _step(scene, prop, direction):
    """Move a 1-2-5 index by `direction`, returns how many steps actually moved."""
    old = getattr(scene, prop)
    new = max(0, min(len(SCALE_STEPS) - 1, old + direction))
    setattr(scene, prop, new)
    return new - old


def adjust_param(scene, key, direction):
    if key == "FREQ":
        f = scene.bbsim_frequency * (FREQ_FACTOR ** direction)
        scene.bbsim_frequency = float(f"{max(1.0, min(1e5, f)):.3g}")
    elif key == "AMPL":
        scene.bbsim_amplitude = max(0.5, min(50.0, scene.bbsim_amplitude + AMPL_STEP * direction))
    else:
        p = scene.bbsim_phase + PHASE_STEP * direction
        scene.bbsim_phase = (p + 180.0) % 360.0 - 180.0


def scroll(scene, fn, direction):
    if fn == "HORIZ_SCALE":
        moved = _step(scene, "scope_x_step", direction)
        turn_knob(fn, moved)
        if moved:
            print(f"[scope] horizontal  x_scale_mult = {x_mult(scene):g}")
            refresh_display(scene)
    elif fn == "CH1_SCALE":
        moved = _step(scene, "scope_y_step", direction)
        turn_knob(fn, moved)
        if moved:
            print(f"[scope] CH1 vertical  y_scale_mult = {y_mult(scene):g}")
            refresh_display(scene)
    elif fn == "ENTRY":
        turn_knob(fn, direction)
        adjust_param(scene, scene.scope_param, direction)      # the property update re-solves + redraws
    elif fn in KNOBS:                                           # CH2 scale, CH1/CH2 position
        turn_knob(fn, direction)
        if fn not in _STATE["warned"]:
            _STATE["warned"].add(fn)
            print(f"[scope] {fn}: plot_voltage has no parameter for this knob — it turns but does nothing")


def click(scene, fn):
    if fn == "POWER":
        set_power(scene, not scene.scope_power)
    elif fn.startswith("SOFT_"):
        scene.scope_param = fn[5:]
        update_readouts(scene)
        print("[scope] Entry knob now adjusts", scene.scope_param)
    elif fn == "ENTRY":                                         # push to select: next parameter
        scene.scope_param = PARAMS[(PARAMS.index(scene.scope_param) + 1) % len(PARAMS)]
        update_readouts(scene)
        print("[scope] Entry knob now adjusts", scene.scope_param)
    elif fn in ("HORIZ_SCALE", "CH1_SCALE"):                    # push = back to x1
        prop = "scope_x_step" if fn == "HORIZ_SCALE" else "scope_y_step"
        moved = UNITY - getattr(scene, prop)
        setattr(scene, prop, UNITY)
        turn_knob(fn, moved)
        print(f"[scope] {fn} reset to x1")
        refresh_display(scene)


def fn_under_mouse(context, event):
    """Raycast the mouse; climb parents until an object carrying `fn` is found."""
    region, rv3d = context.region, context.region_data
    if rv3d is None:
        return None
    coord = (event.mouse_region_x, event.mouse_region_y)
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    hit, _, _, _, obj, _ = context.scene.ray_cast(context.evaluated_depsgraph_get(), origin, direction)
    while hit and obj is not None:
        if "fn" in obj:
            return obj["fn"]
        obj = obj.parent
    return None


def set_view(context, eye, target):
    rv3d = context.region_data
    eye, target = Vector(eye), Vector(target)
    rv3d.view_perspective = 'PERSP'
    rv3d.view_location = target
    rv3d.view_distance = (eye - target).length
    rv3d.view_rotation = (eye - target).to_track_quat('Z', 'Y')


def screen_view():
    ob = bpy.data.objects.get("SCOPE_display")
    if ob is None:
        return VIEWS["ONE"]
    pts = [ob.matrix_world @ Vector(c) for c in ob.bound_box]
    centre = sum(pts, Vector()) / len(pts)
    return (centre + Vector((0.0, -1.0, 0.35)).normalized() * 230.0, centre)


# ---------------------------------------------------------------------------
# operators / panel / properties
# ---------------------------------------------------------------------------
def _safe(func, *args):
    """Run a control action; an exception is printed, never allowed to kill the modal."""
    try:
        func(*args)
    except Exception:
        traceback.print_exc()


def _apply_steps(scene, fn, acc, px):
    """Turn accumulated pixels into knob steps.  Returns (pixels left over, stepped?)."""
    stepped = False
    while acc >= px:
        _safe(scroll, scene, fn, +1)
        acc -= px
        stepped = True
    while acc <= -px:
        _safe(scroll, scene, fn, -1)
        acc += px
        stepped = True
    return acc, stepped


class VIEW3D_OT_oscilloscope(bpy.types.Operator):
    """Knobs (drag / scroll / click), softkeys, power button, arrow keys and the 1/2/3 view keys."""
    bl_idname = "view3d.oscilloscope"
    bl_label = "Oscilloscope controls"

    _drag = None            # {"fn", "y", "acc", "moved"} while a knob is held with the left button
    _pan = 0.0              # accumulated trackpad scroll over a knob

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Run from the 3D Viewport")
            return {'CANCELLED'}
        context.window_manager.modal_handler_add(self)
        print("[scope] running — DRAG a knob up/down (or scroll over it): Horizontal = t scale, CH1 = V scale, "
              "Entry = selected wave-gen value (softkeys pick Frequency / Amplitude / Phase; UP/DOWN keys also "
              "turn Entry). Click a knob = reset / next. Power button. Keys 1/2/3 = overview / board / screen. "
              "N-panel > Oscilloscope has sliders too.")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        scene = context.scene
        if self._drag is not None:                                    # a knob is being turned by dragging
            d = self._drag
            if event.type == 'MOUSEMOVE':
                d["acc"] += event.mouse_region_y - d["y"]
                d["y"] = event.mouse_region_y
                d["acc"], stepped = _apply_steps(scene, d["fn"], d["acc"], DRAG_PX)
                d["moved"] = d["moved"] or stepped
            elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
                if not d["moved"]:
                    _safe(click, scene, d["fn"])                      # plain click = push the knob
                self._drag = None
            elif event.type == 'ESC':
                self._drag = None
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'TRACKPADPAN':                               # two-finger scroll over a knob
            fn = fn_under_mouse(context, event)
            if fn in KNOBS:
                self._pan += event.mouse_y - event.mouse_prev_y
                self._pan, _ = _apply_steps(scene, fn, self._pan, PAN_PX)
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}
            self._pan = 0.0
            return {'PASS_THROUGH'}

        if event.value != 'PRESS':
            return {'PASS_THROUGH'}
        if event.type in ('UP_ARROW', 'DOWN_ARROW'):
            _safe(scroll, scene, "ENTRY", 1 if event.type == 'UP_ARROW' else -1)
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type in ('ONE', 'TWO', 'THREE') and context.region_data is not None:
            eye, target = screen_view() if event.type == 'THREE' else VIEWS[event.type]
            set_view(context, eye, target)
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type in ('LEFTMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'):
            fn = fn_under_mouse(context, event)
            if fn is None:
                return {'PASS_THROUGH'}                               # holes / buttons / navigation as usual
            if event.type == 'LEFTMOUSE':
                if fn in KNOBS:
                    self._drag = {"fn": fn, "y": event.mouse_region_y, "acc": 0.0, "moved": False}
                else:
                    _safe(click, scene, fn)                           # power button, softkeys
            else:
                _safe(scroll, scene, fn, 1 if event.type == 'WHEELUPMOUSE' else -1)
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}


class VIEW3D_OT_scope_power(bpy.types.Operator):
    bl_idname = "view3d.scope_power"
    bl_label = "Power"

    def execute(self, context):
        set_power(context.scene, not context.scene.scope_power)
        return {'FINISHED'}


class VIEW3D_OT_scope_redraw(bpy.types.Operator):
    bl_idname = "view3d.scope_redraw"
    bl_label = "Re-solve and redraw"

    def execute(self, context):
        refresh_display(context.scene, resolve=True)
        return {'FINISHED'}


class VIEW3D_PT_oscilloscope(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Oscilloscope"
    bl_label = "Oscilloscope"

    def draw(self, context):
        s = context.scene
        col = self.layout.column(align=True)
        col.operator("view3d.scope_power", text="Power: ON" if s.scope_power else "Power: OFF", depress=s.scope_power)
        col.separator()
        col.label(text="Wave generator")
        col.prop(s, "bbsim_amplitude")
        col.prop(s, "bbsim_frequency")
        col.prop(s, "bbsim_phase")
        col.prop(s, "scope_param")
        col.separator()
        col.label(text=f"Horizontal  x_scale_mult = {x_mult(s):g}")
        col.label(text=f"CH1 vertical  y_scale_mult = {y_mult(s):g}")
        col.label(text=f"CH1: {verdict_text(_STATE['result']) or '—'}")
        col.operator("view3d.scope_redraw")


def _on_source_changed(self, _context):
    refresh_display(self, resolve=True)


def _on_param_changed(self, _context):
    update_readouts(self)
    redraw()


PROPS = {
    "bbsim_amplitude": FloatProperty(name="Amplitude (V)", default=12.0, min=0.5, max=50.0, update=_on_source_changed),
    "bbsim_frequency": FloatProperty(name="Frequency (Hz)", default=50.0, min=1.0, max=1e5, update=_on_source_changed),
    "bbsim_phase": FloatProperty(name="Phase (deg)", default=0.0, min=-180.0, max=180.0, update=_on_source_changed),
    "scope_power": BoolProperty(name="Power", default=True),
    "scope_x_step": IntProperty(name="x step", default=UNITY, min=0, max=len(SCALE_STEPS) - 1),
    "scope_y_step": IntProperty(name="y step", default=UNITY, min=0, max=len(SCALE_STEPS) - 1),
    "scope_param": EnumProperty(name="Entry knob", default="FREQ", update=_on_param_changed,
                                items=[("FREQ", "Frequency", ""), ("AMPL", "Amplitude", ""), ("PHASE", "Phase", "")]),
}
CLASSES = (VIEW3D_OT_oscilloscope, VIEW3D_OT_scope_power, VIEW3D_OT_scope_redraw, VIEW3D_PT_oscilloscope)


def register():
    for cls in CLASSES:
        if hasattr(bpy.types, cls.__name__):
            bpy.utils.unregister_class(getattr(bpy.types, cls.__name__))
        bpy.utils.register_class(cls)
    for name, prop in PROPS.items():
        setattr(bpy.types.Scene, name, prop)
    bpy.app.driver_namespace["bbsim_after_change"] = on_circuit_changed


def start_handler():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                region = next(r for r in area.regions if r.type == 'WINDOW')
                area.spaces.active.show_region_ui = True
                with bpy.context.temp_override(window=window, area=area, region=region):
                    bpy.ops.view3d.oscilloscope('INVOKE_DEFAULT')
                scene = bpy.context.scene
                scene.scope_x_step = scene.scope_y_step = UNITY
                _STATE["result"] = netlist.report(scene)
                set_power(scene, True)
                return None
    return 0.5


def selftest():
    """Headless: render both plot variants through render_plot and check the files."""
    import tempfile
    out = os.path.join(tempfile.gettempdir(), "scope_selftest")
    render_plot(out + "_single.png", 12.0, 50.0, 0.0, None, 1.0, 1.0)
    render_plot(out + "_both.png", 12.0, 50.0, 30.0, {"ok": True, "amp": 8.0, "phase_deg": -20.0}, 2.0, 0.5)
    for suffix in ("_single.png", "_both.png"):
        with open(out + suffix, "rb") as fh:
            assert fh.read(8) == b"\x89PNG\r\n\x1a\n", suffix
    print("[scope] SELFTEST PASS —", out + "_*.png")


if __name__ == "__main__":
    register()
    if bpy.app.background:
        selftest()
    else:
        bpy.app.timers.register(start_handler, first_interval=0.5)   # after the other two scripts
