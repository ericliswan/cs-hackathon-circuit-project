# OscilloscopeCircuit — final product package

Self-contained folder: breadboard + your buttons.blend selector + oscilloscope, with the frozen
Python backend. Nothing here depends on files outside this folder.

## Run
    ./launch_oscilloscope.sh              # opens OscilloscopeCircuit.blend with all three scripts
    ./launch_oscilloscope.sh --build      # rebuild OscilloscopeCircuit.blend from the sources first

Needs Blender at /Applications/Blender.app (or `BLENDER=/path/to/Blender ./launch_oscilloscope.sh`).
Run it from a Terminal: print() output (component list, solver verdict) appears there.
Optional: matplotlib inside Blender's Python for the real scope plot
(`<Blender>/Contents/Resources/<ver>/python/bin/python3.x -m pip install matplotlib`).

## What is what
| File | Role |
|---|---|
| `OscilloscopeCircuit.blend` | the final scene (open this) |
| `launch_oscilloscope.sh` | launcher: runs the three runtime scripts in one Blender session |
| `toggle_buttons.py` | buttons: click = arm, writes `scene.armed_component` |
| `place_components.py` | hover ring, click hole A, click hole B -> part created, list printed, solved |
| `oscilloscope_sim.py` | scope screen = `AC_Circuit_Solver.plot_voltage` PNG; knobs, wave gen, power |
| `blender_sim/` | package: hole layout, meshes, netlist walk, solver bridge |
| `AC_Circuit_Solver.py`, `Breadboard_Circuit_Parser.py` | backend (unmodified) |
| `breadboard_holes.json` | hole coordinates (world mm) |
| `build_oscilloscope_scene.py`, `swap_selector.py`, `build_scene.py`, `launch_blender.sh` | rebuild chain: `build_scene.py` -> `swap_selector.py` -> `build_oscilloscope_scene.py` |
| `breadboard_sim.blend`, `oscilloscope.blend`, `buttons.blend` | rebuild sources (read-only) |
| `docs/` | specs, Blender setup notes, preview renders |
| `tests/` | `python3 tests/test_board_layout.py` etc.; `*_headless.py` run inside `Blender -b` |
