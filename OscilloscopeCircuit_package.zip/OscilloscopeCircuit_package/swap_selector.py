"""
swap_selector.py — put YOUR component selector (buttons.blend) into breadboard_sim.blend.

    "/Applications/Blender.app/Contents/MacOS/Blender" -b breadboard_sim.blend --python swap_selector.py
    (or:  ./launch_blender.sh --build   which rebuilds the board first, then runs this)

buttons.blend is only READ (bpy.data.libraries.load) — it is never written to.

What it does to breadboard_sim.blend:
  1. deletes the whole phase-1 console: the tilted slab PANEL_modes, its PANEL_base wedge, the
     12 BTN_* buttons, their labels and the "COMPONENTS" title — and any PANEL_user from an
     earlier run of this script, so it can be re-run safely.
  2. appends every object from buttons.blend (8 buttons carrying `arms`, their text
     labels, the plate and the four border bars).
  3. parents them to ONE new Empty, PANEL_user, lying FLAT on the bench beside the board,
     scaled x4.6 (buttons.blend is 15 x 13 units -> 69 x 60 mm).  The objects keep the
     coordinates they have in buttons.blend; the Empty supplies position and scale only.
  4. resets the "pressed" state that was saved in buttons.blend so every button starts up.
  5. drops the stale start_sim.py text block (old session) and rewrites the README block.
  6. saves breadboard_sim.blend (Blender keeps the previous version as breadboard_sim.blend1).
"""
import os
import bpy
from mathutils import Matrix

HERE = os.path.dirname(os.path.abspath(__file__))
BUTTONS_BLEND = os.path.join(HERE, "buttons.blend")

SCALE = 4.6                 # 15 x 13 units -> 69 x 59.8 mm (about the old console's footprint)
PANEL_X = 75.6              # centre of the panel, mm: where the old console stood (board edge is x = 27.6)
PLATE_CENTRE_X = 1.5        # the plate in buttons.blend is centred on x = 1.5, not 0
LIFT = 0.02                 # plate sits 0.02 units (0.09 mm) above the bench: no z-fighting
BUTTON_REST_Z = 0.2         # every button's "up" z in buttons.blend (pressed = 0.2 - 0.08)
OLD_CONSOLE = ("PANEL_modes", "PANEL_base", "PANEL_user")


def bench_top_z():
    """Top surface of BENCH_top (-11.5 mm in the phase-1 scene), read from the mesh."""
    bench = bpy.data.objects.get("BENCH_top")
    if bench is None:
        return -11.5
    return max((bench.matrix_world @ v.co).z for v in bench.data.vertices)


def main():
    ui = bpy.data.collections["SIM_UI"]

    # 1. old console out: slab, wedge, BTN_* + labels, and any previous PANEL_user + its children
    old = [o for o in bpy.data.objects if o.name in OLD_CONSOLE]
    old += [c for o in old for c in o.children_recursive]
    for ob in reversed(old):
        bpy.data.objects.remove(ob, do_unlink=True)
    bpy.data.orphans_purge(do_recursive=True)          # their meshes / materials
    print(f"[swap] removed {len(old)} old console objects")

    # 2. your selector in — libraries.load only reads buttons.blend
    with bpy.data.libraries.load(BUTTONS_BLEND, link=False) as (src, dst):
        dst.objects = src.objects
    new = [o for o in dst.objects if o is not None]
    for ob in new:
        ui.objects.link(ob)
    print(f"[swap] appended {len(new)} objects from buttons.blend:", sorted(o.name for o in new))

    # 3. one Empty carries position / scale: flat on the bench, no rotation
    holder = bpy.data.objects.new("PANEL_user", None)
    ui.objects.link(holder)
    holder.matrix_world = (Matrix.Translation((PANEL_X, 0.0, bench_top_z()))
                           @ Matrix.Scale(SCALE, 4)
                           @ Matrix.Translation((-PLATE_CENTRE_X, 0.0, LIFT)))
    for ob in new:
        if ob.parent is None:                         # buttons, plate, bars (labels stay on their button)
            ob.parent = holder                        # parent-inverse stays identity -> coords become holder-local

    # 4. every button up, nothing pressed
    for ob in new:
        if "arms" in ob:
            ob["pressed"] = False
            ob.location.z = BUTTON_REST_Z

    # 5. text blocks
    stale = bpy.data.texts.get("start_sim.py")
    if stale is not None:
        bpy.data.texts.remove(stale)
    readme = bpy.data.texts.get("README") or bpy.data.texts.new("README")
    readme.clear()
    readme.write("Breadboard Circuit Simulator\n\n"
                 "Component selector = the buttons from buttons.blend (appended by swap_selector.py).\n"
                 "Launch from the Terminal with ./launch_blender.sh, which runs\n"
                 "toggle_buttons.py (arms a button -> scene.armed_component) and then\n"
                 "place_components.py (hover ring, click hole A, click hole B -> part created,\n"
                 "component list + solver result printed in the Terminal).\n")

    # 6. save in place
    bpy.ops.wm.save_mainfile()
    print(f"[swap] saved {bpy.data.filepath}")


if __name__ == "__main__":
    main()
