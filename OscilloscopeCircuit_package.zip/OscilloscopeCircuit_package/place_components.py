"""
place_components.py — hover + two-click component creation for breadboard_sim.blend,
driven by YOUR selector (toggle_buttons.py + the buttons from buttons.blend).

Run via ./launch_blender.sh, which does
    Blender breadboard_sim.blend --python toggle_buttons.py --python place_components.py

toggle_buttons.py owns the buttons: a click arms one (green, sunk) and writes its key to
bpy.context.scene.armed_component.  This script only READS that property — that is the whole
handshake, nothing is imported between the two files.

Behaviour
    mouse move   cyan ring snaps to the nearest hole
    1st click    orange ring marks hole A — nothing else happens (no rubber band, no HUD)
    2nd click    the armed component is created between A and B, the component list is
                 printed in Breadboard_Circuit_Parser's raw format and the circuit is solved
    Esc / RMB    forget hole A          X    delete the last placed component
    Esc again    (nothing pending) stops this script AND toggle_buttons.py

Clicks on the buttons are passed through untouched so toggle_buttons.py handles them.
The meshes, the netlist walk and the solver bridge come from the frozen blender_sim package
(component_meshes.spawn_component, netlist.print_components / report).
"""
import os
import sys
import traceback

import bpy
from bpy_extras import view3d_utils
from mathutils import Vector
from mathutils.geometry import intersect_line_plane

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
from blender_sim import component_meshes, netlist            # noqa: E402
from blender_sim.board_layout import BOARD_TOP_Z, net_repr   # noqa: E402

ARMED_PROP = "armed_component"            # written by toggle_buttons.py
MARKER_HOVER, MARKER_A = "UI_marker_hover", "UI_marker_a"   # ring objects already in the .blend
HIDDEN_Z = -50.0                          # where a hidden ring is parked (same as scene_builder)
PLACEABLE = {k for k, v in component_meshes.COMPONENT_INFO.items() if v["kind"] != "DELETE"}

LAYOUT = netlist.get_layout(bpy.context.scene)   # hole table rebuilt from BOARD_breadboard's props


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------
def armed():
    """Key of the button toggle_buttons.py currently has armed ('' = none)."""
    return bpy.context.scene.get(ARMED_PROP, "")


def show_marker(name, hole, lift):
    ring = bpy.data.objects[name]
    ring.location = (hole.x, hole.y, hole.z + lift)
    ring.hide_set(False)


def hide_marker(name):
    ring = bpy.data.objects[name]
    ring.location = (0.0, 0.0, HIDDEN_Z)
    ring.hide_set(True)


def mouse_ray(context, event):
    region, rv3d = context.region, context.region_data
    coord = (event.mouse_region_x, event.mouse_region_y)
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    return origin, direction


def hole_under_mouse(context, event):
    """Intersect the mouse ray with the board plane and snap to the nearest hole (or None)."""
    if context.region_data is None:
        return None
    origin, direction = mouse_ray(context, event)
    hit = intersect_line_plane(origin, origin + direction * 1e5,
                               Vector((0.0, 0.0, BOARD_TOP_Z)), Vector((0.0, 0.0, 1.0)))
    return LAYOUT.nearest(hit.x, hit.y) if hit is not None else None


def on_button(context, event):
    """True when the click lands on one of your buttons (object or label carrying `arms`)."""
    if context.region_data is None:
        return False
    origin, direction = mouse_ray(context, event)
    hit, _, _, _, obj, _ = context.scene.ray_cast(context.evaluated_depsgraph_get(), origin, direction)
    while hit and obj is not None:
        if "arms" in obj:
            return True
        obj = obj.parent
    return False


# ---------------------------------------------------------------------------
# create / delete  (print the list + run the solver after every change)
# ---------------------------------------------------------------------------
def create(scene, comp_type, a, b):
    if comp_type == "PROBE":                       # one probe at a time, like the full simulator
        for ob in netlist.placed_objects(scene):
            if ob.get("sim_role") == "PROBE":
                print("[place] replaced", ob.name)
                component_meshes.remove_component(ob)
    obj = component_meshes.spawn_component(scene, comp_type, a, b, netlist.next_uid(scene))
    print(f"[place] created {obj.name}: {net_repr(a.net)} -> {net_repr(b.net)}")
    netlist.print_components(scene)                # components = [ ... ]  in the backend's format
    notify(scene, netlist.report(scene))           # [BBSIM] circuit: ... | Vout = ...
    return obj


def delete_last(scene):
    placed = netlist.placed_objects(scene)         # sorted by uid -> last one = most recent
    if not placed:
        print("[place] nothing to delete")
        return
    name = placed[-1].name
    component_meshes.remove_component(placed[-1])
    print("[place] deleted", name)
    netlist.print_components(scene)
    notify(scene, netlist.report(scene))


def notify(scene, result):
    """Optional hook: oscilloscope_sim.py stores a callback here to redraw the scope screen."""
    callback = bpy.app.driver_namespace.get("bbsim_after_change")
    if callback is not None:
        callback(scene, result)


# ---------------------------------------------------------------------------
# the modal operator
# ---------------------------------------------------------------------------
class VIEW3D_OT_place_components(bpy.types.Operator):
    """Hover ring; click hole A, click hole B -> the armed component is created."""
    bl_idname = "view3d.place_components"
    bl_label = "Breadboard: place components"

    _hover = None          # key of the hole under the cursor
    _a = None              # Hole held as endpoint A, or None

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Run from the 3D Viewport")
            return {'CANCELLED'}
        context.window_manager.modal_handler_add(self)
        print("[place] running — arm a button, click hole A, then hole B.  Esc/RMB clears A, X deletes the last part")
        return {'RUNNING_MODAL'}

    def clear_a(self):
        self._a = None
        hide_marker(MARKER_A)

    def click_hole(self, scene, hole):
        key = armed()
        if key not in PLACEABLE:
            print("[place] nothing armed — click a component button first")
            return
        if self._a is None:                                     # first click: just remember A
            self._a = hole
            show_marker(MARKER_A, hole, 0.15)
            print(f"[place] {key}: hole A = {net_repr(hole.net)} — now click hole B")
            return
        if hole.key == self._a.key or (hole.is_rail and self._a.is_rail and hole.net == self._a.net):
            print("[place] same hole / same rail as A — pick a different hole for B")
            return
        try:                                                    # second click: create
            create(scene, key, self._a, hole)
        except Exception:
            traceback.print_exc()
        self.clear_a()

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            hole = hole_under_mouse(context, event)
            hover_key = hole.key if hole is not None else None
            if hover_key != self._hover:                        # move the ring only when the hole changes
                self._hover = hover_key
                if hole is None:
                    hide_marker(MARKER_HOVER)
                else:
                    show_marker(MARKER_HOVER, hole, 0.1)
                context.area.tag_redraw()
            return {'PASS_THROUGH'}

        if event.value != 'PRESS':
            return {'PASS_THROUGH'}

        if event.type in {'ESC', 'RIGHTMOUSE'}:
            if self._a is not None:
                print("[place] cleared hole A")
                self.clear_a()
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}
            if event.type == 'ESC':                             # nothing pending: stop (and let
                hide_marker(MARKER_HOVER)                       # toggle_buttons.py see the Esc too)
                print("[place] stopped")
                return {'CANCELLED', 'PASS_THROUGH'}
            return {'PASS_THROUGH'}

        if event.type == 'X':
            try:
                delete_last(context.scene)
            except Exception:
                traceback.print_exc()
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE':
            if on_button(context, event):
                return {'PASS_THROUGH'}                         # toggle_buttons.py arms it
            hole = hole_under_mouse(context, event)
            if hole is None:
                return {'PASS_THROUGH'}                         # empty bench: normal Blender click
            self.click_hole(context.scene, hole)
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}                            # consume: no object selection

        return {'PASS_THROUGH'}                                 # orbit / zoom / everything else


def register():
    if hasattr(bpy.types, "VIEW3D_OT_place_components"):
        bpy.utils.unregister_class(bpy.types.VIEW3D_OT_place_components)
    bpy.utils.register_class(VIEW3D_OT_place_components)


def start_handler():
    """Timer callback: start the modal once a 3D Viewport exists (needs a viewport context)."""
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                region = next(r for r in area.regions if r.type == 'WINDOW')
                space = area.spaces.active
                space.shading.type = 'MATERIAL'
                if bpy.context.scene.camera is not None:
                    space.region_3d.view_perspective = 'CAMERA'     # frame the bench like before
                with bpy.context.temp_override(window=window, area=area, region=region):
                    bpy.ops.view3d.place_components('INVOKE_DEFAULT')
                return None
    return 0.5


def selftest():
    """Headless check: create a circuit through the same code path, print, solve, clean up."""
    scene = bpy.context.scene
    hole = LAYOUT.hole
    made = [create(scene, "WIRE", LAYOUT.rail_holes("VCC", "L")[0], hole("1b")),
            create(scene, "RESISTOR1", hole("1c"), hole("5c")),
            create(scene, "RESISTOR2", hole("5d"), hole("9d")),
            create(scene, "WIRE", hole("9b"), LAYOUT.rail_holes("GND", "L")[0]),
            create(scene, "PROBE", hole("5a"), LAYOUT.rail_holes("GND", "R")[0])]
    result = netlist.report(scene)
    assert result["ok"] and abs(result["amp"] - 8.0) < 1e-6, result
    for _ in made:
        delete_last(scene)
    assert not netlist.placed_objects(scene)
    print("[place] SELFTEST PASS")


if __name__ == "__main__":
    register()
    hide_marker(MARKER_HOVER)
    hide_marker(MARKER_A)
    if bpy.app.background:
        selftest()
    else:
        bpy.app.timers.register(start_handler, first_interval=0.3)   # after toggle_buttons.py's 0.1 s
