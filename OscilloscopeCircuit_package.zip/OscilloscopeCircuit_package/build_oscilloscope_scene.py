"""
build_oscilloscope_scene.py — assemble OscilloscopeCircuit.blend (headless, run once).

    "/Applications/Blender.app/Contents/MacOS/Blender" -b breadboard_sim.blend --python build_oscilloscope_scene.py
    (or:  ./launch_oscilloscope.sh --build)

Starts from breadboard_sim.blend (board + your buttons.blend selector, unchanged) and adds
  1. the parts of oscilloscope.blend (opened read-only) that matter — chassis, screen, softkeys,
     the functional knobs with their labels, the BNC row, the power button (KEEP_EXACT / KEEP_PREFIX;
     the decorative buttons, pins and labels are left out) — under the Empty SCOPE_root: x8, turned to
     face the camera, standing on the bench behind the board, chassis shortened by SHORTEN
  2. SCOPE_display: a UV-mapped plane filling the bezel opening, whose emissive image texture is the
     PNG oscilloscope_sim.py renders with YOUR AC_Circuit_Solver.plot_voltage
  3. readout text on the bezels (top: V / t multipliers + CH1 verdict; bottom: wave-gen softkey menu)
  4. `fn` custom properties on the functional controls and a pointer mark on every functional knob
  5. the two fixed leads: Gen Out BNC -> carrier binding posts (red VCC / black GND) and
     CH1 BNC -> the probe pick-up point on a small holder (the probe's own cable ends there)
  6. a wider camera framing bench, board, selector and scope

Saves OscilloscopeCircuit.blend next to this file.  breadboard_sim.blend and oscilloscope.blend
are never written.
"""
import math
import os
import sys

import bmesh
import bpy
from mathutils import Matrix, Vector

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
from blender_sim.bpy_utils import bezier, bm_box, bm_cylinder, bm_tube, finish_bmesh, get_collection, mesh_from_bmesh, new_object, set_props  # noqa: E402
from blender_sim.materials import get_material, palette_material   # noqa: E402
from blender_sim.component_meshes import PROBE_CABLE_END            # noqa: E402
import oscilloscope_sim as osim                                       # noqa: E402  (render_plot + names)

SCOPE_BLEND = os.path.join(HERE, "oscilloscope.blend")
OUT_BLEND = os.path.join(HERE, "OscilloscopeCircuit.blend")

# Only these parts of oscilloscope.blend are used — the decorative buttons, knobs, labels, the
# digital-pin bank, USB, probe-comp terminals etc. are left out for a clean, uncluttered front.
KEEP_EXACT = {
    "Body", "Screen", "BNC_Panel",
    "Power_Alcove", "Power_Button", "Power_Line", "Power_Ring",
    "Horizontal_Knob", "Label_Horizontal_-2.80_23.00", "Label_Push for Fine_-2.10_20.45",
    "Entry_Knob", "Entry_Icon", "Label_Push to Select_-2.20_13.65",
    "Label_Vertical_-6.95_9.60", "Label_Push for Fine_-6.95_9.25", "Label_Push to Zero_-6.95_5.10",
    "Label_1_-5.40_6.50", "Label_2_-8.50_6.50", "Label_1_-6.00_4.30", "Label_2_-9.10_4.30",
    "Label_X_-6.00_3.98", "Label_Y_-9.10_3.98", "Label_Gen Out_6.80_2.30",
}
KEEP_PREFIX = ("Foot", "FootGroove", "Bezel_", "Softkey_", "CH1_", "CH2_", "FuncGen_", "Vent_")
SHORTEN = 3.7                                        # model units taken off the top of the chassis (22 -> 18.3)
HORIZONTAL_Z = {"Horizontal_Knob": 16.4,             # the Horizontal knob moves down into the freed space
                "Label_Horizontal_-2.80_23.00": 17.95, "Label_Push for Fine_-2.10_20.45": 15.1}

SCOPE_SCALE = 8.0                                    # model unit -> mm (chassis 34 units -> 272 mm wide)
SCOPE_CENTRE = (30.0, 185.0)                         # world x, y of the chassis centre
SCREEN = dict(x0=-0.3, x1=14.7, z0=6.2, z1=17.7, y=6.87)   # bezel opening, model units (front face y=6.86)
BEZEL_FRONT_Y = 7.01
FN = {"Horizontal_Knob": "HORIZ_SCALE", "CH1_Knob": "CH1_SCALE", "CH2_Knob": "CH2_SCALE",
      "CH1_Pos_Knob": "CH1_POS", "CH2_Pos_Knob": "CH2_POS", "Entry_Knob": "ENTRY",
      "Power_Button": "POWER", "Power_Ring": "POWER", "Power_Line": "POWER", "Power_Alcove": "POWER",
      # model +X is the viewer's LEFT, so Softkey_5 (x=13.45) is the leftmost key under the screen
      "Softkey_4": "SOFT_FREQ", "Softkey_3": "SOFT_AMPL", "Softkey_2": "SOFT_PHASE"}
SOFTKEY_X = {"SCOPE_sk_wave": 13.45, osim.SOFTKEY_TEXT["FREQ"]: 10.95,
             osim.SOFTKEY_TEXT["AMPL"]: 8.45, osim.SOFTKEY_TEXT["PHASE"]: 5.95}
CAMERA = dict(eye=osim.VIEWS["ONE"][0], target=osim.VIEWS["ONE"][1], lens=38.0)


def bench_top_z():
    bench = bpy.data.objects["BENCH_top"]
    return max((bench.matrix_world @ v.co).z for v in bench.data.vertices)


def world_top(name):
    """(centre x, centre y, max z) of an object's world bounding box."""
    ob = bpy.data.objects[name]
    pts = [ob.matrix_world @ Vector(c) for c in ob.bound_box]
    return Vector((sum(p.x for p in pts) / 8, sum(p.y for p in pts) / 8, max(p.z for p in pts)))


# ---------------------------------------------------------------------------
def keep(name):
    return name in KEEP_EXACT or name.startswith(KEEP_PREFIX)


def tidy_chassis():
    """Shorten the chassis from the top and move the Horizontal knob + labels down with it."""
    body = bpy.data.objects["Body"]
    for v in body.data.vertices:                     # origin is at mid-height: z > 0 is the upper half
        if v.co.z > 0.0:
            v.co.z -= SHORTEN
    body.location.z -= SHORTEN / 2.0                 # keep the mesh's local origin in the middle
    for v in body.data.vertices:
        v.co.z += SHORTEN / 2.0
    for ob in bpy.data.objects:
        if ob.name.startswith("Vent_"):
            ob.location.z -= SHORTEN
    for name, z in HORIZONTAL_Z.items():
        bpy.data.objects[name].location.z = z


def append_scope(scene):
    with bpy.data.libraries.load(SCOPE_BLEND, link=False) as (src, dst):
        dst.objects = [n for n in src.objects if keep(n)]
    objs = [o for o in dst.objects if o is not None]
    coll = get_collection("SIM_Scope", parent=scene.collection)
    for ob in objs:
        coll.objects.link(ob)
    root = bpy.data.objects.new("SCOPE_root", None)
    coll.objects.link(root)
    cx, cy = SCOPE_CENTRE
    root.matrix_world = (Matrix.Translation((cx, cy, bench_top_z()))
                         @ Matrix.Rotation(math.pi, 4, 'Z')          # model front is +Y; camera is at -Y
                         @ Matrix.Scale(SCOPE_SCALE, 4))
    for ob in objs:
        if ob.parent is None:
            ob.parent = root                                          # coords stay model-local
    for name, fn in FN.items():
        set_props(bpy.data.objects[name], fn=fn)
    tidy_chassis()
    print(f"[build] appended {len(objs)} oscilloscope objects under SCOPE_root (chassis shortened by {SHORTEN})")
    return coll, root


def build_display(coll, root):
    """UV-mapped quad in the bezel opening; image texture = the plot PNG, emissive."""
    x0, x1, z0, z1, y = SCREEN["x0"], SCREEN["x1"], SCREEN["z0"], SCREEN["z1"], SCREEN["y"]
    bm = bmesh.new()
    verts = [bm.verts.new(p) for p in ((x0, y, z0), (x0, y, z1), (x1, y, z1), (x1, y, z0))]   # normal +Y
    face = bm.faces.new(verts)
    uv = bm.loops.layers.uv.new("UVMap")
    for loop, co in zip(face.loops, ((1, 0), (1, 1), (0, 1), (0, 0))):   # viewer at +Y sees +X on the left
        loop[uv].uv = co
    me = bpy.data.meshes.new("SCOPE_display")
    bm.to_mesh(me)
    bm.free()

    png = os.path.join(HERE, osim.DISPLAY_IMAGE)
    osim.render_plot(png, 12.0, 50.0, 0.0, None, 1.0, 1.0)               # initial picture: wave gen only
    img = bpy.data.images.load("//" + osim.DISPLAY_IMAGE)
    img.name = osim.IMAGE_NAME

    mat = bpy.data.materials.new(osim.DISPLAY_MATERIAL)
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    bsdf = nodes["Principled BSDF"]
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = img
    tex.location = (-400, 200)
    links.new(tex.outputs["Color"], bsdf.inputs["Emission Color"])
    bsdf.inputs["Base Color"].default_value = (0.01, 0.012, 0.015, 1.0)   # black glass when off
    bsdf.inputs["Roughness"].default_value = 0.3
    bsdf.inputs["Emission Strength"].default_value = 1.0
    me.materials.append(mat)

    ob = bpy.data.objects.new("SCOPE_display", me)
    coll.objects.link(ob)
    ob.parent = root
    return ob


def build_texts(coll, root):
    ref = bpy.data.objects["Label_Horizontal_-2.80_23.00"]             # copy how the model's labels face
    white = get_material(osim.TEXT_MAT, base_color=(0.92, 0.92, 0.92, 1.0), roughness=0.6,
                         emission_color=(1.0, 1.0, 1.0, 1.0), emission_strength=0.25)
    hi = get_material(osim.TEXT_MAT_HI, base_color=(1.0, 0.85, 0.2, 1.0), roughness=0.6,
                      emission_color=(1.0, 0.85, 0.2, 1.0), emission_strength=0.8)
    hi.use_fake_user = True                     # unused at build time -> would be dropped on save

    def text(name, body, x, z, size):
        cu = bpy.data.curves.new(name, 'FONT')
        cu.body, cu.size = body, size
        cu.align_x, cu.align_y = 'CENTER', 'CENTER'
        cu.materials.append(white)
        ob = bpy.data.objects.new(name, cu)
        coll.objects.link(ob)
        ob.parent = root
        ob.location = (x, BEZEL_FRONT_Y, z)
        ob.rotation_euler = ref.rotation_euler.copy()
        return ob

    text(osim.READOUT, "", 7.65, 18.15, 0.42)
    text("SCOPE_sk_wave", "Waveform\nSine", SOFTKEY_X["SCOPE_sk_wave"], 5.75, 0.28)
    for key, name in osim.SOFTKEY_TEXT.items():
        set_props(text(name, "", SOFTKEY_X[name], 5.75, 0.28), fn=f"SOFT_{key}")   # clicking the label works too
    _ = hi


def build_pointers(coll):
    dark = bpy.data.materials.get("DarkText") or get_material("SCOPE_pointer", base_color=(0.05, 0.05, 0.05, 1.0))
    for knob_name in ("Horizontal_Knob", "CH1_Knob", "CH2_Knob", "CH1_Pos_Knob", "CH2_Pos_Knob", "Entry_Knob"):
        knob = bpy.data.objects[knob_name]
        r = knob.dimensions.x / 2.0                                   # cylinder along local Z
        z_front = min(c[2] for c in knob.bound_box)                   # local -Z is the face you see
        bm = bmesh.new()
        bm_box(bm, (0.0, r - 0.22, z_front - 0.03), (0.14, 0.36, 0.06))
        finish_bmesh(bm)
        me = mesh_from_bmesh(f"PTR_{knob_name}", bm, [dark])
        ptr = new_object(f"PTR_{knob_name}", me, coll)
        ptr.parent = knob                                             # turns with the knob
    ring = bpy.data.objects["Power_Ring"]
    led = get_material(osim.LED_MATERIAL, base_color=(0.2, 0.9, 0.3, 1.0), roughness=0.5,
                       emission_color=(0.2, 1.0, 0.35, 1.0), emission_strength=2.0)
    ring.data.materials[0] = led


def cable_object(name, build, coll):
    bm = bmesh.new()
    mats = build(bm)
    finish_bmesh(bm)
    return new_object(name, mesh_from_bmesh(name, bm, mats), coll)


def build_cables(scene):
    coll = get_collection("SIM_Cables", parent=scene.collection)
    bpy.context.view_layer.update()
    ch1 = bpy.data.objects["CH1_Input_Pin"].matrix_world.translation.copy()
    gen = bpy.data.objects["FuncGen_Pin"].matrix_world.translation.copy()
    vcc, gnd = world_top("RAIL_post_vcc"), world_top("RAIL_post_gnd")
    out = Vector((0.0, -1.0, 0.0))                                    # the scope front points at -Y
    bench = bench_top_z()
    black = palette_material("probe_black", roughness=0.45)
    red = palette_material("wire_red", roughness=0.45)
    silver = palette_material("lead_silver", metallic=0.9, roughness=0.3)
    grey = palette_material("panel_grey", roughness=0.6)

    def wavegen(bm):
        plug = gen + out * 9.0
        bm_cylinder(bm, gen, plug, 4.2, segments=16, material_index=0)                 # BNC plug body
        bm_cylinder(bm, gen - out * 1.0, gen + out * 1.5, 5.0, segments=16, material_index=2)   # collar
        split = plug + out * 14.0
        bm_tube(bm, [plug, split], 1.6, segments=10, material_index=0)                 # coax stub
        for post, slot, dx in ((vcc, 1, 2.0), (gnd, 0, -2.0)):
            start = split + Vector((dx, 0.0, 0.0))
            path = bezier(start, start + out * 30.0 + Vector((0, 0, -4.0)),
                          Vector((post.x, post.y + 12.0, post.z + 14.0)), post + Vector((0, 0, 6.0)), n=28)
            bm_tube(bm, path, 0.9, segments=8, material_index=slot)                    # lead
            bm_cylinder(bm, post + Vector((0, 0, 0.2)), post + Vector((0, 0, 6.5)), 1.7, segments=12,
                        material_index=slot)                                           # banana plug
        return [black, red, silver]

    end = Vector(PROBE_CABLE_END)                                     # where every spawned probe's cable ends
    lead_dir = Vector((30.0, 0.0, 6.0)).normalized()                  # direction the probe cable arrives from
    coupler_end = end + lead_dir * 9.0

    def ch1_lead(bm):
        plug = ch1 + out * 9.0
        bm_cylinder(bm, ch1, plug, 4.2, segments=16, material_index=0)
        bm_cylinder(bm, ch1 - out * 1.0, ch1 + out * 1.5, 5.0, segments=16, material_index=1)
        path = bezier(plug, plug + out * 70.0 + Vector((0, 0, -25.0)),
                      Vector((140.0, 45.0, bench + 1.8)), coupler_end, n=40)
        bm_tube(bm, path, 1.6, segments=10, material_index=0)
        bm_cylinder(bm, end - lead_dir * 1.0, coupler_end, 2.3, segments=14, material_index=0)   # coupler
        bm_cylinder(bm, end + lead_dir * 3.0, end + lead_dir * 5.0, 2.6, segments=14, material_index=1)
        # holder that keeps the pick-up point in the air while no probe is placed
        foot = Vector((end.x + 1.5, end.y, bench))
        bm_cylinder(bm, foot, foot + Vector((0, 0, 1.5)), 7.0, segments=20, material_index=2)
        bm_cylinder(bm, foot, Vector((foot.x, foot.y, end.z - 2.0)), 1.4, segments=12, material_index=2)
        return [black, silver, grey]

    a = cable_object("CABLE_wavegen", wavegen, coll)
    b = cable_object("CABLE_ch1", ch1_lead, coll)
    for ob in (a, b):
        ob.hide_select = True
    print(f"[build] cables: Gen Out {tuple(round(v) for v in gen)} -> posts; CH1 {tuple(round(v) for v in ch1)} -> {tuple(end)}")


def place_camera(scene):
    cam = bpy.data.objects["CAM_main"]
    eye, target = Vector(CAMERA["eye"]), Vector(CAMERA["target"])
    cam.location = eye
    cam.rotation_euler = (target - eye).to_track_quat('-Z', 'Y').to_euler()
    cam.data.lens = CAMERA["lens"]
    cam.data.clip_end = 3000.0
    scene.camera = cam


def main():
    scene = bpy.context.scene
    coll, root = append_scope(scene)
    build_display(coll, root)
    build_texts(coll, root)
    build_pointers(coll)
    build_cables(scene)
    place_camera(scene)

    readme = bpy.data.texts.get("README") or bpy.data.texts.new("README")
    readme.clear()
    readme.write("OscilloscopeCircuit.blend — breadboard + your buttons.blend selector + oscilloscope.blend\n\n"
                 "Launch with ./launch_oscilloscope.sh (Terminal), which runs toggle_buttons.py,\n"
                 "place_components.py and oscilloscope_sim.py in this session.  The screen shows\n"
                 "AC_Circuit_Solver.plot_voltage's picture; knobs: Horizontal = x_scale_mult,\n"
                 "CH1 = y_scale_mult, Entry + softkeys = wave generator.  Rebuild with\n"
                 "build_oscilloscope_scene.py (never edits breadboard_sim.blend / oscilloscope.blend).\n")
    bpy.ops.wm.save_as_mainfile(filepath=OUT_BLEND, compress=True)
    print(f"[build] saved {OUT_BLEND}: {len(bpy.data.objects)} objects")


if __name__ == "__main__":
    main()
