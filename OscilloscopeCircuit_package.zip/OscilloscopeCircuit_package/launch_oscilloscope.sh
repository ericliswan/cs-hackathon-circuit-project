#!/bin/zsh
# Final product: breadboard + your buttons.blend selector + oscilloscope.blend, in one session.
# Usage: ./launch_oscilloscope.sh            (opens OscilloscopeCircuit.blend)
#        ./launch_oscilloscope.sh --build    (rebuilds it from breadboard_sim.blend + oscilloscope.blend first)
#
# Three scripts, one Blender session:
#   toggle_buttons.py     your buttons: click = arm, writes bpy.context.scene.armed_component
#   place_components.py   hover ring, click hole A, click hole B -> part created, list printed, solved
#   oscilloscope_sim.py   scope screen = AC_Circuit_Solver.plot_voltage's picture; knobs, wave gen, power
# print() output (component list, solver verdict) appears in this Terminal.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
BLENDER="${BLENDER:-/Applications/Blender.app/Contents/MacOS/Blender}"
if [[ ! -x "$BLENDER" ]]; then
  echo "Blender not found at $BLENDER — set BLENDER=/path/to/Blender" >&2; exit 1
fi
cd "$HERE"
if [[ "$1" == "--build" || ! -f "$HERE/OscilloscopeCircuit.blend" ]]; then
  echo "[launch] building OscilloscopeCircuit.blend from breadboard_sim.blend + oscilloscope.blend ..."
  "$BLENDER" -b "$HERE/breadboard_sim.blend" --python "$HERE/build_oscilloscope_scene.py"
fi
exec "$BLENDER" "$HERE/OscilloscopeCircuit.blend" \
    --python "$HERE/toggle_buttons.py" \
    --python "$HERE/place_components.py" \
    --python "$HERE/oscilloscope_sim.py"
