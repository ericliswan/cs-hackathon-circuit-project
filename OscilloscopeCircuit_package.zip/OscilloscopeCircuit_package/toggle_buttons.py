import bpy
from bpy_extras import view3d_utils

# ---------------------------------------------------------------------------
# Buttons = any object whose name is one of these keys (your existing objects).
# Each gets a custom property "arms" so one click handler serves all of them.
# ---------------------------------------------------------------------------
BUTTON_KEYS = ["RESISTOR1", "RESISTOR2", "RESISTOR3",
               "CAPACITOR1", "CAPACITOR2", "CAPACITOR3",
               "WIRE", "PROBE"]

GREY   = (0.78, 0.80, 0.85, 1.0)   # idle colour
ACTIVE = (0.495, 0.801, 0.362, 1.0)  # armed colour (green)
PRESS_DEPTH = 0.08                 # how far an armed button sinks (scene units)

ARMED_PROP = "armed_component"     # bpy.context.scene.armed_component — the cross-script handshake


def get_material(obj):
    """Give the object its own node material and return it."""
    if not obj.data.materials:
        mat = bpy.data.materials.new(f"{obj.name}_mat")
        mat.use_nodes = True
        obj.data.materials.append(mat)
    mat = obj.data.materials[0]
    if mat.users > 1:                        # don't share colours between buttons
        mat = mat.copy()
        obj.data.materials[0] = mat
    mat.use_nodes = True
    if mat.node_tree.nodes.get("Principled BSDF") is None:
        bsdf = mat.node_tree.nodes.new("ShaderNodeBsdfPrincipled")
        out = mat.node_tree.nodes.get("Material Output") or mat.node_tree.nodes.new("ShaderNodeOutputMaterial")
        mat.node_tree.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return mat


def set_colour(obj, rgba):
    mat = get_material(obj)
    mat.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = rgba  # Material Preview / Render
    mat.diffuse_color = rgba                                                          # Solid shading


def set_pressed(obj, pressed):
    was = bool(obj.get("pressed", False))
    obj["pressed"] = pressed
    set_colour(obj, ACTIVE if pressed else GREY)
    if pressed and not was:
        obj.location.z -= PRESS_DEPTH
    elif was and not pressed:
        obj.location.z += PRESS_DEPTH


def button_of(obj):
    """Climb parents until an object carrying 'arms' is found (so clicking a label works)."""
    while obj is not None:
        if "arms" in obj:
            return obj
        obj = obj.parent
    return None


def arm(btn):
    """Radio behaviour: arm `btn`, release every other button; clicking the armed one releases it.

    Writes the armed key to bpy.context.scene.armed_component — the single place ANY other
    script (hover, component creation, ...) reads to find out what's currently selected.
    """
    scene = bpy.context.scene
    if btn.get("pressed"):
        set_pressed(btn, False)
        scene[ARMED_PROP] = ""
    else:
        for other in bpy.data.objects:
            if "arms" in other and other is not btn and other.get("pressed"):
                set_pressed(other, False)
        set_pressed(btn, True)
        scene[ARMED_PROP] = btn["arms"]
    print("[buttons] armed:", scene[ARMED_PROP] or None)


def armed_component():
    """What another script should call to read the currently armed component key ('' = none)."""
    return bpy.context.scene.get(ARMED_PROP, "")


# ---------------------------------------------------------------------------
# One-off scene setup: tag buttons, parent labels, lock everything else
# ---------------------------------------------------------------------------
def setup_buttons():
    buttons = []
    for key in BUTTON_KEYS:
        ob = bpy.data.objects.get(key)
        if ob is None:
            print(f"[buttons] no object named {key!r} — skipped")
            continue
        ob["arms"] = key
        if ob.get("pressed"):                 # reset any state saved in the file
            ob["pressed"] = False
        set_colour(ob, GREY)
        buttons.append(ob)
    # parent each FONT label to the closest button so clicks on the text count
    for ob in bpy.data.objects:
        if ob.type == "FONT" and ob.parent is None and buttons:
            nearest = min(buttons, key=lambda b: (b.location - ob.location).length)
            if (nearest.location - ob.location).length < 3.0:
                world = ob.matrix_world.copy()
                ob.parent = nearest
                ob.matrix_world = world       # keep the label where it is
    bpy.context.scene[ARMED_PROP] = ""
    print(f"[buttons] {len(buttons)} buttons ready:", [b.name for b in buttons])
    return buttons


def lock_scene_objects(exclude_names):
    """Prevent everything except the buttons (and their child labels) from being
    accidentally selected, moved, rotated or scaled in the viewport.

    hide_select disables click-selection (viewport AND Outliner); the lock_* flags
    grey out G/R/S and the N-panel transform fields even if something IS selected
    (e.g. via Select All). Buttons themselves stay unlocked — set_pressed() moves
    them along Z for the press animation.
    """
    locked = []
    for ob in bpy.data.objects:
        if ob.name in exclude_names:
            continue
        ob.hide_select = True
        ob.lock_location = (True, True, True)
        ob.lock_rotation = (True, True, True)
        ob.lock_scale = (True, True, True)
        locked.append(ob.name)
    print(f"[buttons] locked {len(locked)} object(s):", locked)


def unlock_scene_objects():
    """Undo lock_scene_objects(), e.g. while you're still building the scene by hand."""
    for ob in bpy.data.objects:
        ob.hide_select = False
        ob.lock_location = (False, False, False)
        ob.lock_rotation = (False, False, False)
        ob.lock_scale = (False, False, False)
    print("[buttons] unlocked all objects")


# ---------------------------------------------------------------------------
# The click handler
# ---------------------------------------------------------------------------
class VIEW3D_OT_click_toggle(bpy.types.Operator):
    """Click a button to arm it (click again to release). Esc stops."""
    bl_idname = "view3d.click_toggle"
    bl_label = "Click Toggle Component"

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Run from the 3D Viewport")
            return {'CANCELLED'}
        context.window_manager.modal_handler_add(self)
        print("[buttons] click handler running — Esc to stop")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC':
            print("[buttons] stopped")
            return {'CANCELLED'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and context.region_data is not None:
            region, rv3d = context.region, context.region_data
            coord = (event.mouse_region_x, event.mouse_region_y)
            origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            hit, _, _, _, obj, _ = context.scene.ray_cast(context.evaluated_depsgraph_get(), origin, direction)
            btn = button_of(obj) if hit else None
            print(f"[buttons] click: hit={hit} obj={obj.name if hit else None} -> button={btn.name if btn else None}")
            if btn is not None:
                arm(btn)
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}      # consume the click: no Blender selection
        return {'PASS_THROUGH'}               # everything else (orbit, zoom, UI) works as normal


def register():
    if hasattr(bpy.types, "VIEW3D_OT_click_toggle"):      # re-running the script
        bpy.utils.unregister_class(bpy.types.VIEW3D_OT_click_toggle)
    bpy.utils.register_class(VIEW3D_OT_click_toggle)
    if not hasattr(bpy.types.Scene, ARMED_PROP):
        # A real (registerable) Scene property, not just a raw ID prop: shows up in the
        # N-panel with bpy.props tooling and is exactly what other scripts should read.
        setattr(bpy.types.Scene, ARMED_PROP,
               bpy.props.StringProperty(name="Armed Component", default=""))


def start_handler():
    """Invoke the modal with a 3D-viewport context (works from the Text editor)."""
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                region = next(r for r in area.regions if r.type == 'WINDOW')
                area.spaces.active.shading.type = 'MATERIAL'     # so the colour change is visible
                with bpy.context.temp_override(window=window, area=area, region=region):
                    bpy.ops.view3d.click_toggle('INVOKE_DEFAULT')
                return None
    return 0.5                                                   # no viewport yet, retry


if __name__ == "__main__":
    register()
    buttons = setup_buttons()
    lock_scene_objects(exclude_names={b.name for b in buttons} | {l.name for b in buttons for l in b.children})
    if not bpy.app.background:
        bpy.app.timers.register(start_handler, first_interval=0.1)
    else:
        print("[buttons] background mode: registered, not started")
