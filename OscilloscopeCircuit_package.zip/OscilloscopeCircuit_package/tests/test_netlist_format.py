"""
bpy-free unit tests for blender_sim.netlist (formatting + backend bridge + solve).

    python3 tests/test_netlist_format.py            (or: python3 -m pytest tests/test_netlist_format.py)

Import mechanism
----------------
``blender_sim/__init__.py`` imports the bpy-dependent modules, so ``import blender_sim.netlist``
would fail outside Blender.  Instead a bare package object named ``blender_sim`` whose
``__path__`` points at the package directory is registered in ``sys.modules`` *before*
importing ``blender_sim.netlist``.  The import machinery then loads ``netlist.py`` as a
submodule of that package without ever executing ``__init__.py``, and netlist's relative
import (``from .board_layout import ...``) resolves normally.  ``netlist.py`` itself imports
``bpy`` only inside its scene-dependent functions, which these tests never call.
"""
import copy
import importlib
import math
import os
import sys
import types

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG_DIR = os.path.join(PROJECT_DIR, "blender_sim")

if "blender_sim" not in sys.modules:
    _pkg = types.ModuleType("blender_sim")
    _pkg.__path__ = [PKG_DIR]
    sys.modules["blender_sim"] = _pkg
netlist = importlib.import_module("blender_sim.netlist")

assert "bpy" not in sys.modules, "importing blender_sim.netlist must not import bpy"

AMP, PHASE, FREQ = 12.0, 0.0, 50.0

DIVIDER = [
    ["WIRE", "VCC", (1, "b")],
    ["RESISTOR1", (1, "c"), (5, "c")],
    ["RESISTOR2", (5, "d"), (9, "d")],
    ["WIRE", (9, "b"), "GND"],
    ["PROBE", (5, "a"), "GND"],
]

RC_LOWPASS = [
    ["WIRE", "VCC", (1, "b")],
    ["RESISTOR3", (1, "c"), (5, "c")],
    ["CAPACITOR2", (5, "d"), (9, "d")],
    ["WIRE", (9, "b"), "GND"],
    ["PROBE", (5, "a"), "GND"],
]

failures = []
_STRICT = __name__ != "__main__"     # under pytest a failed check must fail the test immediately


def check(cond, msg):
    if cond:
        print("  ok  ", msg)
    else:
        print("  FAIL", msg)
        failures.append(msg)
        if _STRICT:
            raise AssertionError(msg)


# ----------------------------------------------------------------------------
# format_components
# ----------------------------------------------------------------------------
def test_format_three_rows():
    raw = [["WIRE", "VCC", (1, "b")], ["RESISTOR1", (2, "c"), (4, "c")], ["PROBE", (4, "c"), "GND"]]
    expected = ('components = [\n'
                '    ["WIRE", \'VCC\', (1,"b")],\n'
                '    ["RESISTOR1", (2,"c"), (4,"c")],\n'
                '    ["PROBE", (4,"c"), \'GND\'],\n'
                ']')
    text = netlist.format_components(raw)
    print(text)
    check(text == expected, "3-row format is verbatim (4-space indent, trailing commas, closing bracket)")
    check(netlist.format_components([["WIRE", "VCC", "1b"]]) == 'components = [\n    ["WIRE", \'VCC\', (1,"b")],\n]',
          "pin strings are rendered as nets")
    check(netlist.format_components([["WIRE", "VCC", [65, "c"]]]) == 'components = [\n    ["WIRE", \'VCC\', (65,"c")],\n]',
          "list endpoints are rendered as tuples")


def test_format_empty():
    check(netlist.format_components([]) == "components = []", "empty list formats as 'components = []'")
    check(netlist.format_components(None) == "components = []", "None formats as 'components = []'")


def test_report_line_format():
    ok = {"ok": True, "reason": "closed and valid", "amp": 7.41234, "phase_deg": -31.24, "error": None}
    line = netlist.format_report_line(ok, 12.0, 0.0, 50.0)
    check(line == "[BBSIM] circuit: closed and valid | Vout = 7.4123 V ∠ -31.2°  @ 50 Hz  (source 12 V ∠ 0°)",
          f"ok report line: {line}")
    bad = {"ok": False, "reason": netlist.REASON_OPEN, "error": None}
    check(netlist.format_report_line(bad, 12.0, 0.0, 50.0) == "[BBSIM] circuit: open circuit — VCC not connected to GND",
          "failure report line carries only the reason")


# ----------------------------------------------------------------------------
# backend bridge
# ----------------------------------------------------------------------------
def test_backend_bridge():
    backend = netlist.load_backend()
    check(backend.__name__ == "Breadboard_Circuit_Parser", "load_backend imports Breadboard_Circuit_Parser")
    check(hasattr(backend, "solve_nodal") and hasattr(backend, "VoltageSource"),
          "parser namespace carries the solver's names")
    check(netlist.load_backend() is backend, "load_backend caches the module")
    check(netlist.load_backend(reload=True).__name__ == backend.__name__, "load_backend(reload=True) works")
    check(netlist.PROJECT_ROOT in sys.path, "project root inserted in sys.path")

    mpl, plt = netlist.make_matplotlib_stub()
    check(plt.figure(figsize=(8, 4)) is None and plt.show() is None and plt.anything_at_all(1, x=2) is None,
          "matplotlib stub: pyplot calls are no-ops")
    check(mpl.pyplot is plt, "matplotlib stub: matplotlib.pyplot attribute is the pyplot stub")
    try:
        plt.__missing_dunder__
        check(False, "stub raises AttributeError for dunder names")
    except AttributeError:
        check(True, "stub raises AttributeError for dunder names")
    # On this interpreter matplotlib may be real; the stub only installs when it is missing.
    installed = netlist.install_matplotlib_stub()
    try:
        import matplotlib.pyplot  # noqa: F401
        check(True, f"matplotlib.pyplot importable after install_matplotlib_stub (stub installed: {installed})")
    except ImportError:
        check(False, "matplotlib.pyplot importable after install_matplotlib_stub")


# ----------------------------------------------------------------------------
# solve
# ----------------------------------------------------------------------------
def test_solve_parser_test_list():
    backend = netlist.load_backend()
    raw = copy.deepcopy(backend.test)          # the parser's own example circuit
    before = copy.deepcopy(raw)
    res = netlist.solve(raw, AMP, PHASE, FREQ)
    print(f"  parser test list -> ok={res['ok']} reason={res['reason']!r} amp={res['amp']} phase={res['phase_deg']}")
    check(res["ok"] is True and res["reason"] == "closed and valid", "parser's own test list solves")
    check(res["amp"] is not None and res["amp"] > 0 and res["phase_deg"] is not None, "amp/phase returned")
    check(res["probe"] == (5, 0), f"probe nodes reduced to (5, 0): {res['probe']}")
    check(isinstance(res["v_nodes"], list) and all(isinstance(v, complex) for v in res["v_nodes"]),
          "v_nodes is a plain list of complex")
    check(raw == before, "solve does not mutate the caller's raw list")
    check(set(res) == {"ok", "reason", "amp", "phase_deg", "v_nodes", "probe", "error"}, "result keys per contract")


def test_solve_divider():
    res = netlist.solve(DIVIDER, AMP, PHASE, FREQ)
    print(f"  divider -> {res['reason']} amp={res['amp']} phase={res['phase_deg']}")
    check(res["ok"] is True, "resistive divider solves")
    check(res["amp"] is not None and abs(res["amp"] - 8.0) < 1e-6, f"divider amplitude 8.0 V (got {res['amp']})")
    check(res["phase_deg"] is not None and abs(res["phase_deg"]) < 1e-6, f"divider phase 0 deg (got {res['phase_deg']})")
    # source phase propagates and stays in (-180, 180]
    res2 = netlist.solve(DIVIDER, AMP, 170.0, FREQ)
    check(res2["ok"] and abs(res2["phase_deg"] - 170.0) < 1e-6, f"source phase 170 -> output 170 (got {res2['phase_deg']})")
    res3 = netlist.solve(DIVIDER, AMP, -200.0, FREQ)
    check(res3["ok"] and abs(res3["phase_deg"] - 160.0) < 1e-6, f"source phase -200 -> output 160 (got {res3['phase_deg']})")


def test_solve_rc_lowpass():
    R, C = 1000.0, 47e-6
    w = 2 * math.pi * FREQ
    wrc = w * R * C
    exp_amp = AMP / math.sqrt(1 + wrc ** 2)
    exp_phase = -math.degrees(math.atan(wrc))
    res = netlist.solve(RC_LOWPASS, AMP, PHASE, FREQ)
    print(f"  RC low-pass -> {res['reason']} amp={res['amp']} phase={res['phase_deg']} "
          f"(expected {exp_amp:.6f}, {exp_phase:.4f})")
    check(res["ok"] is True, "RC low-pass solves")
    check(res["amp"] is not None and abs(res["amp"] - exp_amp) < 1e-6, "RC amplitude = 12/sqrt(1+(wRC)^2)")
    check(res["phase_deg"] is not None and abs(res["phase_deg"] - exp_phase) < 1e-6, "RC phase = -atan(wRC)")


def test_solve_open_circuit():
    raw = [r for r in DIVIDER if not (r[0] == "WIRE" and r[2] == "GND")]
    res = netlist.solve(raw, AMP, PHASE, FREQ)
    check(res["ok"] is False and res["reason"] == "open circuit — VCC not connected to GND",
          f"open circuit: {res['reason']}")
    check(res["v_nodes"] is None and res["amp"] is None, "open circuit returns no voltages")
    res = netlist.solve([], AMP, PHASE, FREQ)
    check(res["ok"] is False and "open" in res["reason"], f"empty board is an open circuit: {res['reason']}")
    check(netlist.classify([]) == netlist.REASON_OPEN, "classify([]) -> open")


def test_solve_short():
    raw = DIVIDER + [["WIRE", "VCC", "GND"]]
    res = netlist.solve(raw, AMP, PHASE, FREQ)
    check(res["ok"] is False and res["reason"] == "VCC wired directly to GND", f"direct short: {res['reason']}")
    raw = [["WIRE", "GND", "VCC"]]
    res = netlist.solve(raw, AMP, PHASE, FREQ)
    check(res["ok"] is False and res["reason"] == "VCC wired directly to GND", f"lone GND-VCC wire: {res['reason']}")
    # indirect short through a strip column (chain of wires)
    raw = [["WIRE", "VCC", (1, "b")], ["WIRE", (1, "a"), "GND"], ["PROBE", (1, "c"), "GND"]]
    res = netlist.solve(raw, AMP, PHASE, FREQ)
    check(res["ok"] is False and res["reason"] == "VCC wired directly to GND", f"wire-chain short: {res['reason']}")
    check(netlist.classify(raw) == netlist.REASON_SHORT, "classify -> short")
    check(netlist.classify(DIVIDER) is None, "classify(divider) -> None (solvable)")


def test_solve_no_probe():
    raw = [r for r in DIVIDER if r[0] != "PROBE"]
    res = netlist.solve(raw, AMP, PHASE, FREQ)
    check(res["ok"] is False and res["reason"] == "no probe placed", f"no probe: {res['reason']}")
    check(isinstance(res["v_nodes"], list) and len(res["v_nodes"]) >= 7, "v_nodes still returned without a probe")
    check(abs(res["v_nodes"][1] - 12.0) < 1e-9 and abs(res["v_nodes"][6] - 8.0) < 1e-6,
          "node voltages: VCC node = 12 V, divider node = 8 V")
    # a probe whose ends the wires merge onto one node is dropped by the parser -> distinct reason
    raw = [r for r in DIVIDER if r[0] != "PROBE"] + [["PROBE", (9, "a"), "GND"]]
    res = netlist.solve(raw, AMP, PHASE, FREQ)
    check(res["ok"] is False and res["reason"] == netlist.REASON_PROBE_SAME_NODE and "same node" in res["reason"],
          f"probe across one node: {res['reason']}")


def test_solve_floating_probe():
    raw = [r for r in DIVIDER if r[0] != "PROBE"] + [["PROBE", (30, "a"), "GND"]]
    res = netlist.solve(raw, AMP, PHASE, FREQ)
    check(res["ok"] is False and "floating" in res["reason"], f"floating probe (index out of range): {res['reason']}")
    # a probe on a strip column below the highest used node but unused -> NaN path
    raw = [r for r in DIVIDER if r[0] != "PROBE"] + [["PROBE", (7, "a"), "GND"]]
    res = netlist.solve(raw, AMP, PHASE, FREQ)
    check(res["ok"] is False and "floating" in res["reason"], f"floating probe (NaN node): {res['reason']}")


def test_solve_never_raises():
    res = netlist.solve([["RESISTOR1", "VCC", "GND"], ["BOGUS", (1, "a"), (2, "a")]], AMP, PHASE, FREQ)
    check(res["ok"] is False and res["reason"] == "solver error" and res["error"], f"unknown key -> solver error: {res['error']}")
    res = netlist.solve([["RESISTOR1", "VCC", "GND"], ["PROBE", "VCC", "GND"]], AMP, PHASE, FREQ)
    check(res["ok"] is True and abs(res["amp"] - 12.0) < 1e-9, "single resistor across the rails reads 12 V")
    res = netlist.solve(DIVIDER, "twelve", PHASE, FREQ)
    check(res["ok"] is False and res["reason"] == "solver error", "bad amplitude type -> solver error, no exception")


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for t in tests:
        print(f"== {t.__name__}")
        try:
            t()
        except Exception as exc:  # noqa: BLE001
            import traceback
            traceback.print_exc()
            failures.append(f"{t.__name__}: {exc!r}")
    print("\nNETLIST TEST:", "PASS" if not failures else f"FAIL ({len(failures)})")
    for f in failures:
        print("  -", f)
    sys.exit(1 if failures else 0)
