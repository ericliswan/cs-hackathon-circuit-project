"""
Headless test + visual check for blender_sim.component_meshes.

    "/Applications/Blender.app/Contents/MacOS/Blender" -b --python tests/test_component_meshes_headless.py

Spawns every placeable key between sample holes on a plain white slab, asserts names, props,
face budgets and that every mesh physically reaches both holes, checks placed_root /
remove_component, then renders preview PNGs into the scratch dir (overview + close-ups).
Prints 'COMPONENT MESHES TEST: PASS' on success; exits non-zero on failure.
"""
import math
import os
import sys
import traceback

import bmesh
import bpy
from mathutils import Vector

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_DIR)
SCRATCH = os.environ.get(
    "BBSIM_SCRATCH",
    "/private/tmp/claude-501/-Users-imira-Desktop-Claude-Projects-Oscilloscope-Circuits/"
    "ef82b01b-cc10-49e2-94f3-099864d2aff4/scratchpad")
os.makedirs(SCRATCH, exist_ok=True)

failures = []

SAMPLES = [
    ("WIRE", "VCC", "1b"),               # rail -> strip
    ("RESISTOR1", "1c", "5c"),           # normal span
    ("RESISTOR2", "5d", "9d"),
    ("RESISTOR3", "10a", "10b"),         # adjacent -> standing resistor
    ("CAPACITOR1", "5e", "65a"),         # across the channel
    ("CAPACITOR2", "9c", "14c"),
    ("CAPACITOR3", "20b", "26b"),
    ("INDUCTOR1", "30c", "34c"),
    ("INDUCTOR2", "40c", "46c"),
    ("INDUCTOR3", "50c", "58c"),
    ("WIRE", "14a", "GND"),
    ("WIRE", "65e", "120e"),             # long wire
    ("PROBE", "9a", "GND"),
    ("INDUCTOR3", "70a", "70b"),         # cramped inductor
    ("CAPACITOR3", "75c", "75d"),        # adjacent can
    ("WIRE", "80a", "81a"),              # shortest jumper
]


def check(cond, msg):
    print("  ok  " if cond else "  FAIL", msg)
    if not cond:
        failures.append(msg)


def build_context_board(layout, collection):
    """White slab + dark dot at every hole, so the renders have context."""
    from blender_sim.bpy_utils import bm_box, finish_bmesh, mesh_from_bmesh, new_object
    from blender_sim.materials import palette_material
    from blender_sim.board_layout import BOARD_THICKNESS
    bm = bmesh.new()
    cx, cy = layout.centre
    bm_box(bm, (cx, cy, -BOARD_THICKNESS / 2), (layout.width, layout.length, BOARD_THICKNESS), 0)
    for h in layout.holes:
        bm_box(bm, (h.x, h.y, 0.02), (1.0, 1.0, 0.08), 1)
    finish_bmesh(bm)
    me = mesh_from_bmesh("TEST_board", bm, [palette_material("board_white", roughness=0.6),
                                            palette_material("hole_dark", roughness=0.9)])
    return new_object("TEST_board", me, collection)


def setup_render(scene, collection):
    scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x, scene.render.resolution_y = 1100, 700
    scene.render.resolution_percentage = 100
    scene.eevee.taa_render_samples = 32
    scene.render.image_settings.file_format = "PNG"
    world = bpy.data.worlds.new("TEST_world")
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    if bg:
        bg.inputs[0].default_value = (0.45, 0.5, 0.55, 1.0)
        bg.inputs[1].default_value = 1.0
    scene.world = world
    sun = bpy.data.lights.new("TEST_sun", "SUN")
    sun.energy = 3.0
    sun.angle = math.radians(20)
    ob = bpy.data.objects.new("TEST_sun", sun)
    collection.objects.link(ob)
    ob.rotation_euler = (math.radians(40), math.radians(-20), math.radians(30))
    fill = bpy.data.lights.new("TEST_fill", "AREA")
    fill.energy = 20000.0
    fill.size = 80
    fo = bpy.data.objects.new("TEST_fill", fill)
    collection.objects.link(fo)
    fo.location = (-40, -40, 60)
    fo.rotation_euler = Vector((40, -40, 60)).normalized().to_track_quat("Z", "Y").to_euler()
    cam = bpy.data.cameras.new("TEST_cam")
    cam.lens = 50
    cam.clip_start = 1.0
    cam.clip_end = 2000.0
    co = bpy.data.objects.new("TEST_cam", cam)
    collection.objects.link(co)
    scene.camera = co
    return co


def aim_camera(cam_obj, target, distance, elevation_deg=55.0, azimuth_deg=-125.0):
    el, az = math.radians(elevation_deg), math.radians(azimuth_deg)
    offset = Vector((math.cos(el) * math.cos(az), math.cos(el) * math.sin(az), math.sin(el))) * distance
    cam_obj.location = Vector(target) + offset
    cam_obj.rotation_euler = (-offset).to_track_quat("-Z", "Y").to_euler()


def render(scene, path):
    scene.render.filepath = path
    try:
        bpy.ops.render.render(write_still=True)
    except Exception as e:                       # headless GPU contexts can be flaky
        print("  render failed with EEVEE:", e, "-> retrying with WORKBENCH")
        scene.render.engine = "BLENDER_WORKBENCH"
        bpy.ops.render.render(write_still=True)
    print("  rendered", path)


def mesh_points(obj):
    pts = [obj.matrix_world @ v.co for v in obj.data.vertices]
    for ch in obj.children_recursive:
        if ch.type == "MESH":
            pts += [ch.matrix_world @ v.co for v in ch.data.vertices]
    return pts


def main():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    import blender_sim
    from blender_sim import component_meshes as cm
    from blender_sim.board_layout import BoardLayout, HOLE_DEPTH
    from blender_sim.bpy_utils import get_collection

    scene = bpy.context.scene
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.scale_length = 0.001
    scene.unit_settings.length_unit = "MILLIMETERS"
    layout = BoardLayout()
    env = get_collection("TEST_env", parent=scene.collection)
    build_context_board(layout, env)
    cam = setup_render(scene, env)

    print("== COMPONENT_INFO")
    keys = ["RESISTOR1", "RESISTOR2", "RESISTOR3", "CAPACITOR1", "CAPACITOR2", "CAPACITOR3",
            "INDUCTOR1", "INDUCTOR2", "INDUCTOR3", "WIRE", "PROBE", "DELETE"]
    check(list(cm.COMPONENT_INFO.keys()) == keys, "12 keys in palette order")
    for k in keys:
        info = cm.COMPONENT_INFO[k]
        check("label" in info and "kind" in info, f"{k} has label/kind ({info['label']})")
    check(cm.COMPONENT_INFO["DELETE"]["kind"] == "DELETE" and cm.COMPONENT_INFO["DELETE"]["label"] == "Delete",
          "DELETE entry")
    check(cm.COMPONENT_INFO["RESISTOR1"]["bands"] == ("red", "green", "brown"), "R1 bands")
    check(cm.COMPONENT_INFO["RESISTOR2"]["bands"] == ("green", "black", "brown"), "R2 bands")
    check(cm.COMPONENT_INFO["RESISTOR3"]["bands"] == ("brown", "black", "red"), "R3 bands")

    print("== spawn")
    placed = []
    for uid, (comp_type, a, b) in enumerate(SAMPLES, start=1):
        ha, hb = layout.hole(a), layout.hole(b)
        try:
            obj = cm.spawn_component(scene, comp_type, ha, hb, uid)
        except Exception:
            traceback.print_exc()
            obj = None
        check(obj is not None, f"spawn {comp_type} {a}->{b}")
        if obj is None:
            continue
        placed.append(obj)
        expected = {"WIRE": f"WIRE_{uid:04d}", "PROBE": f"PROBE_{uid:04d}"}.get(comp_type, f"COMP_{comp_type}_{uid:04d}")
        check(obj.name == expected, f"  name {obj.name}")
        role = {"WIRE": "WIRE", "PROBE": "PROBE"}.get(comp_type, "COMPONENT")
        check(obj.get("sim_role") == role and obj.get("comp_type") == comp_type, "  sim_role/comp_type")
        check(obj.get("pin_a") == a and obj.get("pin_b") == b and obj.get("uid") == uid, "  pin_a/pin_b/uid")
        xa, xb = list(obj["pin_a_xyz"]), list(obj["pin_b_xyz"])
        check(len(xa) == 3 and abs(xa[0] - ha.x) < 1e-6 and abs(xa[1] - ha.y) < 1e-6, "  pin_a_xyz")
        check(len(xb) == 3 and abs(xb[0] - hb.x) < 1e-6 and abs(xb[1] - hb.y) < 1e-6, "  pin_b_xyz")
        check(obj.users_collection and obj.users_collection[0].name == "SIM_Components", "  in SIM_Components")
        nfaces = len(obj.data.polygons)
        check(0 < nfaces < 3000, f"  faces {nfaces}")
        check(len(obj.data.materials) >= 2, f"  material slots {len(obj.data.materials)}")
        pts = mesh_points(obj)
        da = min(math.hypot(p.x - ha.x, p.y - ha.y) for p in pts)
        db = min(math.hypot(p.x - hb.x, p.y - hb.y) for p in pts)
        zmin = min(p.z for p in pts)
        check(da < 0.8 and db < 0.8, f"  reaches both holes (d={da:.2f},{db:.2f})")
        check(zmin < -0.5 and zmin > -HOLE_DEPTH - 0.5, f"  pins sunk (zmin={zmin:.2f})")
        check(any(f.use_smooth for f in obj.data.polygons), "  smooth shading present")

    print("== errors")
    for comp_type, a, b in (("RESISTOR1", "5c", "5c"), ("DELETE", "1a", "2a"), ("BOGUS", "1a", "2a")):
        try:
            cm.spawn_component(scene, comp_type, layout.hole(a), layout.hole(b), 999)
            ok = False
        except ValueError:
            ok = True
        check(ok, f"ValueError for {comp_type} {a}->{b}")

    print("== renders")
    y = layout.column_y
    views = [  # (file, target, distance, elevation, azimuth, lens)
        ("components_preview.png", (-6, y(20), 2), 90, 55, -125, 24),
        ("components_preview_1.png", (-14, y(7), 2), 48, 50, -120, 50),
        ("components_preview_2.png", (-12, y(25), 2), 40, 50, -120, 50),
        ("components_preview_3.png", (-12, y(49), 2), 48, 50, -120, 50),
        ("components_preview_4.png", (12, y(74), 2), 40, 50, -60, 50),
        ("components_preview_5.png", (-14, y(3), 2), 40, 55, -150, 50),
    ]
    for fname, target, dist, el, az, lens in views:
        cam.data.lens = lens
        aim_camera(cam, target, dist, el, az)
        path = os.path.join(SCRATCH, fname)
        render(scene, path)
        check(os.path.exists(path), f"{fname} written")

    print("== placed_root / remove_component")
    cube_me = bpy.data.meshes.new("TEST_cube")
    cube = bpy.data.objects.new("TEST_cube", cube_me)
    env.objects.link(cube)
    check(cm.placed_root(cube) is None, "plain cube -> None")
    check(cm.placed_root(None) is None, "None -> None")
    check(cm.placed_root(placed[0]) is placed[0], "root -> itself")
    cube.parent = placed[1]
    check(cm.placed_root(cube) is placed[1], "child climbs to root")
    try:
        cm.remove_component(bpy.data.objects["TEST_board"])
        ok = False
    except ValueError:
        ok = True
    check(ok and bpy.data.objects.get("TEST_board") is not None, "refuses to remove the board")
    victim = placed.pop()            # the shortest jumper
    vname, vmesh = victim.name, victim.data.name
    cm.remove_component(victim)
    check(bpy.data.objects.get(vname) is None, f"removed {vname}")
    check(bpy.data.meshes.get(vmesh) is None, "mesh datablock freed")
    victim = placed.pop()            # adjacent can (remove via its child)
    vname = victim.name
    cube.parent = victim
    cm.remove_component(cube)
    check(bpy.data.objects.get(vname) is None and bpy.data.objects.get("TEST_cube") is None,
          "removing via a child removes the whole tree")

    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(SCRATCH, "component_meshes_test.blend"))


try:
    main()
except Exception:
    traceback.print_exc()
    failures.append("exception: " + traceback.format_exc().splitlines()[-1])

print("\nCOMPONENT MESHES TEST:", "PASS" if not failures else f"FAIL ({len(failures)})")
for f in failures:
    print("  -", f)
if failures:
    sys.exit(1)
