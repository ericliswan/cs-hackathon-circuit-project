"""Unit tests for blender_sim.board_layout (run with system python: python3 -m pytest tests/ or python3 tests/test_board_layout.py)."""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from blender_sim.board_layout import *  # noqa


def test_counts_standard():
    L = BoardLayout(LAYOUT_STANDARD)
    assert len(L.strip_holes()) == 2 * 60 * 5
    assert len(L.rail_holes()) == 4 * 50
    assert len(L.holes) == 600 + 200
    assert len({h.key for h in L.holes}) == len(L.holes)


def test_logical_columns_and_pins():
    L = BoardLayout()
    h = L.hole((65, "c"))
    assert h.net == (65, "c") and h.pin == "65c" and h.side == "R"
    assert string_to_net("65c") == (65, "c")
    assert net_to_string((5, "a")) == "5a"
    assert string_to_net("VCC") == "VCC" and net_to_string("GND") == "GND"
    assert net_repr((5, "c")) == '(5,"c")' and net_repr("VCC") == "'VCC'"
    assert physical_from_logical(61) == ("R", 1) and physical_from_logical(120) == ("R", 60)
    assert logical_from_physical("R", 5) == 65


def test_geometry_standard():
    L = BoardLayout()
    # pitch along columns
    assert math.isclose(L.hole((2, "a")).y - L.hole((1, "a")).y, PITCH)
    # same column on both halves shares y
    assert math.isclose(L.hole((5, "c")).y, L.hole((65, "c")).y)
    # channel spacing e(L) -> a(R)
    assert math.isclose(L.hole((5, "a")).x - L.hole((5, "e")).x, -4 * PITCH)
    assert math.isclose(L.hole((65, "a")).x - L.hole((5, "e")).x, CHANNEL)
    # halves read a..e left to right
    assert L.hole((5, "a")).x < L.hole((5, "e")).x < 0 < L.hole((65, "a")).x < L.hole((65, "e")).x
    # column 1 nearest the camera (most negative y)
    assert L.hole((1, "a")).y < L.hole((60, "a")).y
    # rails outside the strips, VCC outermost
    assert L.rail_x("L", NET_VCC) < L.rail_x("L", NET_GND) < L.hole((1, "a")).x
    assert L.hole((61, "e")).x < L.rail_x("R", NET_VCC) < L.rail_x("R", NET_GND)   # + - | + -
    assert L.rail_is_outer("L", NET_VCC) and L.rail_is_outer("R", NET_GND)
    assert not L.rail_is_outer("L", NET_GND) and not L.rail_is_outer("R", NET_VCC)
    assert math.isclose(L.width, 2 * (4 * PITCH + CHANNEL / 2 + RAIL_GAP + RAIL_PAIR + SIDE_MARGIN))


def test_nearest():
    L = BoardLayout()
    h = L.hole((7, "d"))
    assert L.nearest(h.x + 0.6, h.y - 0.5) is h
    assert L.nearest(h.x + 1.27, h.y) is None or L.nearest(h.x + 1.3, h.y) is not h
    # rail hole resolves to the rail net
    r = L.rail_holes(net="GND", side="R")[3]
    assert L.nearest(r.x + 0.2, r.y + 0.2).net == "GND"
    # a point in the channel is not a hole
    assert L.nearest(0.0, 0.0) is None


def test_end_to_end():
    L = BoardLayout(LAYOUT_END_TO_END)
    assert len(L.holes) == 600 + 4 * 100
    assert L.hole((60, "c")).y < L.hole((61, "c")).y
    assert math.isclose(L.hole((61, "c")).y - L.hole((60, "c")).y, END_TO_END_GAP)
    assert math.isclose(L.hole((5, "c")).x, L.hole((65, "c")).x)


def test_columns_option():
    L = BoardLayout(columns=30)
    assert len(L.strip_holes()) == 2 * 30 * 5 and len(L.rail_holes()) == 4 * 25
    assert L.hole((30, "a")) and L.hole((90, "e")).side == "R"
    assert BoardLayout.from_params(L.to_params()).columns == 30
    try:
        L.hole((31, "a")); assert False, "column 31 must not exist on a 30-column board"
    except KeyError:
        pass


def test_params_roundtrip():
    L = BoardLayout(LAYOUT_END_TO_END)
    L2 = BoardLayout.from_params(L.to_params())
    assert L2.layout == L.layout and len(L2.holes) == len(L.holes)
    t = L.export_table()
    assert t["strip"]["65c"] == [round(v, 4) for v in L.hole("65c").xyz]


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn(); print("ok", name)
