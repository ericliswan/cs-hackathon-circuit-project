"""
Headless Blender test for blender_sim.netlist's scene-dependent functions.

    "/Applications/Blender.app/Contents/MacOS/Blender" -b --python tests/test_netlist_headless.py

Builds no geometry: three empties carrying the placed-item custom props (CONTRACT §2) stand
in for spawned components, plus a board empty with layout props and a child object without
``sim_role``.  Checks ``placed_objects`` / ``build_raw`` ordering and format, ``get_layout``,
``print_components``, ``report`` (with and without the ``bbsim_*`` scene props) and
``next_uid``.  Prints ``NETLIST TEST: PASS`` on success; exits non-zero on failure.
"""
import os
import sys
import traceback

import bpy

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_DIR)

failures = []


def check(cond, msg):
    if cond:
        print("  ok  ", msg)
    else:
        print("  FAIL", msg)
        failures.append(msg)


def make_placed(name, sim_role, comp_type, pin_a, pin_b, uid, layout, parent=None):
    """An empty carrying exactly the placed-item props from CONTRACT §2."""
    ob = bpy.data.objects.new(name, None)
    bpy.context.scene.collection.objects.link(ob)
    ob["sim_role"] = sim_role
    ob["comp_type"] = comp_type
    ob["pin_a"] = pin_a
    ob["pin_b"] = pin_b
    ob["pin_a_xyz"] = list(layout.hole(pin_a).xyz)
    ob["pin_b_xyz"] = list(layout.hole(pin_b).xyz)
    ob["uid"] = uid
    ob.parent = parent
    return ob


def main():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    from blender_sim import netlist
    from blender_sim.board_layout import BoardLayout, DEFAULT_LAYOUT, LAYOUT_END_TO_END

    scene = bpy.context.scene

    print("== backend bridge inside Blender (no matplotlib here)")
    backend = netlist.load_backend()
    check(backend.__name__ == "Breadboard_Circuit_Parser", "backend imported inside Blender")
    import matplotlib.pyplot as plt
    check(plt.figure() is None and plt.show() is None, "matplotlib.pyplot resolves (stub or real) and is callable")
    print("     matplotlib is", "the no-op stub" if isinstance(plt, netlist._StubModule) else "a real install")

    print("== get_layout")
    check(netlist.get_layout(scene) is DEFAULT_LAYOUT, "no board object -> DEFAULT_LAYOUT")
    board = bpy.data.objects.new("BOARD_breadboard", None)
    scene.collection.objects.link(board)
    board["sim_role"] = "BOARD"
    for k, v in BoardLayout(LAYOUT_END_TO_END).to_params().items():
        board[k] = v
    layout = netlist.get_layout(scene)
    check(isinstance(layout, BoardLayout) and layout.layout == LAYOUT_END_TO_END, "layout rebuilt from board props")
    check(netlist.get_layout(scene) is layout, "layout cached by name")
    board["layout"] = "STANDARD"
    layout = netlist.get_layout(scene)
    check(layout.layout == "STANDARD" and len(layout.holes) == 800, "STANDARD layout recovered (800 holes)")

    print("== next_uid")
    check("bbsim_next_uid" not in scene.keys(), "counter starts absent")
    u1, u2, u3 = netlist.next_uid(scene), netlist.next_uid(scene), netlist.next_uid(scene)
    check((u1, u2, u3) == (1, 2, 3) and scene["bbsim_next_uid"] == 3, f"next_uid increments: {(u1, u2, u3)}")

    print("== placed_objects / build_raw")
    check(netlist.placed_objects(scene) == [] and netlist.build_raw(scene) == [], "empty board -> no rows")
    # created out of uid order on purpose
    r1 = make_placed("COMP_RESISTOR1_0002", "COMPONENT", "RESISTOR1", "1c", "5c", 2, layout)
    w1 = make_placed("WIRE_0001", "WIRE", "WIRE", "VCC", "1b", 1, layout)
    p1 = make_placed("PROBE_0003", "PROBE", "PROBE", "5a", "GND", 3, layout)
    # a child without sim_role and an unrelated object must be ignored
    child = bpy.data.objects.new("COMP_RESISTOR1_0002.body", None)
    scene.collection.objects.link(child)
    child.parent = r1
    btn = bpy.data.objects.new("BTN_resistor1", None)
    scene.collection.objects.link(btn)
    btn["sim_role"] = "BUTTON"
    btn["arms"] = "RESISTOR1"

    objs = netlist.placed_objects(scene)
    check([o.name for o in objs] == ["WIRE_0001", "COMP_RESISTOR1_0002", "PROBE_0003"],
          f"placed_objects sorted by uid: {[o.name for o in objs]}")
    raw = netlist.build_raw(scene)
    check(raw == [["WIRE", "VCC", (1, "b")], ["RESISTOR1", (1, "c"), (5, "c")], ["PROBE", (5, "a"), "GND"]],
          f"build_raw rows/order: {raw}")
    text = netlist.format_components(raw)
    expected = ('components = [\n'
                '    ["WIRE", \'VCC\', (1,"b")],\n'
                '    ["RESISTOR1", (1,"c"), (5,"c")],\n'
                '    ["PROBE", (5,"a"), \'GND\'],\n'
                ']')
    check(text == expected, "format_components verbatim")

    print("== print_components")
    out = netlist.print_components(scene, reason='placed RESISTOR1 (1,"c")->(5,"c")')
    check(out.splitlines()[0] == '[BBSIM] components (3) — placed RESISTOR1 (1,"c")->(5,"c")', "header with reason")
    check(out == out.splitlines()[0] + "\n" + expected, "header + formatted list")
    out = netlist.print_components(scene)
    check(out.splitlines()[0] == "[BBSIM] components (3)", "header without reason")

    print("== report (no bbsim_* props registered -> defaults 12 V / 0 deg / 50 Hz)")
    check(not hasattr(scene, "bbsim_amplitude"), "interaction props not registered in this test")
    res = netlist.report(scene)
    check(res["ok"] is False and res["reason"] == "open circuit — VCC not connected to GND",
          f"open circuit reported: {res['reason']}")
    check(res["summary"] == "[BBSIM] circuit: open circuit — VCC not connected to GND", "summary line")
    # close the divider: R2 5d-9d, wire 9b-GND
    make_placed("COMP_RESISTOR2_0004", "COMPONENT", "RESISTOR2", "5d", "9d", netlist.next_uid(scene), layout)
    make_placed("WIRE_0005", "WIRE", "WIRE", "9b", "GND", netlist.next_uid(scene), layout)
    res = netlist.report(scene)
    check(res["ok"] is True and abs(res["amp"] - 8.0) < 1e-6 and abs(res["phase_deg"]) < 1e-6,
          f"divider solves to 8 V / 0 deg: {res['summary']}")
    check(res["summary"] == "[BBSIM] circuit: closed and valid | Vout = 8.0000 V ∠ 0.0°  @ 50 Hz  (source 12 V ∠ 0°)",
          "ok summary line format")

    print("== report honours scene bbsim_* props when present")
    bpy.types.Scene.bbsim_amplitude = bpy.props.FloatProperty(default=12.0)
    bpy.types.Scene.bbsim_phase = bpy.props.FloatProperty(default=0.0)
    bpy.types.Scene.bbsim_frequency = bpy.props.FloatProperty(default=50.0)
    try:
        scene.bbsim_amplitude, scene.bbsim_phase, scene.bbsim_frequency = 6.0, 30.0, 1000.0
        res = netlist.report(scene)
        check(res["ok"] and abs(res["amp"] - 4.0) < 1e-6 and abs(res["phase_deg"] - 30.0) < 1e-6,
              f"6 V ∠ 30° source -> 4 V ∠ 30°: {res['summary']}")
        check("@ 1000 Hz  (source 6 V ∠ 30°)" in res["summary"], "summary shows the scene's source settings")
    finally:
        del bpy.types.Scene.bbsim_amplitude
        del bpy.types.Scene.bbsim_phase
        del bpy.types.Scene.bbsim_frequency

    print("== short / delete / malformed props")
    short = make_placed("WIRE_0006", "WIRE", "WIRE", "VCC", "GND", netlist.next_uid(scene), layout)
    res = netlist.report(scene)
    check(res["ok"] is False and res["reason"] == "VCC wired directly to GND", f"short: {res['reason']}")
    bpy.data.objects.remove(short, do_unlink=True)
    check(len(netlist.build_raw(scene)) == 5 and netlist.report(scene)["ok"], "removing the short restores the divider")
    bpy.data.objects.remove(p1, do_unlink=True)
    res = netlist.report(scene)
    check(res["ok"] is False and res["reason"] == "no probe placed", f"probe removed: {res['reason']}")
    w1["pin_b"] = "999z"
    res = netlist.report(scene)
    check(res["ok"] is False and res["reason"] == "solver error" and "WIRE_0001" in res["error"],
          f"malformed pin -> solver error, no exception: {res['error']}")
    w1["pin_b"] = "1b"
    check(netlist.build_raw(scene)[0] == ["WIRE", "VCC", (1, "b")], "pin restored")


try:
    main()
except Exception:  # noqa: BLE001
    traceback.print_exc()
    failures.append("exception: " + traceback.format_exc().splitlines()[-1])

print("\nNETLIST TEST:", "PASS" if not failures else f"FAIL ({len(failures)})")
for f in failures:
    print("  -", f)
if failures:
    sys.exit(1)
