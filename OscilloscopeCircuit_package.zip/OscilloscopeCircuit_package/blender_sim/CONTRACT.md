# blender_sim — Module Contract (Phase 1: breadboard + placement + delete + terminal netlist)

This is the binding interface between the modules of the `blender_sim` Blender package.
Every module author MUST follow the names, signatures, conventions and file paths here.
Read these first (they are authoritative, in this order):

1. `AC_Circuit_Solver.py` and `Breadboard_Circuit_Parser.py` (project root) — the backend.
   **Never edit them.** Their identifiers win over the spec documents.
2. `blender_sim/board_layout.py` — hole coordinate source of truth (pure Python, tested).
3. `breadboard_sim_spec.md` §2, §3, §4.2–4.4, §5.3, §5.4, §5.7, §6 — the UX spec.
4. `blender_sim/RESEARCH_NOTES.md` — verified Blender 4.1 API facts + breadboard dimensions.

Target: **Blender 4.1** (`/Applications/Blender.app/Contents/MacOS/Blender`), bundled Python 3.11
(has numpy, no matplotlib). Everything must work headless (`Blender -b --python ...`) except the
GUI-only parts (modal operator event handling, draw handlers), which must be guarded so that
importing/registering the package headless never fails.

## 0. Phase-1 scope (what "done" means)

* A procedurally generated breadboard (two halves 1–60 × rows a–e, centre channel, VCC/GND rails)
  on a carrier board on a bench, with labels, camera and lights, built by `scene_builder.build_scene()`.
* A side panel of **3D clickable buttons** (and a mirrored N-panel) that arm a mode:
  `RESISTOR1/2/3`, `CAPACITOR1/2/3`, `INDUCTOR1/2/3`, `WIRE`, `PROBE`, `DELETE`.
* **Two-click placement**: first click on a hole = endpoint A (marker shown, rubber-band line),
  second click on a different hole = endpoint B → component mesh spawned spanning the holes with
  custom props, netlist row appended, **component list printed to the terminal** in the backend's format.
* **Delete mode**: click a placed component/wire/probe → removed → list re-printed. The breadboard,
  rails, buttons, labels and bench can never be deleted.
* After every change the backend is run (`check_complete` → `parse_raw_components` → `solve_nodal` →
  `find_output_voltage`) and the result (valid/invalid reason, Vout amplitude/phase) is printed.
  No oscilloscope model in this phase.

## 1. Files

```
blender_sim/
  __init__.py            (written by lead)  bl_info, register(), unregister(), reload support
  board_layout.py        (written by lead)  BoardLayout, Hole, pin/net helpers — read it
  materials.py           (Agent A)          PBR material factory with cache
  scene_builder.py       (Agent A)          build_scene(), BUTTONS, object names
  component_meshes.py    (Agent B)          spawn_component(), COMPONENT_INFO, remove_component()
  netlist.py             (Agent C)          scene walk → raw list, formatting/printing, backend bridge
  interaction.py         (Agent D)          operators, modal session, HUD, N-panel, scene props
build_scene.py           (lead)  headless: build + save breadboard_sim.blend
start_sim.py             (lead)  run inside Blender: register + build if needed + start session
launch_blender.sh        (lead)  launches Blender from Terminal so print() is visible
tests/                   unit tests (system python) + headless Blender smoke tests
```

All modules use **relative imports** inside the package (`from . import board_layout`), and must be
importable with `importlib.reload`. Never import `bpy` at module level in `board_layout.py`.
Other modules may `import bpy`, `bmesh`, `mathutils`.

## 2. Scene conventions

* **Units:** 1 Blender unit = 1 mm. `scene.unit_settings.system='METRIC'`, `scale_length=0.001`,
  `length_unit='MILLIMETERS'`. All coordinates below are mm.
* **Frame:** from `board_layout.py`: board centred at the origin, top surface at `BOARD_TOP_Z = 0`.
  Columns along +Y (column 1 at −Y, nearest the camera). LHS strip at −X, RHS strip at +X,
  centre channel at X = 0. Rails outside each strip (VCC outermost, GND inner). Board extents via
  `layout.x_min/x_max/y_min/y_max`. The bench top is at z = `-(BOARD_THICKNESS + CARRIER_THICKNESS)`.
* **Collections:** `SIM_Env` (bench, lights, camera), `SIM_Board` (board, carrier, rails, labels),
  `SIM_UI` (button panel, buttons, markers), `SIM_Components` (everything the student places).
  `scene_builder.get_collection(name)` creates/returns them (linked to `scene.collection`).
* **Object name prefixes** (the runtime filters on these):
  | Prefix | Meaning | Deletable by student |
  |---|---|---|
  | `BOARD_` | breadboard body/holes/carrier/channel | no |
  | `RAIL_` | pre-wired rail jumpers, binding posts | no |
  | `LBL_` | text labels | no |
  | `BTN_` | clickable 3D mode buttons (root object carries `arms`) | no |
  | `PANEL_` | button panel base | no |
  | `UI_` | markers / helpers (hover marker, endpoint-A marker) | no |
  | `BENCH_`, `CAM_`, `LIGHT_` | environment | no |
  | `COMP_` | placed resistor/capacitor/inductor root object | **yes** |
  | `WIRE_` | placed jumper wire root object | **yes** |
  | `PROBE_` | placed probe root object | **yes** |
* **Custom properties** (ID props: only int/float/str/homogeneous lists allowed):
  * Board body `BOARD_breadboard`: `sim_role="BOARD"`, `layout="STANDARD"|"END_TO_END"`, `pitch`,
    `columns`, `rows="abcde"`, `board_top_z` (from `BoardLayout.to_params()`).
  * Button root: `sim_role="BUTTON"`, `arms=<mode key>`, `label=<text>`.
  * Placed item root: `sim_role="COMPONENT"|"WIRE"|"PROBE"`, `comp_type=<key>` (`"RESISTOR1"`,
    …, `"WIRE"`, `"PROBE"`), `pin_a=<pin str>`, `pin_b=<pin str>`, `pin_a_xyz=[x,y,z]`,
    `pin_b_xyz=[x,y,z]`, `uid=<int>`. Children of a root may exist; the runtime always climbs to
    the root via `obj.parent` until an object with `sim_role` is found.
  * Fixed rail jumpers: `sim_role="RAIL"`, `rail="VCC"|"GND"`, `hole=<pin str of the rail hole>`.
* **Pin strings:** `"VCC"`, `"GND"`, or `f"{logical_col}{row}"` (e.g. `"65c"`). Convert with
  `board_layout.string_to_net` / `net_to_string`. Netlist rows use nets: `"VCC"`, `"GND"`,
  `(65, "c")`.

## 3. Mode keys and component palette (from the backend — do not rename)

| key | class/value (Breadboard_Circuit_Parser.CLASS_NAME) | label | accent colour |
|---|---|---|---|
| `RESISTOR1` | Resistor 250 Ω | `R 250Ω` | tan body, bands red-green-brown |
| `RESISTOR2` | Resistor 500 Ω | `R 500Ω` | bands green-black-brown |
| `RESISTOR3` | Resistor 1000 Ω | `R 1kΩ` | bands brown-black-red |
| `CAPACITOR1` | Capacitor 0.47 µF | `C 0.47µF` | ceramic disc, orange/tan |
| `CAPACITOR2` | Capacitor 47 µF | `C 47µF` | ceramic disc, orange/tan (same mesh as CAPACITOR1) |
| `CAPACITOR3` | Capacitor 470 µF | `C 470µF` | ceramic disc, orange/tan (same mesh as CAPACITOR1) |
| `INDUCTOR1` | Inductor 2.2 µH | `L 2.2µH` | small copper coil on ferrite |
| `INDUCTOR2` | Inductor 220 µH | `L 220µH` | medium coil |
| `INDUCTOR3` | Inductor 220 mH | `L 220mH` | large coil |
| `WIRE` | jumper (node merge) | `Jumper Wire` | coloured tube arc |
| `PROBE` | oscilloscope probe (`["PROBE", holeP, holeM]`) | `Probe` | yellow tip + black clip |
| `DELETE` | delete mode (not a component) | `Delete` | red |

`component_meshes.COMPONENT_INFO: dict[key, dict(label=..., value=..., unit=..., kind=...)]`
is the single place these labels/values live; `scene_builder` and `interaction` import it.
Mode keys are exposed as `interaction.MODE_KEYS` (ordered list of the 12 keys above).

## 4. `board_layout.py` (done) — what you use

```python
from .board_layout import (BoardLayout, DEFAULT_LAYOUT, Hole, PITCH, BOARD_TOP_Z, HOLE_DEPTH,
    HOLE_SIZE, BOARD_THICKNESS, CHANNEL, NET_VCC, NET_GND, RAIL_NETS, string_to_net, net_to_string,
    net_repr, span_mm, LAYOUT_STANDARD, LAYOUT_END_TO_END)
layout = BoardLayout()              # STANDARD
layout.holes                        # Sequence[Hole]; h.key, h.net, h.pin, h.x, h.y, h.z, h.kind, h.side
layout.hole((65,"c")) / layout.hole("65c") / layout.hole("VCC")
layout.nearest(x, y, tol=0.48*PITCH) -> Hole | None
layout.rail_x(side, net), layout.row_x(side,row), layout.column_y(col), layout.rail_holes(net, side)
layout.x_min/x_max/y_min/y_max/width/length, layout.channel_x_range()
layout.to_params() / BoardLayout.from_params(d) / layout.export_table()
```
The runtime obtains the layout with `netlist.get_layout(scene)` (reads `BOARD_breadboard` props,
falls back to `DEFAULT_LAYOUT`).

## 5. `materials.py` + `scene_builder.py` (Agent A)

```python
# materials.py
def get_material(name: str, base_color=(r,g,b,1), metallic=0.0, roughness=0.5,
                 emission_color=None, emission_strength=0.0, alpha=1.0) -> bpy.types.Material
    # cached by name in bpy.data.materials (reuse if exists); Principled BSDF; use_nodes=True.
PALETTE: dict[str, tuple]   # named colours used across the scene (board white, rail red/blue, ...)

# scene_builder.py
CARRIER_THICKNESS = 3.0
BENCH_Z = -(BOARD_THICKNESS + CARRIER_THICKNESS)
BUTTONS: list[dict]   # [{"key": "RESISTOR1", "label": "R 250Ω", "row": 0, "col": 0}, ...] 4 rows x 3 cols
def get_collection(name: str) -> bpy.types.Collection
def clear_sim_scene() -> None                  # removes all SIM_* collections and their objects + orphan data
def build_scene(layout: BoardLayout | None = None, *, clear: bool = True) -> dict
    # returns {"board": obj, "holes": obj, "carrier": obj, "panel": obj, "buttons": {key: obj},
    #          "marker_a": obj, "marker_hover": obj, "camera": obj, "layout": layout}
def set_button_armed(key: str | None) -> None  # visual state: armed button highlighted + pushed in 0.8 mm
def mesh_from_bmesh(name, bm, materials=()) -> bpy.types.Mesh   # helper others may reuse
def new_object(name, mesh_or_none, collection, location=(0,0,0)) -> bpy.types.Object
```
Requirements:
* Geometry built with `bmesh` / mesh data only — **no `bpy.ops`** (must work headless and from a modal).
* `BOARD_breadboard`: body from `layout.x_min..x_max`, `y_min..y_max`, z from `-BOARD_THICKNESS` to `0`,
  bevelled-looking edges optional; centre channel groove (`layout.channel_x_range()`, depth ~2 mm);
  red and blue rail lines; `BOARD_holes`: ONE mesh containing a dark square recess for every
  `layout.holes` entry (side `HOLE_SIZE`, from z = −1.8 to z = +0.02) — visually reads as holes;
  `BOARD_carrier`: plate under the board (board footprint + ~12 mm margin on X, + ~30 mm on +Y for the
  binding posts), dark green; `BENCH_top`: big plane at `BENCH_Z`.
* `RAIL_post_vcc`/`RAIL_post_gnd`: red/black binding posts on the carrier beyond +Y end;
  `RAIL_jumper_vcc_L`, `RAIL_jumper_gnd_L`, `RAIL_jumper_vcc_R`, `RAIL_jumper_gnd_R`: fixed tube
  jumpers from the posts to the first rail hole of each rail (props per §2). These are static.
* Labels (`LBL_`): row letters a–e at both ends of each strip; column numbers 1,5,10,…,60 along each
  strip's outer side; `+`/`−` at rail ends. Text objects (`FONT` curves) are fine — small, dark.
* Button panel: `PANEL_modes` slab to the +X side of the board (about x = 50…110, centred at y = 0),
  tilted ~18° toward the camera (rotation about X), with 12 `BTN_<key lower>` buttons (4 rows × 3
  cols, ~16 × 9 × 3 mm, 2 mm proud), each with a child `LBL_btn_<key>` text. Per-button material
  instances (so one can highlight) with the accent colours in §3; armed look = emissive highlight.
  Button root props: `sim_role="BUTTON"`, `arms=key`, `label=...`.
* Markers: `UI_marker_hover` (thin emissive ring/disc Ø 2.2 mm, z = 0.1) and `UI_marker_a` (brighter
  ring, z = 0.15), both in `SIM_UI`, initially hidden with `hide_set(True)` **and** moved under the
  board (z = −50) so ray_cast never cares about them.
* `CAM_main`: perspective camera framing the board + button panel from the −Y side, elevated;
  `scene.camera` set. Lights: 3 area lights (key/fill/rim) + world colour. Render engine
  `BLENDER_EEVEE`, bloom on. Scene units set as in §2. For every `SpaceView3D` in `bpy.data.screens`:
  `shading.type='MATERIAL'`, `clip_start=0.5`, `clip_end=5000`, `show_region_ui=True`.
* Write the board props (`BoardLayout.to_params()` + `sim_role="BOARD"`) on `BOARD_breadboard`.
* Idempotent: `build_scene()` with `clear=True` removes previous SIM objects first.
* Provide `if __name__ == "__main__": build_scene()` guarded for headless smoke use.

## 6. `component_meshes.py` (Agent B)

```python
COMPONENT_INFO = {  # §3 — labels/values; "kind" in {"RESISTOR","CAPACITOR","INDUCTOR","WIRE","PROBE"}
  "RESISTOR1": {"label": "R 250Ω", "kind": "RESISTOR", "value": 250.0, "unit": "Ω", "bands": ("red","green","brown")}, ...
  "WIRE": {"label": "Jumper Wire", "kind": "WIRE"}, "PROBE": {"label": "Probe", "kind": "PROBE"}}
def spawn_component(scene: bpy.types.Scene, comp_type: str, hole_a: Hole, hole_b: Hole, uid: int,
                    collection: bpy.types.Collection | None = None) -> bpy.types.Object
def remove_component(obj: bpy.types.Object) -> None     # removes root + children + orphan mesh data
def placed_root(obj) -> bpy.types.Object | None           # climb parents to the object carrying sim_role in
                                                          # {"COMPONENT","WIRE","PROBE"}; None otherwise
```
Requirements:
* Root object name: `COMP_{comp_type}_{uid:04d}`, `WIRE_{uid:04d}`, `PROBE_{uid:04d}`; props per §2
  (`sim_role`, `comp_type`, `pin_a`, `pin_b`, `pin_a_xyz`, `pin_b_xyz`, `uid`). Prefer a **single
  mesh object** per placed item (multiple material slots via `face.material_index`) so raycast/delete is
  simple; children are allowed but must be parented to the root.
* Geometry (all bmesh, mm): pin tips exactly at `hole.xyz` and sunk to `z = -HOLE_DEPTH`; leads Ø 0.6;
  lead height ~3.5 mm above the board; resistor body Ø 2.4 × length clamp(span−3, 2.6, 6.5) with 3 colour
  bands + gold band; if span < 5 mm stand the resistor vertically over hole A with the lead looping to B.
  Capacitor1: ceramic disc Ø 5 × 1.4 standing vertically at the midpoint; Capacitor2: can Ø 5 × 7 (axis Z);
  Capacitor3: can Ø 8 × 11 with a pale stripe; Inductors: ferrite core cylinder + copper helix tube
  (≥ 6 turns), sizes small/medium/large. Wire: tube Ø 1.0 along a smooth arc (quadratic/cubic Bézier
  sampled ~24 segments) from A to B, arc height clamp(0.25·span, 3, 14) mm; colour chosen by span like
  real jumper kits (e.g. ≤5 mm red, ≤10 yellow, ≤20 green, ≤40 blue, else black). Probe: yellow tip cone +
  barrel over hole A, black "ground clip" over hole B, and a thin black lead arcing from the barrel
  toward `(+120, 0, 25)` (off-board, where the scope will sit later).
* Keep meshes light (a few hundred faces each). Use `materials.get_material`.
* Must work headless; provide a `__main__`/test that spawns one of each type between sample holes and
  asserts names/props.

## 7. `netlist.py` (Agent C)

```python
def get_layout(scene) -> BoardLayout
def placed_objects(scene) -> list[bpy.types.Object]      # roots with sim_role in {COMPONENT,WIRE,PROBE}, sorted by uid
def build_raw(scene) -> list[list]      # [[comp_type, net_a, net_b], ...] e.g. ["RESISTOR1", (2,"c"), (4,"c")], ["WIRE","VCC",(1,"b")]
def format_components(raw) -> str       # EXACT style of the parser docstring:
    # components = [
    #     ["WIRE", 'VCC', (1,"b")],
    #     ["RESISTOR1", (2,"c"), (4,"c")],
    # ]
def print_components(scene, reason: str = "") -> str      # prints header "[BBSIM] components (N) — <reason>" + formatted list; returns the text
def solve(raw, amplitude: float, phase_deg: float, freq_hz: float) -> dict
    # {"ok": bool, "reason": str, "amp": float|None, "phase_deg": float|None, "v_nodes": list|None,
    #  "probe": tuple|None, "error": str|None}
def report(scene) -> dict               # build_raw + solve with scene.bbsim_* props; prints a one-line summary; returns result
def next_uid(scene) -> int              # increments scene["bbsim_next_uid"]
```
Backend bridge requirements:
* Import the user's files from the project root (parent of `blender_sim/`): add it to `sys.path`; before
  importing, if `import matplotlib` fails, install a **stub** `matplotlib` + `matplotlib.pyplot` module in
  `sys.modules` (no-op `figure/plot/xlim/ylim/minorticks_on/grid/show`), so `AC_Circuit_Solver` imports
  cleanly. **Do not modify the backend files.** Use `importlib` with reload-safety.
* `solve` mirrors `Breadboard_Circuit_Parser.__main__`: `check_complete(raw)` → if False: ok=False,
  reason "open circuit — VCC not connected to GND". Else `parse_raw_components(raw)` →
  `VoltageSource("V1", 1, 0, amplitude, phase_deg)` appended → `solve_nodal(comps, omega=2π·f)` →
  if probe is None: ok=False reason "no probe placed" (still return v_nodes); else guard index range and
  NaN: if either probe node index ≥ len(v_nodes) or the value is NaN → ok=False reason "probe on a floating
  node"; else `find_output_voltage(probe, v_nodes, omega)` → amp=mag, phase_deg=degrees(phi). Also detect
  a WIRE row whose two ends are both rails and different → reason "VCC wired directly to GND", ok=False.
  Catch every exception → ok=False, reason "solver error", error=str(e). Never raise into the UI.
* `format_components` must print nets exactly via `board_layout.net_repr` (`'VCC'`, `(2,"c")`).
* Provide `tests/test_netlist_format.py` (system python, bpy-free: test `format_components` and `solve`
  using a fake raw list, importing the backend through the same stub mechanism) — so factor the backend
  bridge into bpy-free functions (`netlist.py` may import bpy lazily inside the bpy-dependent functions).

## 8. `interaction.py` (Agent D)

Scene properties (registered on `bpy.types.Scene` in `register()`):
`bbsim_armed: StringProperty` (mode key or ""), `bbsim_running: BoolProperty`, `bbsim_status: StringProperty`
(last message for HUD/panel), `bbsim_pending: StringProperty` (pin str of endpoint A or ""),
`bbsim_amplitude: FloatProperty(default=12.0, min=0, max=24)`, `bbsim_phase: FloatProperty(default=0, min=-180, max=180)`,
`bbsim_frequency: FloatProperty(default=50.0, min=1, max=1e6)` — updates of the three source props call
`netlist.report(scene)`.

Operators (`bl_idname`): `bbsim.session` (modal; `bl_options={'REGISTER'}`), `bbsim.stop`, `bbsim.arm`
(`key: StringProperty`), `bbsim.clear_board` (deletes all placed items, prints list), `bbsim.print_list`,
`bbsim.solve`, `bbsim.build_scene` (calls `scene_builder.build_scene()`), `bbsim.place` (non-modal helper:
`comp_type`, `pin_a`, `pin_b` string props → spawns via `component_meshes.spawn_component` and prints —
used by tests and the panel), `bbsim.delete_item` (`name` prop).

Panel: `VIEW3D_PT_bbsim` in the sidebar (`bl_category="Breadboard Sim"`): Start/Stop session, armed mode,
12 mode buttons (`bbsim.arm` with key) laid out 3 per row with the armed one depressed, status text,
source amplitude/phase/frequency, Print list / Solve / Clear board / Rebuild scene.

Modal session `BBSIM_OT_session.modal()` rules:
* `invoke()`: `context.window_manager.modal_handler_add(self)`, set `scene.bbsim_running=True`, add a HUD
  draw handler (`POST_PIXEL`: armed mode, pending endpoint, status, hint line; `POST_VIEW`: rubber-band
  line from endpoint A to the hovered hole) — guard with `try/except` so headless import never breaks;
  `wm.event_timer_add(0.1)` for redraws is optional.
* Every event: if `not scene.bbsim_running` → clean up (remove draw handlers, hide markers, reset armed) and
  return `{'FINISHED'}`. If the mouse is not over a VIEW_3D **WINDOW** region (or is over that area's
  `UI`/`HEADER`/`TOOLS`/`TOOL_HEADER` regions) → `{'PASS_THROUGH'}`. Navigation events (MIDDLEMOUSE,
  wheel, trackpad/NDOF, any event with `alt`/`ctrl`/`shift`? — keep `shift` free for future) →
  `{'PASS_THROUGH'}`.
* `MOUSEMOVE`: compute the ray (`view3d_utils`), (1) `scene.ray_cast(depsgraph, origin, dir)`; (2) intersect
  with the board plane `z = BOARD_TOP_Z` and `layout.nearest(x, y)`; move `UI_marker_hover` to the hovered
  hole (unhide) or hide it; remember hovered button/object for highlight; `area.tag_redraw()`.
* `LEFTMOUSE PRESS`: resolve the click in this order:
  1. ray hit on a `BTN_` root (climb parents; has `arms`) → `arm(key)`; button push animation via
     `scene_builder.set_button_armed`.
  2. armed `DELETE` and hit object with `component_meshes.placed_root(obj)` → `remove_component`, print
     list + report, status "deleted COMP_…". Hit on anything else → status "cannot delete the breadboard".
  3. otherwise hole snapping: if `nearest` is None → status "no hole there"; if no mode armed → status
     "arm a component first"; if `pending` empty → set pending, show `UI_marker_a`; else if same hole →
     status "same hole — pick a different one" (reject, keep pending); else spawn (`netlist.next_uid`,
     `spawn_component`), clear pending, `print_components(scene, reason="placed …")`, `netlist.report`.
     For `PROBE`: remove any existing `PROBE_` first (single probe).
  Return `{'RUNNING_MODAL'}` for consumed clicks.
* `RIGHTMOUSE PRESS` or `ESC`: if pending → cancel pending; elif armed → disarm; else pass through.
* Keyboard shortcuts (PRESS): `R`/`C`/`L` arm RESISTOR/CAPACITOR/INDUCTOR of the current variant,
  `ONE/TWO/THREE` choose variant 1–3 (re-arm same kind), `W` WIRE, `P` PROBE, `X`/`DEL` DELETE.
* Never let an exception escape `modal()` — wrap the body, set status to the error, keep running.
* `stop()`: sets `bbsim_running=False`; the modal exits on its next event (also poke a redraw).

Helper functions to expose for tests: `arm(scene, key)`, `place(scene, comp_type, pin_a, pin_b) -> obj`,
`delete(scene, obj) -> bool`, `resolve_click(context, event) -> dict` (pure: `{"button": key|None,
"placed": obj|None, "hole": Hole|None, "hit_obj": obj|None}`).

## 9. Printing format (verbatim requirement)

After every placement/deletion the terminal shows:

```
[BBSIM] components (3) — placed RESISTOR1 (2,"c")->(4,"c")
components = [
    ["WIRE", 'VCC', (1,"b")],
    ["RESISTOR1", (2,"c"), (4,"c")],
    ["PROBE", (4,"c"), 'GND'],
]
[BBSIM] circuit: closed and valid | Vout = 7.4123 V ∠ -31.2°  @ 50.0 Hz  (source 12.0 V ∠ 0.0°)
```
or `[BBSIM] circuit: open circuit — VCC not connected to GND` / `no probe placed` / etc.

## 10. Testing expectations

* System python: `python3 tests/test_board_layout.py`, `python3 tests/test_netlist_format.py`.
* Headless Blender: `"/Applications/Blender.app/Contents/MacOS/Blender" -b --python tests/blender_smoke_test.py`
  must: register the package, `build_scene()`, place one of each component type via
  `interaction.place(...)`, print the list, delete one, assert object names/props and that the list
  reflects deletions, assert board/buttons are refused by `delete`, run `netlist.report`, and save a
  `.blend` to the scratch dir. Each agent adds their own tests to `tests/` and runs them.
