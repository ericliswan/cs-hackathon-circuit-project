# RESEARCH_NOTES — verified facts for the Blender breadboard simulator

Generated 2026-08-22 by the research workflow (assets + dimensions agent, Blender 4.1 API agent, adversarial verifier: **all API claims confirmed, no corrections**).

## 1. Real breadboard dimensions (830-point / BB830 class) — used by board_layout.py

- **overall_length**: 165.1
- **overall_width**: 54.6
- **overall_height**: 8.5
- **hole_pitch**: 2.54
- **hole_size**: 1
- **hole_shape**: square opening (approx. 1.0 mm; the BusBoard SB830 solderable twin drills 1.07 mm / 0.042 in; accepted wire 0.4–0.7 mm dia = 21–26 AWG; ProtoSupplies spec lists 'square hole') — treat 1.0 ± 0.15 mm as an estimate, no manufacturer publishes the plastic opening
- **columns**: 63
- **terminal_rows_per_strip**: 5
- **centre_channel_e_to_f_centre_distance**: 7.62
- **rail_pair_spacing**: 2.54
- **rail_to_nearest_terminal_row**: 7.62
- **rail_hole_grouping**: Each rail = 50 holes in 10 groups of 5; between groups one grid position is skipped (2.54 mm blank, so 5.08 mm centre-to-centre across a gap). Groups sit on terminal columns 3–7, 9–13, 15–19, 21–25, 27–31, 33–37, 39–43, 45–49, 51–55, 57–61; columns 1–2 and 62–63 have no rail holes. The metal strip is continuous across the gaps (electrically one rail per side, unless the board is a 'split-rail' variant). Confirmed by parsing Fritzing breadboard2.svg (pin3W..pin61Z) and by pixel analysis of the Pololu 830 top-down photo (detected groups at 0-based column indices 2–6, 8–12, 14–18, 20–24, 26–30, 33–37, 39–43, 45–49, 52–56, 58–62).
- **rails_aligned_with_columns**: Aligned (on the same 0.1 in grid as the terminal columns) on BB830 / MB-102-class boards — verified in the Fritzing RSR 03MB102 drawing (rail x = column x to 0.005 mm) and in the Pololu photo. Caveat: the Adafruit forum thread notes roughly half of all breadboard brands offset the rails by half a pitch (1.27 mm); model them aligned, as on the BB830.
- **notes**: Consensus values. Length 165.1 mm (6.50 in) is stated by BusBoard, Jameco, Twin, Pololu, DigiKey; MB-102 clones list 165–170 mm and Adafruit 163 mm — use 165.1. Width 54.6 mm (2.15 in) is BusBoard's metric figure; others give 2.1–2.2 in (53.3–55.9 mm) — ±1 mm brand spread. Height: BusBoard 8.5 mm (0.3 in); Adafruit/MB-102 listings say 9–10 mm including the adhesive/metal backplate — model 8.5–9.5. Grid (from the Fritzing drawing, which is an exact 0.1-in-grid rendering of an 03MB102 board, in mm from the board's long edge on a 53.34 mm drawing; add ~0.6 mm per edge for a 54.6 mm board): outer rail 2.54, inner rail 5.08, row j 12.70, i 15.24, h 17.78, g 20.32, f 22.86, [0.3 in channel], e 30.48, d 33.02, c 35.56, b 38.10, a 40.64, inner rail 48.26, outer rail 50.80; column 1 centre at x = 3.85 mm, column 63 at 161.33 mm (62 x 2.54 = 157.48 span); rail holes from x = 8.94 (col 3) to 156.26 (col 61). Layout is mirror-symmetric about the channel centreline (y = 26.67 on the drawing). e→f = 7.62 mm (0.300 in) verified both from the drawing and from the Pololu photo (≈2.9 pitches, perspective-limited). Rail-to-nearest-row 7.62 mm (3 pitches) is the drawing value; the photo measures ≈2.8–2.9 pitches (7.1–7.4 mm) and since the rail strips are separate snap-on pieces this varies by brand by up to ~0.5 mm — it has no electrical meaning, so 7.62 is the safe modelling value. Columns: the real board has 63 columns labelled 1–60 in steps of 5 (columns 61–63 unlabelled) and rows a–e / f–j; the spec's 'two halves each 1–60 with rows a–e' (120 x 5) is a logical layout, not a physical product — no asset will match it. 830 = 63 x 10 + 4 x 50. Hole opening ~1.0 mm square is an estimate (no manufacturer publishes it).

Sources:
- BusBoard BB830 datasheet Rev 7 (PDF): 630 + 4x50 tie points, white ABS body, black printed legend, phosphor bronze / nickel contacts, 21–26 AWG (0.4–0.7 mm) — https://www.busboard.com/documents/datasheets/BPS-DAT-(BB830)-Datasheet.pdf
- BusBoard BB830/BB830T product page: 6.5 x 2.2 x 0.3 in (165.1 x 54.6 x 8.5 mm), red & black rail legend — https://www.busboard.com/BB830T
- Mouser BB830 overview (via search): '63 vertical columns on top and 63 columns below, each column 5 connected holes' — https://www.mouser.com/datasheet/2/58/BPS-MAR-BB830_BB830T-001-6408.pdf
- DigiKey BB830 attributes: 6.50 x 2.20 in (165.1 x 55.9 mm), 126 five-point terminals, 4 buses, white — https://www.digikey.com/en/products/detail/busboard-prototype-systems/BB830/19200392
- Jameco WBU-202-R / BB830: 6.5 x 2.125 in; datasheet PDF (403 to fetch) — https://www.jameco.com/Jameco/Products/ProdDS/2125026.pdf
- Twin Industries TW-E41-1020 page + catalogue PDF: 2.14 x 6.5 in, 'Holes spaced 0.1" x 0.1"', 630 + 2x100 — https://twinind.com/index.php/products/prototyping-boards/solderless-breadboards/tw-e41-1020/
- Adafruit #239 Full Sized Premium Breadboard: 16.3 x 5.3 x 1 cm, 79 g, rails detach to 3.5 cm width — https://www.adafruit.com/product/239
- Handsontec MB102 datasheet PDFs: 55 x 170 x 10 mm (2.2 x 7 x 0.4 in) — https://handsontec.com/dataspecs/accessory/Breadboard-Full.pdf and http://www.handsontec.com/dataspecs/m102-830-bread-board.pdf
- Pololu #352 830-point breadboard: 6.5 x 2.125 in, '63 rows of pins', #22 wire max; top-down photo used for pixel measurement — https://www.pololu.com/product/352
- Electronix Express 03MB102: 6.5 x 2.1 in, phosphor bronze nickel-plated, 0.4–0.7 mm insertion, 0.8 mm metal plate — https://www.elexp.com/products/03mb102breadboards-solderless-model
- BusBoard SB830 solderable twin datasheet: holes on 0.1 in (2.54 mm) centres, 0.042 in (1.07 mm) holes — https://www.busboard.com/documents/datasheets/BPS-DAT-(SB830)-Datasheet.pdf
- Wikipedia 'Breadboard': 0.1 in (2.54 mm) pitch, 0.3 in (7.6 mm) DIP row separation, 5 clips per terminal strip, tin-plated phosphor bronze / nickel silver — https://en.wikipedia.org/wiki/Breadboard
- ProtoSupplies breadboard guide + 400 Pro spec: 2.54 mm X/Y, 0.3 in centre gap, square/round holes, ABS off-white, red/blue rail lines, 8.5 mm thick — https://protosupplies.com/guide-to-solderless-breadboards/
- SparkFun 'How to use a breadboard': 0.1 in pitch, 5-clip strips, ravine for DIPs, red/blue(black) rail stripes — https://learn.sparkfun.com/tutorials/how-to-use-a-breadboard/anatomy-of-a-breadboard
- EEVblog thread on the rail gap every 5th hole (continuous strip, manufacturing cut points) — https://www.eevblog.com/forum/chat/why-do-breadboards-have-a-gap-every-5th-hole-in-the-power-rails/
- Adafruit forum 'Offset breadboard power rails?': ~half of brands offset rails by half a row — https://forums.adafruit.com/viewtopic.php?t=32112
- Fritzing breadboard2.svg (RSR 03MB102) parsed for hole centres — https://github.com/fritzing/fritzing-parts/blob/master/svg/core/breadboard/breadboard2.svg
- mnemocron/SBB830 CC0 KiCad replica: 167.64 x 58.42 mm, 1 mm holes — https://github.com/mnemocron/SBB830

### Colours / look
- **body**: White / off-white ABS (BusBoard BB830 'white ABS'; MB-102 clones off-white/ivory; ProtoSupplies 'off-white'); sRGB approx #F1EFE8 with a slight matte roughness (~0.55)
- **hole_contact**: Square dark opening (~1 mm) with nickel-plated phosphor bronze spring clip visible inside — render as a near-black cavity (#2A2A2A) with a thin silver-grey metallic lip (#B8B8B8, metallic 1.0, roughness 0.35)
- **label_text**: Black printed legend (#1A1A1A): column numbers 1, 5, 10 … 60 along both outer terminal rows, row letters a–j at both ends, '+' in red and '−' in black/blue at rail ends
- **rail_plus_line**: Red continuous line along the outer edge of the + rail (≈ #E0242B); '+' marks in red at both ends
- **rail_minus_line**: Blue line on MB-102 / Pololu / Elegoo-style boards (≈ #1F4FC2, used by Fritzing too: #0000FF); BusBoard BB830 and Adafruit #239 use BLACK instead of blue — pick blue for the generic classroom look or black to match the BB830 datasheet

### Recommendation

Generate the board procedurally in bpy from the real dimensions and use assets only as look references. The decisive fact is that the spec's board (two halves each numbered 1–60 with rows a–e, i.e. a 120 x 5 logical grid with a physical gap between halves) is not any real product — a real BB830 is 63 columns x rows a–j with the 7.62 mm channel between e and f — so no open asset can be imported and have its holes reverse-engineered into the required table without first being cut apart and re-laid out, at which point you are rebuilding it anyway. Reverse-engineering also inherits each asset's unknown scale (only one Sketchfab model even claims 1:1), fused/decimated hole geometry, and a licence obligation (CC BY attribution or CC BY-SA share-alike) for the single most important object in the scene. Procedural generation is ~100 lines: a base slab (165.1 x 54.6 x 8.5 mm, or whatever length 2 x 60 columns at 2.54 mm plus a centre gap needs), one hole mesh (≈1.0 mm square cavity with a chamfered lip) instanced via an Array/Geometry Nodes setup at pitch 2.54 mm, rows at the measured offsets (a–e spaced 2.54 mm; rails 2.54 mm apart and 7.62 mm from row a; rail holes on the same column grid in groups of 5 with one skipped position), red/blue rail stripes and black text objects for the legend. Because the same script that places the instances writes the (logical_column, row) → (x, y, z) table, the coordinate table is exact by construction, the LHS→1–60 / RHS→61–120 mapping is emitted directly, and the board stays light for the live modal loop. If polish is wanted, open the CC0 BlenderKit breadboard (or the CC BY P0l15hC0w Sketchfab model) purely to copy materials, bevel sizes and the legend look, and use the CC BY-SA Fritzing breadboard2.svg as the 2D layout reference for stripe/legend placement — neither needs to ship in the project.

### Open-source breadboard assets surveyed (look references; none ships in the project)

| Asset | Licence | Format | Notes |
|---|---|---|---|
| [BlenderKit — "Breadboard" by Roland Schuller ("Electronics Breadboard full size 2.54mm")](https://www.blenderkit.com/asset-gallery-detail/85a896f7-81c8-4493-9778-c70b3a7d2a9c/) | CC0 (Creative Commons Zero) — free tier; confirm the badge inside the BlenderKit add-on, the web page redirected to a blendkit.com mirror | .blend (native Blender asset, 21,377 polys, 6.2 MiB; pulled in via the BlenderKit add-on or web download) | Full-size breadboard modelled at 2.54 mm pitch; hole count not stated on the page (presumably 830, 63 x a–j + 4 rails) — Best zero-friction import for Blender 4.1 (drag-drop from the add-on, materials included, no attribution burden). Verify scale by measuring two adjacent hole centres = 2.54 mm; count columns. Geometry is a visual model — hole positions would have to be reverse-engineered from vertices, and it will not match the spec's non-standard 2 x 60 x a–e layout. |
| [Sketchfab — "BREADBOARD" by P0l15hC0w](https://sketchfab.com/3d-models/breadboard-e12efacea6c84f62b112ecb1e0011288) | CC BY 4.0 (Sketchfab API licence slug "by"; downloadable = true) | Sketchfab download: glTF/GLB, USDZ, plus original source (authored in Blender) | "simple breadboard model… scaled in Blender metres, 1:1 size"; 25.9k tris / 13k verts; board size (830/400) not stated but appears full-size — Good: glTF imports natively into Blender 4.1 and the author claims 1:1 metric scale, so pitch should read 2.54 mm without rescaling (check). Requires attribution. Visual asset only; hole coordinates must be extracted from mesh. |
| [Sketchfab — "Breadboard" by VirtualUniversity](https://sketchfab.com/3d-models/breadboard-49f5ff2407f14b8da36e00d25cffa26d) | CC BY 4.0 (Sketchfab licence "CC Attribution"; downloadable) | Sketchfab download: glTF/GLB, USDZ (+ original Cinema4D source if provided) | "Realistic 3D model of a standard breadboard… colour-coded strips"; 82.8k tris / 45k verts; size (830/400) not stated — Usable but heavier (83k tris) and scale is unknown (Cinema4D origin) — must be rescaled so hole pitch = 2.54 mm. Attribution required. Good for look-reference renders; not a coordinate source. |
| [Sketchfab — "[CC0] Set of Electronic Components" by literallylara](https://sketchfab.com/3d-models/cc0-set-of-electronic-components-f4cb777b4ea3490587008e24b61bcf75) | Sketchfab licence field = CC BY 4.0 (the title says CC0 but the binding badge/API value is "CC Attribution" — treat as CC BY and credit) | .blend (native, modifiers intact), plus Sketchfab glTF/USDZ | Low-poly set: mini breadboard (80 x 60 x 8 mm, 2.5 mm socket spacing — NOT 2.54), axial resistor, ceramic/cylindric/foil capacitors, LED, radial inductor, diodes, TO-220/TO-92; 28k tris total — Wrong board (mini) and wrong pitch (2.5 mm) — skip it for the board, but the resistor/capacitor/inductor meshes are a handy CC-licensed starting point for §5.4 component models (scale by 1.016 to the 2.54 grid). |
| [Fritzing core part — breadboard2.svg / breadboard2.fzp ("RSR 03MB102 Breadboard", size full+)](https://github.com/fritzing/fritzing-parts/blob/master/svg/core/breadboard/breadboard2.svg) | CC BY-SA 3.0 Unported (fritzing-parts LICENSE.txt: all graphics licensed CC BY-SA 3.0) | SVG (2D, 72 px/in Illustrator export) + .fzp connector XML; siblings breadboard.svg, halfBreadboard.svg, miniBreadboard.svg | Full-size 830-point board: 63 columns x rows A–J (630) + 4 rails x 50 (pin3W..pin61Z). Every hole is a named <g id="pinNNX"> with a circle centre — parsed: pitch exactly 2.54 mm, e→f 7.62 mm, rail pair 2.54 mm, inner rail→nearest row 7.62 mm, canvas 165.18 x 53.34 mm — Not a mesh, but the single best open source of exact, named hole coordinates — parse the SVG with ~15 lines of Python (done during this research) or import into Blender 4.1 via File > Import > SVG as a reference plane/texture. ShareAlike only bites if you redistribute derived graphics. |
| [mnemocron/SBB830 — KiCad PCB replica of the BB830 layout](https://github.com/mnemocron/SBB830) | CC0 (README: "Released to the Public Domain under CC0 License"; no LICENSE file, so the README statement is the grant) | KiCad .kicad_pcb (+ PNG renders); exportable from KiCad to STEP/VRML | Solderable PCB with all 830 holes positioned as an "Exact Solderless Match" to the 830 breadboard: 167.64 x 58.42 mm, 1 mm (40 mil) holes, M3 mounts — Not a plastic-board mesh, but a CC0 cross-check of the 830 hole layout: read hole positions straight from the .kicad_pcb text, or export STEP and bring it into Blender through FreeCAD. Useful for validating a procedurally generated table. |
| [farTooOld/Kicad_BreadBoard — breadboard + jumper STEP/FreeCAD models for KiCad](https://github.com/farTooOld/Kicad_BreadBoard) | GPL-3.0 (LICENSE file in repo; open but copyleft on redistribution) | STEP (BB_81x53.step, BB_Mini_*.step), FreeCAD source files, KiCad footprints/symbols | Half-size 400-point (81 x 53 mm) and mini 170-point boards plus coloured jumper wires; author notes dimensions are "based on my hardware… within a few millimetres" — no 830 board — Low-medium: no full-size board, dimensions self-admittedly approximate, and STEP needs FreeCAD (or a STEP import add-on) to reach Blender 4.1. The FreeCAD jumper-wire models are the more reusable bit. |
| [Thingiverse/Printables — "Customizable Parametric OpenSCAD Breadboard" by TickyTacky](https://www.thingiverse.com/thing:3057115) | CC BY-NC-SA 4.0 (from the page's license metadata) — FLAG: NonCommercial + ShareAlike, so not fully open; acceptable for a university practical but check institutional policy. Mirror: https://www.printables.com/model/210324-customizable-parametric-openscad-breadboard | .scad (parametric) + example STL | 3D-printable breadboard generator: parameters for pin rows, pin columns, pin spacing, pin grouping and optional power terminals — can be set to 63 x 10 + rails, or to the spec's 2 x 60 x 5 layout — OpenSCAD → STL → Blender 4.1 imports cleanly and the hole grid is exact by construction, but the geometry is print-oriented (thick walls, no contacts, no legend) and the NC licence is a caveat. More useful as a reference for how to parameterise than as the asset. |
| [Cults3D — "BREADBOARD 830 TIE POINTS DIY" by JUANFIEE](https://cults3d.com/en/3d-model/tool/full-sized-premium-breadboard-830-tie-points) | NOT OPEN — Cults "Private Use" (PU) licence: free download, but no redistribution/derivative rights | 2 x STL (top and bottom shells) | Full-size 830-point board, 2.2 x 7 in (55 x 170 mm), print-in-place — Flagged: licence does not permit reuse in a distributed project. Do not use. |
| [GrabCAD — "830 Tie Points Breadboard"](https://grabcad.com/library/830-tie-points-breadboard-1) | NOT OPEN — GrabCAD Community default terms (non-exclusive, no Creative Commons grant) | Various CAD (STEP/SolidWorks etc.) | Full-size 830 breadboard CAD model — Flagged: GrabCAD's default terms are not an open licence. Use only as a visual reference you do not redistribute. |
| [gedobbles/breadview — OpenSCAD breadboard visualisation library](https://github.com/gedobbles/breadview) | NO LICENSE FILE (GitHub API license = null) — all rights reserved by default; FLAG | breadview.scad + example.scad | Renders breadboard layouts in OpenSCAD — Flagged: unlicensed, 2 stars, last push 2020. Not usable without contacting the author. |

## 2. Blender 4.1 Python API — verified answers (Q1–Q15)

### Q1  (verified: True; source: headless run (probe_q1.py) + https://docs.blender.org/api/4.1/bpy.types.Scene.html ('ray_cast(depsgraph, origin, direction, distance=1.70141e+38) ... Return (result, location, normal, index, object, matrix)'))

Signature (4.1): Scene.ray_cast(depsgraph, origin, direction, distance=1.70141e+38) -> (result: bool, location: Vector, normal: Vector, index: int, object: Object, matrix: Matrix 4x4). 6-tuple. First arg MUST be a Depsgraph (passing a ViewLayer raises TypeError: 'Function.depsgraph expected a Depsgraph type, not ViewLayer'). Keyword call works: scene.ray_cast(depsgraph=dg, origin=..., direction=...). EMPIRICAL results (cube size 1, ray from z=10 straight down): (a) obj.hide_set(True) -> NOT hit (hit=False). (b) obj.hide_viewport=True -> NOT hit. (hide_render=True -> still hit.) (c) FONT text object -> HIT (both with extrude=0.1 and flat extrude=0; hit obj=txt). CURVE with bevel_depth=0.2 -> HIT. CURVE with no bevel (zero-area wire) -> NOT hit. Ray cast works on evaluated geometry from the depsgraph so anything that produces faces (text, bevelled curves) is hit; hidden objects (either hide_set or hide_viewport) are excluded.

```python
import bpy
from mathutils import Vector
dg = bpy.context.evaluated_depsgraph_get()
hit, loc, nrm, face_idx, ob, mat = bpy.context.scene.ray_cast(dg, Vector((0,0,10)), Vector((0,0,-1)), distance=100.0)
# hit: bool; ob: original Object (None if miss); loc/nrm world space; face_idx: evaluated face index
# results (4.1.0): visible cube hit=True; hide_set(True) hit=False; hide_viewport=True hit=False;
# hide_render=True hit=True; FONT obj hit=True (extrude 0 or 0.1); CURVE bevel_depth=0.2 hit=True; CURVE no bevel hit=False
```

### Q2  (verified: True; source: GUI run (probe_gui2.py, Blender 4.1.0 foreground, self-quitting) + https://docs.blender.org/api/4.1/bpy_extras.view3d_utils.html ('region_2d_to_origin_3d(region, rv3d, coord, *, clamp=None)', 'region_2d_to_vector_3d(region, rv3d, coord) ... coord: 2d coordinates relative to the region: (event.mouse_region_x, event.mouse_region_y) for example', 'rv3d ... typically bpy.context.space_data.region_3d') + https://docs.blender.org/api/4.1/bpy.types.Event.html ('mouse_x: The window relative horizontal location of the mouse', 'mouse_region_x: The region relative horizontal location') + https://docs.blender.org/api/4.1/bpy.types.Region.html ('x: The window relative vertical location of the region'))

event.mouse_x/mouse_y are WINDOW-relative; region.x/region.y are the region's window-relative origin, so region-local coords = (event.mouse_x - region.x, event.mouse_y - region.y) (equals event.mouse_region_x/y only when context.region is the WINDOW region). Then bpy_extras.view3d_utils.region_2d_to_origin_3d(region, rv3d, coord, *, clamp=None) and region_2d_to_vector_3d(region, rv3d, coord) give the ray; rv3d = area.spaces.active.region_3d (same object as context.region_data inside the modal, verified). Region overlap: verified in 4.1 GUI run with use_region_overlap=True that the WINDOW region covers the whole area (x,y,w,h = 0,183,2825,1686) and the UI (N-panel) region (2384,183,441,1582), TOOLS (0,183,113,1582), HEADER (0,1817,2825,52), TOOL_HEADER (0,1765,2825,52) all lie INSIDE the WINDOW rect; unused regions (HUD, ASSET_SHELF...) have width/height 1. So hit-test every region of the VIEW_3D area by rect, ignore regions with width<=1 or height<=1, and treat any non-WINDOW region containing the mouse as 'over UI' -> return {'PASS_THROUGH'}. Verified region_under() returned WINDOW for the mouse over the viewport, UI for the centre of the N-panel rect, HEADER for the header. Note the UI region rect is only meaningful when space.show_region_ui is True (if the N-panel is hidden the region's width is 1). Inside the modal, context.area/context.region already point at the VIEW_3D WINDOW region the operator was invoked in (verified ctx.area=VIEW_3D ctx.region=WINDOW on every event, even mouse moves elsewhere), so use the area-scan approach below rather than relying on context.region to detect what is under the mouse.

```python
from bpy_extras import view3d_utils

def view3d_under_mouse(context, event):
    """Return (area, region, rv3d, region_type_under_mouse) for the VIEW_3D under the mouse, or (None,)*4."""
    mx, my = event.mouse_x, event.mouse_y          # window-relative
    for area in context.screen.areas:
        if area.type != 'VIEW_3D':
            continue
        if not (area.x <= mx < area.x + area.width and area.y <= my < area.y + area.height):
            continue
        win_region = next(r for r in area.regions if r.type == 'WINDOW')
        rv3d = area.spaces.active.region_3d         # == context.region_data when invoked in that region
        under = [r.type for r in area.regions
                 if r.width > 1 and r.height > 1
                 and r.x <= mx < r.x + r.width and r.y <= my < r.y + r.height
                 and r.type != 'WINDOW']              # UI / TOOLS / HEADER / TOOL_HEADER overlap WINDOW
        return area, win_region, rv3d, (under[0] if under else 'WINDOW')
    return None, None, None, None

def mouse_ray(region, rv3d, event):
    coord = (event.mouse_x - region.x, event.mouse_y - region.y)   # region-local 2D
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)  # normalized
    return origin, direction

# in modal():
#   area, region, rv3d, rtype = view3d_under_mouse(context, event)
#   if region is None or rtype != 'WINDOW': return {'PASS_THROUGH'}   # over N-panel/header/toolbar/other editor
#   o, d = mouse_ray(region, rv3d, event)
#   hit, loc, nrm, idx, ob, mat = context.scene.ray_cast(context.evaluated_depsgraph_get(), o, d)
```

### Q3  (verified: True; source: GUI run (probe_gui2.py: modal_handler_add, 295 events, stop-flag -> FINISHED, draw counts 1 vs 40 with tag_redraw, TIMER events) + headless run (Operator.modal return enum, Event.type enum, event_timer_add params ['time_step','window']) + https://docs.blender.org/api/4.1/bpy.types.Operator.html (Modal Execution example: 'context.window_manager.modal_handler_add(self); return {'RUNNING_MODAL'}'))

Verified in a real 4.1.0 GUI session: invoke() calls context.window_manager.modal_handler_add(self) and returns {'RUNNING_MODAL'}; modal() return enum is exactly ['RUNNING_MODAL','CANCELLED','FINISHED','PASS_THROUGH','INTERFACE']. The modal received every window event (MOUSEMOVE, INBETWEEN_MOUSEMOVE, TIMER, NONE) regardless of where the mouse was; returning {'PASS_THROUGH'} hands the event on to the normal handlers (navigation, UI buttons), which is the documented semantics ('Pass Through: Do nothing and pass the event on'), so sidebar buttons stay clickable as long as you return PASS_THROUGH for events whose mouse position is outside the WINDOW region / over the UI region (Q2 test) and for MIDDLEMOUSE / WHEELUPMOUSE / WHEELDOWNMOUSE / TRACKPADPAN / TRACKPADZOOM / MOUSEROTATE / MOUSESMARTZOOM / NDOF_MOTION and any event with event.alt or event.ctrl (all these type names confirmed in the 4.1 Event.type enum). (Actual button clicks were not simulated; region detection and event delivery were.) Ending from outside: a flag on the window manager (wm['probe_stop'] = True set by a timer; a 'Stop' button operator does the same) was seen on the next event and the modal returned {'FINISHED'} after 295 events - works. Redraw: draw handlers were called only ONCE in 3 s without tag_redraw (no events that trigger a redraw), and 40 times in the following 4 s once the modal called area.tag_redraw() on each TIMER event - so context.area.tag_redraw() IS needed for the HUD to refresh, and wm.event_timer_add(0.1, window=context.window) IS needed for periodic refresh when the mouse is idle (timer events arrive as event.type == 'TIMER'; remove with wm.event_timer_remove(timer) in cancel/finish). Also verified: self.report({'INFO'}, ...) from invoke printed 'Info: probe modal started'.

```python
import bpy

class SIM_OT_session(bpy.types.Operator):
    bl_idname = "sim.session"; bl_label = "Simulator Session"
    NAV = {'MIDDLEMOUSE','WHEELUPMOUSE','WHEELDOWNMOUSE','TRACKPADPAN','TRACKPADZOOM',
           'MOUSEROTATE','MOUSESMARTZOOM','NDOF_MOTION'}

    def invoke(self, context, event):
        wm = context.window_manager
        wm['sim_stop'] = False
        self._timer = wm.event_timer_add(0.1, window=context.window)   # periodic 'TIMER' events
        self._hud = bpy.types.SpaceView3D.draw_handler_add(draw_hud, (), 'WINDOW', 'POST_PIXEL')
        wm.modal_handler_add(self)
        self.report({'INFO'}, "session started")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        wm = context.window_manager
        if wm.get('sim_stop'):                       # set by a 'Stop' button operator / timer
            self.finish(context); return {'FINISHED'}
        if event.type == 'TIMER':
            context.area.tag_redraw()                # needed: HUD only redraws when something tags it
            return {'PASS_THROUGH'}
        if event.type in self.NAV or event.alt or event.ctrl:
            return {'PASS_THROUGH'}                  # let viewport navigation through
        area, region, rv3d, rtype = view3d_under_mouse(context, event)   # from Q2
        if region is None or rtype != 'WINDOW':
            return {'PASS_THROUGH'}                  # over N-panel/header/other editor: UI stays clickable
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            ...  # handle click (ray_cast)
            context.area.tag_redraw(); return {'RUNNING_MODAL'}
        if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.finish(context); return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def finish(self, context):
        context.window_manager.event_timer_remove(self._timer)
        bpy.types.SpaceView3D.draw_handler_remove(self._hud, 'WINDOW')
        for a in context.screen.areas: a.tag_redraw()
    cancel = finish  # called by Blender if the operator is cancelled externally

class SIM_OT_stop(bpy.types.Operator):
    bl_idname = "sim.stop"; bl_label = "Stop"
    def execute(self, context):
        context.window_manager['sim_stop'] = True; return {'FINISHED'}
```

### Q4  (verified: True; source: GUI run (probe_gui2.py) + https://docs.blender.org/api/4.1/gpu.shader.html (built-in list: 'UNIFORM_COLOR Attributes: vec3 pos Uniforms: vec4 color'; 'POLYLINE_UNIFORM_COLOR Attributes: vec3 pos Uniforms: vec2 viewportSize, float lineWidth') + https://docs.blender.org/api/4.1/gpu.html ('3D Lines with Single Color' example uses gpu.shader.from_builtin('UNIFORM_COLOR') and batch_for_shader(shader, 'LINES', {"pos": coords}) with draw_handler_add(draw, (), 'WINDOW', 'POST_VIEW')) + https://docs.blender.org/api/4.1/blf.html ('blf.size(fontid, size) ... size (float) - Point size of the font'))

Verified in a real 4.1.0 GUI session inside draw handlers (Metal backend). (a) bpy.types.SpaceView3D.draw_handler_add(cb, (), 'WINDOW', 'POST_PIXEL') works; blf.size(font_id, size) takes exactly 2 args - blf.size(0, 20, 72) raises 'TypeError: blf.size() takes exactly 2 arguments (3 given)' (dpi argument is gone); blf.position(fontid, x, y, z), blf.color(fontid, r, g, b, a), blf.draw(fontid, text), blf.dimensions(fontid, text) -> (width, height) all worked. (b) Valid builtin shader names in 4.1 are exactly ('FLAT_COLOR', 'IMAGE', 'IMAGE_COLOR', 'SMOOTH_COLOR', 'UNIFORM_COLOR', 'POLYLINE_FLAT_COLOR', 'POLYLINE_SMOOTH_COLOR', 'POLYLINE_UNIFORM_COLOR') - the old '3D_UNIFORM_COLOR', '2D_UNIFORM_COLOR', '3D_POLYLINE_UNIFORM_COLOR' raise ValueError ('expected a string in (...)'). UNIFORM_COLOR: attribute 'pos', uniform 'color' (vec4); drawing 'LINES' and 'LINE_STRIP' batches with gpu.state.line_width_set(3.0) worked. POLYLINE_UNIFORM_COLOR: attribute 'pos', uniforms 'viewportSize' (vec2), 'lineWidth' (float), plus 'color' (vec4) - setting all three worked; 'lineSmooth' is also accepted; unknown names raise 'ValueError: GPUShader.uniform_float: uniform bogus not found'. batch_for_shader(shader, type, content, *, indices=None) accepts 'LINES' and 'LINE_STRIP'. gpu.shader.from_builtin raises SystemError 'GPU API is not available in background mode' when called in -b, so shaders must be created lazily inside the draw callback (or after startup in GUI).

```python
import bpy, gpu, blf
from gpu_extras.batch import batch_for_shader

# (a) 2D HUD text
def draw_hud():
    font_id = 0
    blf.size(font_id, 20)                 # 4.x: (fontid, size) only - no dpi argument
    blf.position(font_id, 20, 40, 0)
    blf.color(font_id, 1.0, 1.0, 0.0, 1.0)
    blf.draw(font_id, "HUD text")
    w, h = blf.dimensions(font_id, "HUD text")
hud_handle = bpy.types.SpaceView3D.draw_handler_add(draw_hud, (), 'WINDOW', 'POST_PIXEL')

# (b) 3D rubber-band line
STATE = {'pts': [(0,0,0), (1,1,1)]}
def draw_line():
    # simple: fixed-function line width
    sh = gpu.shader.from_builtin('UNIFORM_COLOR')      # NOT '3D_UNIFORM_COLOR' in 4.x
    batch = batch_for_shader(sh, 'LINES', {"pos": STATE['pts']})
    gpu.state.line_width_set(3.0)
    sh.bind(); sh.uniform_float("color", (1, 0, 0, 1)); batch.draw(sh)
    gpu.state.line_width_set(1.0)
    # wide anti-aliased polyline
    sh2 = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    batch2 = batch_for_shader(sh2, 'LINE_STRIP', {"pos": STATE['pts']})
    region = bpy.context.region
    sh2.bind()
    sh2.uniform_float("viewportSize", (region.width, region.height))   # required
    sh2.uniform_float("lineWidth", 4.0)                                # required
    sh2.uniform_float("color", (0, 1, 0, 1))
    batch2.draw(sh2)
line_handle = bpy.types.SpaceView3D.draw_handler_add(draw_line, (), 'WINDOW', 'POST_VIEW')
# remove: bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
```

### Q5  (verified: True; source: headless run (probe_q5_6_7_9_11_14.py))

EMPIRICAL 4.1.0 input names of a fresh ShaderNodeBsdfPrincipled (use_nodes=True default node): ['Base Color', 'Metallic', 'Roughness', 'IOR', 'Alpha', 'Normal', 'Weight', 'Subsurface Weight', 'Subsurface Radius', 'Subsurface Scale', 'Subsurface IOR', 'Subsurface Anisotropy', 'Specular IOR Level', 'Specular Tint', 'Anisotropic', 'Anisotropic Rotation', 'Tangent', 'Transmission Weight', 'Coat Weight', 'Coat Roughness', 'Coat IOR', 'Coat Tint', 'Coat Normal', 'Sheen Weight', 'Sheen Roughness', 'Sheen Tint', 'Emission Color', 'Emission Strength']. Identifiers equal the names. All of 'Base Color','Metallic','Roughness','IOR','Alpha','Emission Color','Emission Strength','Coat Weight','Sheen Weight','Subsurface Weight','Specular IOR Level' exist. (Old names 'Specular', 'Emission', 'Clearcoat', 'Sheen', 'Subsurface', 'Transmission' do NOT exist.) 'Base Color' default_value is RGBA (4 floats).

```python
mat = bpy.data.materials.new("M"); mat.use_nodes = True
pb = mat.node_tree.nodes["Principled BSDF"]      # created automatically, linked to 'Material Output'
pb.inputs['Base Color'].default_value = (1.0, 0.0, 0.0, 1.0)
pb.inputs['Metallic'].default_value = 0.8
pb.inputs['Roughness'].default_value = 0.3
pb.inputs['Emission Color'].default_value = (0, 1, 0, 1)
pb.inputs['Emission Strength'].default_value = 2.0
pb.inputs['Alpha'].default_value = 1.0
```

### Q6  (verified: True; source: headless run (probe_q5_6_7_9_11_14.py))

Verified headless: cu = bpy.data.curves.new(name, 'FONT') returns a TextCurve; cu.body, cu.align_x (enum LEFT/CENTER/RIGHT/JUSTIFY/FLUSH), cu.align_y (TOP/TOP_BASELINE/CENTER/BOTTOM_BASELINE/BOTTOM), cu.size, cu.extrude all settable; obj = bpy.data.objects.new(name, cu) gives obj.type == 'FONT'; link with scene.collection.objects.link(obj). Mesh conversion without bpy.ops: (1) ev = obj.evaluated_get(depsgraph); m = ev.to_mesh() -> temporary mesh owned by the evaluated object (832 verts / 608 polys for 'R1 10k' with extrude) - must call ev.to_mesh_clear() and must not keep it; (2) m = bpy.data.meshes.new_from_object(ev) -> a real persistent Mesh datablock (same counts) you can assign to a new object; kwargs preserve_all_data_layers=True, depsgraph=dg also accepted. new_from_object on the un-evaluated original also worked here (same counts) but passing the evaluated object is the documented form. obj.dimensions of the text object is available after view_layer.update().

```python
import bpy
scene = bpy.context.scene
cu = bpy.data.curves.new("LabelCurve", 'FONT')   # TextCurve
cu.body = "R1 10k"; cu.align_x = 'CENTER'; cu.align_y = 'CENTER'
cu.size = 2.0; cu.extrude = 0.05
txt = bpy.data.objects.new("Label", cu)          # txt.type == 'FONT'
scene.collection.objects.link(txt)
bpy.context.view_layer.update()

# convert to a persistent mesh datablock (no bpy.ops)
dg = bpy.context.evaluated_depsgraph_get()
ev = txt.evaluated_get(dg)
mesh = bpy.data.meshes.new_from_object(ev)        # new Mesh datablock
mesh_obj = bpy.data.objects.new("LabelMesh", mesh); scene.collection.objects.link(mesh_obj)
mesh_obj.matrix_world = txt.matrix_world

# or read-only temporary access:
tmp = ev.to_mesh(); n = len(tmp.polygons); ev.to_mesh_clear()
```

### Q7  (verified: True; source: headless run (probe_q5_6_7_9_11_14.py))

EMPIRICAL 4.1.0: allowed: int, float, str, bool, None, homogeneous lists/tuples of ints or floats (stored as IDPropertyArray; [1, 2.5] is promoted to a float array [1.0, 2.5]; empty list -> empty IDPropertyArray), lists of strings (stored and read back as a plain Python list ['a','b']), dicts (stored as IDPropertyGroup; read with .to_dict(); nested lists inside dicts fine). obj['pin_a'] = [5, 'c'] FAILS with 'TypeError: only floats, ints and dicts are allowed in ID property arrays'. obj['pin_a'] = '5c' works (str). obj['pin_a_xyz'] = [1.0, 2.0, 3.0] works and reads back as <bpy id property array [3]> (type IDPropertyArray) - convert with list(obj['pin_a_xyz']) -> [1.0, 2.0, 3.0]. Also: 'key' in obj, obj.get(key, default), obj.keys(), del obj[key] all work.

```python
ob['pin_a'] = '5c'                       # str OK
ob['pin_a_xyz'] = [1.0, 2.0, 3.0]        # -> IDPropertyArray
xyz = list(ob['pin_a_xyz'])              # [1.0, 2.0, 3.0]
ob['pins'] = {'a': 1, 'b': 'x'}          # -> IDPropertyGroup; ob['pins'].to_dict()
try:
    ob['bad'] = [5, 'c']                 # TypeError: only floats, ints and dicts are allowed in ID property arrays
except TypeError as e:
    print(e)
val = ob.get('missing', None)
```

### Q8  (verified: True; source: headless run (probe_q8.py, then probe_q8b.py re-opening the saved file))

Verified headless (-b, bpy.app.background True): after bpy.ops.wm.read_factory_settings(use_empty=True) there are 11 screens / 11 workspaces and 1 window; 10 SpaceView3D spaces were found across bpy.data.screens[*].areas[*].spaces. Setting space.shading.type='MATERIAL', space.clip_start=0.1, space.clip_end=10000.0, space.show_region_ui=True, space.overlay.show_floor=False and space.region_3d.view_perspective worked in background mode. bpy.ops.wm.save_as_mainfile(filepath=...) returned {'FINISHED'} (390 kB file). Re-opening the saved .blend (Blender -b file.blend --python ...) showed every VIEW_3D space still had shading=MATERIAL, clip 0.1/10000, show_region_ui=True, show_floor=False, the unit system METRIC and the Text datablock 'start.py' - the settings persist. Note scene.camera is None in the empty file (add a camera/light if rendering).

```python
import bpy
bpy.ops.wm.read_factory_settings(use_empty=True)
for screen in bpy.data.screens:
    for area in screen.areas:
        for space in area.spaces:
            if space.type == 'VIEW_3D':
                space.shading.type = 'MATERIAL'
                space.clip_start = 0.1
                space.clip_end = 10000.0
                space.show_region_ui = True
                space.overlay.show_floor = False
bpy.ops.wm.save_as_mainfile(filepath="/abs/path/sim.blend")   # {'FINISHED'}
```

### Q9  (verified: True; source: headless run (probe_q5_6_7_9_11_14.py))

Confirmed headless in 4.1.0: scene.unit_settings has properties ['system','system_rotation','scale_length','use_separate','length_unit','mass_unit','time_unit','temperature_unit']; system enum is NONE/METRIC/IMPERIAL. Setting system='METRIC', scale_length=0.001, length_unit='MILLIMETERS' succeeded and read back METRIC / 0.001 / MILLIMETERS (length_unit is a dynamic enum whose items depend on system; set system first).

```python
us = bpy.context.scene.unit_settings
us.system = 'METRIC'
us.scale_length = 0.001          # 1 BU = 1 mm
us.length_unit = 'MILLIMETERS'   # set AFTER system (dynamic enum)
```

### Q10  (verified: True; source: headless run (probe_q10.py))

Confirmed headless on macOS (Metal backend) with Blender 4.1.0: scene.render.engine enum is ('BLENDER_EEVEE', 'BLENDER_WORKBENCH', 'CYCLES'); default engine 'BLENDER_EEVEE'; assigning 'BLENDER_EEVEE_NEXT' raises TypeError 'enum "BLENDER_EEVEE_NEXT" not found in (...)' - so 4.1 uses 'BLENDER_EEVEE' (EEVEE Next / 'BLENDER_EEVEE_NEXT' is 4.2+). scene.eevee.use_bloom, use_gtao, use_ssr, use_ssr_refraction, taa_render_samples, use_soft_shadows, use_motion_blur, shadow_cube_size all exist (defaults bloom/gtao/ssr False, taa_render_samples 64). Headless EEVEE render of the default scene at 64x64 with bloom+gtao+ssr on: bpy.ops.render.render(write_still=True) -> {'FINISHED'}, PNG written (3161 bytes) in 4.4 s. WORKBENCH also works: {'FINISHED'}, PNG 3601 bytes, 3.5 s. gpu.platform.backend_type_get() reports 'METAL'. Both engines work in -b mode on this Mac; WORKBENCH is a valid fallback.

```python
sc = bpy.context.scene
sc.render.engine = 'BLENDER_EEVEE'            # 4.1 name ('BLENDER_EEVEE_NEXT' only in 4.2+)
sc.eevee.taa_render_samples = 16
sc.eevee.use_bloom = True; sc.eevee.use_gtao = True; sc.eevee.use_ssr = True
sc.render.resolution_x = sc.render.resolution_y = 64; sc.render.resolution_percentage = 100
sc.render.filepath = '/abs/path/out.png'
bpy.ops.render.render(write_still=True)       # {'FINISHED'} headless on macOS/Metal
# fallback: sc.render.engine = 'BLENDER_WORKBENCH'
```

### Q11  (verified: True; source: headless run (probe_q5_6_7_9_11_14.py))

Exact 4.1 signatures (from bmesh.ops docstrings, run headless): create_cone(bmesh, cap_ends=False, cap_tris=False, segments=0, radius1=0.0, radius2=0.0, depth=0.0, matrix=Matrix(), calc_uvs=False); create_cube(bmesh, size=0.0, matrix=Matrix(), calc_uvs=False); create_uvsphere(bmesh, u_segments=0, v_segments=0, radius=0.0, matrix=Matrix(), calc_uvs=False); create_circle(bmesh, cap_ends=False, cap_tris=False, segments=0, radius=0.0, matrix=Matrix(), calc_uvs=False); also create_icosphere(subdivisions, radius, matrix, calc_uvs), create_grid(x_segments, y_segments, size, matrix, calc_uvs), create_monkey(matrix, calc_uvs). Each returns a dict with key 'verts' (list of new BMVerts). Unknown keywords raise TypeError (e.g. 'create_cube: keyword "diameter" is invalid for this operator'). Built a mesh headless: cone + cube + uvsphere + circle in one BMesh, set face.material_index = 0 for the first primitive's faces and 1 for the rest, bm.to_mesh(mesh); bm.free(); mesh.update(); obj.data.materials.append(matA); .append(matB) -> two slots ['A','B'], polygon material_index set {0,1}, 73 polys / 94 verts, mesh.validate() False (valid).

```python
import bpy, bmesh
from mathutils import Matrix
bm = bmesh.new()
bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=16, radius1=0.5, radius2=0.2, depth=2.0, matrix=Matrix.Identity(4), calc_uvs=True)
n_body = len(bm.faces)
bmesh.ops.create_cube(bm, size=1.0, matrix=Matrix.Translation((3, 0, 0)), calc_uvs=True)
bmesh.ops.create_uvsphere(bm, u_segments=8, v_segments=6, radius=0.5, matrix=Matrix.Translation((-3, 0, 0)), calc_uvs=True)
bmesh.ops.create_circle(bm, cap_ends=True, cap_tris=False, segments=12, radius=0.4, matrix=Matrix.Translation((0, 3, 0)), calc_uvs=True)
bm.faces.ensure_lookup_table()
for i, f in enumerate(bm.faces):
    f.material_index = 0 if i < n_body else 1
mesh = bpy.data.meshes.new("Part"); bm.to_mesh(mesh); bm.free(); mesh.update()
ob = bpy.data.objects.new("Part", mesh); bpy.context.scene.collection.objects.link(ob)
ob.data.materials.append(bpy.data.materials.new("Body"))   # slot 0
ob.data.materials.append(bpy.data.materials.new("Pins"))   # slot 1
```

### Q12  (verified: True; source: GUI run (probe_gui2.py / probe_gui.py) + headless run (probe_q12_13.py: temp_override(window, area, region, **keywords); register(function, first_interval=0, persistent=False); timers do not fire in -b) + https://docs.blender.org/api/4.1/bpy.types.Context.html ('temp_override(window, area, region, **keywords) ... When overriding window, area and regions: the arguments must be consistent, so any region argument that's passed in must be contained by the current area or the area passed in') + https://docs.blender.org/manual/en/4.1/editors/text_editor.html ('Run Script Alt-P: Executes the text as a Python script'))

Verified: 'Blender file.blend --python start.py' runs the script AFTER the .blend is loaded (bpy.data.filepath was the .blend path and its Text datablock was visible inside the script, both in -b and GUI runs). In a GUI run, a bpy.app.timers.register(fn, first_interval=1.0) callback fired with bpy.context.window set (Window, screen 'Layout') but context.area and context.region None; calling bpy.ops.myop('INVOKE_DEFAULT') WITHOUT an override did run invoke() but with context.area/region/space_data None (so anything touching context.area fails); with `with bpy.context.temp_override(window=win, area=area, region=region): bpy.ops.probe.session('INVOKE_DEFAULT')` the operator got area=VIEW_3D, region=WINDOW, region_data=RegionView3D and returned {'RUNNING_MODAL'}, and the modal kept running after the timer returned. Fetch the window with bpy.context.window_manager.windows[0] (or bpy.context.window, which was non-None in the timer) and the area/region from win.screen.areas. temp_override signature in 4.1: temp_override(window, area, region, **keywords) (screen also accepted as keyword). In -b mode, timers are registered but never fire (no event loop) - verified. Timer signature: register(function, first_interval=0, persistent=False); return None to stop, a float to re-run. Embedding: t = bpy.data.texts.new('start.py'); t.write(code) and save - the text block survived save/reload; the user runs it from the Text Editor with Run Script (Alt-P), or register it to auto-run with t.use_module=True (needs Auto Run Python Scripts enabled in preferences, and is a security prompt).

```python
# start.py  (launched as:  /Applications/Blender.app/Contents/MacOS/Blender sim.blend --python start.py)
import bpy

def launch():
    wm = bpy.context.window_manager
    win = wm.windows[0]                                    # bpy.context.window is also set in timers
    area = next((a for a in win.screen.areas if a.type == 'VIEW_3D'), None)
    if area is None:
        return 0.5                                         # retry later
    region = next(r for r in area.regions if r.type == 'WINDOW')
    with bpy.context.temp_override(window=win, area=area, region=region):
        bpy.ops.sim.session('INVOKE_DEFAULT')              # -> {'RUNNING_MODAL'}
    area.tag_redraw()
    return None                                            # unregister timer

bpy.app.timers.register(launch, first_interval=0.5)

# embedding the script in the .blend (headless build step):
# t = bpy.data.texts.new("start.py"); t.write(open("start.py").read())
# user: Scripting workspace > Text editor > select 'start.py' > Run Script (Alt-P)
```

### Q13  (verified: True; source: GUI run (probe_gui2.py) + headless run (probe_q12_13.py: Area.tag_redraw, Region.tag_redraw, Operator.report(type, message) enum) + https://docs.blender.org/api/4.1/bpy.types.Region.html ('tag_redraw()') + https://docs.blender.org/api/4.1/bpy.types.Operator.html ('report(type, message): type (enum set in Wm Report Items), message (string)'))

context.area.tag_redraw() redraws the whole VIEW_3D area (all its regions, incl. the sidebar); to redraw only one region call region.tag_redraw() on that bpy.types.Region (e.g. the 'UI' region found via next(r for r in area.regions if r.type == 'UI'), or the 'WINDOW' region for just the viewport). Both methods exist in 4.1 (Area.tag_redraw(), Region.tag_redraw()) and area.tag_redraw() from inside modal() was verified to trigger the POST_PIXEL/POST_VIEW draw handlers (40 redraws vs 1 without). self.report({'INFO'}, msg) from invoke()/modal() prints 'Info: <msg>' to the terminal and the Info editor (verified: 'Info: probe modal started'); report type enum: DEBUG, INFO, OPERATOR, PROPERTY, WARNING, ERROR, ERROR_INVALID_INPUT, ERROR_INVALID_CONTEXT, ERROR_OUT_OF_MEMORY. Note: reports issued by a modal operator are shown in the status bar/Info editor only while the operator is the running one; {'WARNING'}/{'ERROR'} also pop up a message.

```python
def modal(self, context, event):
    ...
    # redraw just the 3D viewport region
    for r in context.area.regions:
        if r.type == 'WINDOW': r.tag_redraw()
    # redraw just the sidebar (N-panel) after state changes
    for r in context.area.regions:
        if r.type == 'UI': r.tag_redraw()
    # or everything in the area:
    context.area.tag_redraw()
    self.report({'INFO'}, f"Placed {name}")       # shows in Info editor / status bar
    return {'RUNNING_MODAL'}
```

### Q14  (verified: True; source: headless run (probe_q14b.py, probe_q5_6_7_9_11_14.py) + https://docs.blender.org/api/4.1/bpy.types.Context.html ('evaluated_depsgraph_get(): ... If any data-blocks have been edited, the dependency graph will be updated. This invalidates all references to evaluated data-blocks from the dependency graph.'))

Verified headless: bpy.data.objects.remove(obj, do_unlink=True) removes the object; its mesh datablock stays with users == 0 (orphan) - remove it with bpy.data.meshes.remove(mesh) (grab obj.data before removing the object) or later bpy.data.orphans_purge(do_recursive=True) (exists in 4.1, returns count). For children use list(obj.children_recursive) and remove them first. Depsgraph behaviour: a previously fetched depsgraph is NOT automatically refreshed for structural/transform changes made afterwards - with the stale depsgraph, ray_cast still hit remaining object A (no crash), did not hit the removed B (fine), but did NOT see a newly added object C until context.evaluated_depsgraph_get() was called again, and after moving A it still hit A at the OLD location and missed the new one until re-fetched. evaluated_depsgraph_get() returns a new wrapper each call ('dg is dg2' False) and its doc says it updates the graph if data-blocks were edited. So: always call context.evaluated_depsgraph_get() immediately before each ray_cast (cheap), especially after removing/adding/moving objects. Note ray_cast returns the ORIGINAL object (e.g. name 'A'), so obj.name lookups into bpy.data.objects work.

```python
def delete_with_children(obj):
    for child in list(obj.children_recursive):
        data = child.data
        bpy.data.objects.remove(child, do_unlink=True)
        if data is not None and data.users == 0:
            bpy.data.meshes.remove(data) if isinstance(data, bpy.types.Mesh) else bpy.data.curves.remove(data)
    data = obj.data
    bpy.data.objects.remove(obj, do_unlink=True)
    if data is not None and data.users == 0:
        bpy.data.meshes.remove(data) if isinstance(data, bpy.types.Mesh) else bpy.data.curves.remove(data)

# afterwards, ALWAYS re-fetch before casting:
dg = context.evaluated_depsgraph_get()
hit, loc, nrm, idx, ob, mat = context.scene.ray_cast(dg, origin, direction)
```

### Q15  (verified: True; source: headless run (probe_q15.py + direct python3.11 invocation) + https://docs.blender.org/manual/en/4.1/advanced/command_line/launch/macos.html ('In order to run Blender you will have to specify that path to the Blender executable inside this folder, to get all output printed to the terminal ... /Applications/Blender.app/Contents/MacOS/Blender') + https://docs.blender.org/api/4.1/info_tips_and_tricks.html ('Use the Terminal: ... You can see the output of print() as your script runs'))

On macOS, print() goes to the process stdout: when Blender is launched from Terminal via /Applications/Blender.app/Contents/MacOS/Blender the output appears in that Terminal; when launched by double-clicking the .app (Finder/Dock) there is no attached terminal and stdout is discarded (only visible via Console.app system log in some cases, not reliably). The 4.1 manual's macOS launch page says to run the executable inside the bundle 'to get all output printed to the terminal'. There is no 'Toggle System Console' on macOS: that is the Windows-only wm.console_toggle operator - verified headless that bpy.ops.wm.console_toggle.poll() raises 'AttributeError: Polling operator "bpy.ops.wm.console_toggle" error, could not be found' on this Mac build (the operator is not registered). Bundled Python: /Applications/Blender.app/Contents/Resources/4.1/python/bin/python3.11 is Python 3.11.7; numpy 1.24.3 is bundled (site-packages/numpy) and importable both inside Blender and from the standalone binary; matplotlib is NOT present (ModuleNotFoundError), scipy is NOT present either.

```python
# Terminal (see print() output):
#   /Applications/Blender.app/Contents/MacOS/Blender sim.blend --python start.py
# Inside Blender:
import sys, numpy
print(sys.version)           # 3.11.7
print(numpy.__version__)     # 1.24.3 (bundled)
try:
    import matplotlib        # ModuleNotFoundError in 4.1's bundled Python
except ModuleNotFoundError:
    pass
# bpy.ops.wm.console_toggle exists only on Windows; on macOS poll() raises AttributeError
```


## 3. Raw headless probe output (abridged)

```
##### probe_q1.py  (Blender -b --python probe_q1.py) #####
=== Q1 ray_cast ===
Blender version: 4.1.0 (4, 1, 0)
Scene.ray_cast doc: Cast a ray onto in object space
  param: depsgraph POINTER is_output= False is_required= True
  param: origin FLOAT is_output= False is_required= True
  param: direction FLOAT is_output= False is_required= True
  param: distance FLOAT is_output= False is_required= False
  param: result BOOLEAN is_output= True is_required= False
  param: location FLOAT is_output= True is_required= False
  param: normal FLOAT is_output= True is_required= False
  param: index INT is_output= True is_required= False
  param: object POINTER is_output= True is_required= False
  param: matrix FLOAT is_output= True is_required= False
visible cube                 hit=True obj=cube_vis loc=(0.0, 0.0, 0.5) face=5
return tuple len: 6
hide_set(True) cube          hit=False obj=None loc=(0.0, 0.0, 0.0) face=0
hide_viewport=True cube      hit=False obj=None loc=(0.0, 0.0, 0.0) face=0
hide_render=True cube        hit=True obj=cube_hide_render loc=(9.0, 0.0, 0.5) face=5
FONT text (extrude 0.1)      hit=True obj=txt loc=(12.0, 0.0, 0.1) face=103
CURVE bevel_depth=0.2        hit=True obj=crv loc=(15.0, 0.0, 0.2) face=3
CURVE no bevel               hit=False obj=None loc=(0.0, 0.0, 0.0) face=0
FONT text (extrude 0)        hit=True obj=txt loc=(12.0, 0.0, 0.0) face=103
keyword call ok: True cube_vis
view_layer arg error: TypeError Scene.ray_cast(): error with argument 1, "depsgraph" -  Function.depsgraph expected a Depsgraph type, not ViewLayer
Blender 4.1.0 (hash 40a5e739e270 built 2024-03-26 00:46:24)

##### probe_q5_6_7_9_11_14.py #####
Blender 4.1.0
=== Q5 Principled BSDF inputs ===
node type: ShaderNodeBsdfPrincipled
['Base Color', 'Metallic', 'Roughness', 'IOR', 'Alpha', 'Normal', 'Weight', 'Subsurface Weight', 'Subsurface Radius', 'Subsurface Scale', 'Subsurface IOR', 'Subsurface Anisotropy', 'Specular IOR Level', 'Specular Tint', 'Anisotropic', 'Anisotropic Rotation', 'Tangent', 'Transmission Weight', 'Coat Weight', 'Coat Roughness', 'Coat IOR', 'Coat Tint', 'Coat Normal', 'Sheen Weight', 'Sheen Roughness', 'Sheen Tint', 'Emission Color', 'Emission Strength']
identifiers: (identical to names)
  'Base Color' in inputs: True ... 'Metallic','Roughness','IOR','Alpha','Emission Color','Emission Strength','Coat Weight','Sheen Weight','Subsurface Weight','Specular IOR Level','Specular Tint','Coat Roughness','Transmission Weight','Normal': all True
set Base Color ok: (1.0, 0.0, 0.0, 1.0)
output node present: True linked: 1
=== Q6 text from data ===
align_x enum: ['LEFT', 'CENTER', 'RIGHT', 'JUSTIFY', 'FLUSH']
align_y enum: ['TOP', 'TOP_BASELINE', 'CENTER', 'BOTTOM_BASELINE', 'BOTTOM']
text obj type: FONT data type: TextCurve
evaluated_get().to_mesh(): verts 832 polys 608 (temp mesh; call ev.to_mesh_clear())
meshes.new_from_object(ev): verts 832 polys 608 name LabelCurve
new_from_object(original obj): verts 832
mesh object type: MESH
new_from_object kwargs preserve_all_data_layers/depsgraph OK
text dims: (5.61, 1.4, 0.1)
=== Q7 ID props ===
  int                SET OK -> type int value 5
  float              SET OK -> type float value 1.5
  str                SET OK -> type str value '5c'
  float list         SET OK -> type IDPropertyArray value <bpy id property array [3]> list()=[1.0, 2.0, 3.0]
  int list           SET OK -> type IDPropertyArray value <bpy id property array [3]> list()=[1, 2, 3]
  str list           SET OK -> type list value ['a', 'b']
  mixed list         FAIL TypeError: only floats, ints and dicts are allowed in ID property arrays
  dict               SET OK -> type IDPropertyGroup value <bpy id prop: owner="OBLabel", name="p_dict", ...> to_dict()={'a': 1, 'b': 'x'}
  tuple float        SET OK -> type IDPropertyArray value <bpy id property array [2]> list()=[1.0, 2.0]
  bool               SET OK -> type bool value True
  nested dict list   SET OK -> type IDPropertyGroup ... to_dict()={'pins': [1, 2]}
  None               SET OK -> type NoneType value None
  mixed int/float    SET OK -> type IDPropertyArray value <bpy id property array [2]> list()=[1.0, 2.5]
  empty list         SET OK -> type IDPropertyArray value <bpy id property array [0]> list()=[]
  keys: ['p_int', 'p_float', 'p_str', 'p_float_list', 'p_int_list', 'p_str_list', 'p_dict', 'p_tuple_float', 'p_bool', 'p_nested_dict_list', 'p_None', 'p_mixed_int_float', 'p_empty_list']
  'p_str' in ob: True  get default: dflt
  after del: False
=== Q9 units ===
props: ['system', 'system_rotation', 'scale_length', 'use_separate', 'length_unit', 'mass_unit', 'time_unit', 'temperature_unit']
system enum: ['NONE', 'METRIC', 'IMPERIAL']
length_unit enum (metric): ['DEFAULT']   (static rna listing; dynamic enum)
set: METRIC 0.0010000000474974513 MILLIMETERS
=== Q11 bmesh ops ===
  create_cone: BMeshOpFunc bmesh.ops.create_cone(bmesh, cap_ends=False, cap_tris=False, segments=0, radius1=0.0, radius2=0.0, depth=0.0, matrix=Matrix(), calc_uvs=False)
  create_cube: BMeshOpFunc bmesh.ops.create_cube(bmesh, size=0.0, matrix=Matrix(), calc_uvs=False)
  create_uvsphere: BMeshOpFunc bmesh.ops.create_uvsphere(bmesh, u_segments=0, v_segments=0, radius=0.0, matrix=Matrix(), calc_uvs=False)
  create_circle: BMeshOpFunc bmesh.ops.create_circle(bmesh, cap_ends=False, cap_tris=False, segments=0, radius=0.0, matrix=Matrix(), calc_uvs=False)
  create_icosphere: BMeshOpFunc bmesh.ops.create_icosphere(bmesh, subdivisions=0, radius=0.0, matrix=Matrix(), calc_uvs=False)
  create_grid: BMeshOpFunc bmesh.ops.create_grid(bmesh, x_segments=0, y_segments=0, size=0.0, matrix=Matrix(), calc_uvs=False)
  create_monkey: BMeshOpFunc bmesh.ops.create_monkey(bmesh, matrix=Matrix(), calc_uvs=False)
  cone returned: dict_keys(['verts']) 32
  cube returned: dict_keys(['verts']) 8
  uvsphere returned: dict_keys(['verts']) 42
  circle returned: dict_keys(['verts']) 12
  slots: ['A', 'B'] mat idx set: [0, 1]
  polys: 73 verts: 94
  mesh.validate(): False
  bad kw error: Typ
```
