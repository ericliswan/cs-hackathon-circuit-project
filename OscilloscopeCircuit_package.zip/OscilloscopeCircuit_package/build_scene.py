"""
build_scene.py — build the simulator scene headless and save it as breadboard_sim.blend.

    "/Applications/Blender.app/Contents/MacOS/Blender" -b --python build_scene.py -- [--out PATH] [--layout STANDARD|END_TO_END] [--columns 60] [--render PATH.png]

Run from the project directory (the folder containing AC_Circuit_Solver.py).
"""
import os
import sys

import bpy

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)


def _args():
    argv = sys.argv
    argv = argv[argv.index("--") + 1:] if "--" in argv else []
    out, layout, render, columns = os.path.join(PROJECT_DIR, "breadboard_sim.blend"), "STANDARD", None, 60
    i = 0
    while i < len(argv):
        if argv[i] == "--out":
            out = argv[i + 1]; i += 2
        elif argv[i] == "--layout":
            layout = argv[i + 1]; i += 2
        elif argv[i] == "--render":
            render = argv[i + 1]; i += 2
        elif argv[i] == "--columns":
            columns = int(argv[i + 1]); i += 2
        else:
            i += 1
    return out, layout, render, columns


def main():
    out, layout_name, render, columns = _args()
    bpy.ops.wm.read_factory_settings(use_empty=True)

    import blender_sim
    from blender_sim.board_layout import BoardLayout
    blender_sim.register()
    objs = blender_sim.scene_builder.build_scene(BoardLayout(layout_name, columns=columns))
    print(f"[build_scene] built scene: {len(bpy.data.objects)} objects, layout={layout_name}, columns={columns}")

    # Embed the start script as a text block so the .blend is self-describing.
    start_path = os.path.join(PROJECT_DIR, "start_sim.py")
    if os.path.exists(start_path):
        txt = bpy.data.texts.get("start_sim.py") or bpy.data.texts.new("start_sim.py")
        txt.clear(); txt.write(open(start_path).read())
    readme = bpy.data.texts.get("README") or bpy.data.texts.new("README")
    readme.clear()
    readme.write("Breadboard Circuit Simulator\n\n"
                 "Run start_sim.py from this Text editor (Run Script / Alt+P) to register the\n"
                 "add-on and start the interactive session, or launch Blender from the Terminal\n"
                 "with launch_blender.sh so that the component list printed on every placement\n"
                 "is visible.\n")

    # Export the hole coordinate table next to the .blend
    import json
    table = objs["layout"].export_table()
    with open(os.path.join(os.path.dirname(out), "breadboard_holes.json"), "w") as fh:
        json.dump(table, fh, indent=1)

    bpy.ops.wm.save_as_mainfile(filepath=out, compress=True)
    print(f"[build_scene] saved {out}")

    if render:
        scene = bpy.context.scene
        scene.render.filepath = render
        scene.render.resolution_x, scene.render.resolution_y = 1280, 800
        scene.render.resolution_percentage = 100
        scene.render.image_settings.file_format = "PNG"
        try:
            bpy.ops.render.render(write_still=True)
            print(f"[build_scene] rendered {render}")
        except Exception as exc:  # EEVEE may be unavailable headless; fall back to Workbench
            print(f"[build_scene] EEVEE render failed ({exc}); retrying with WORKBENCH")
            scene.render.engine = "BLENDER_WORKBENCH"
            bpy.ops.render.render(write_still=True)


if __name__ == "__main__":
    main()
