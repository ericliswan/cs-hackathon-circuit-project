# Breadboard Circuit Simulator — Blender frontend (Phase 1)

Interactive breadboard in **Blender 4.1**: arm a component with a 3D button (or the N-panel /
keyboard), click two holes, and a resistor / capacitor / inductor / jumper wire / probe snaps
between them. Every placement or deletion prints the component list to the **terminal** in the
exact raw-netlist format that `Breadboard_Circuit_Parser.py` consumes, then runs the backend
solver and prints the result. The backend files are used unmodified.

```
components = [
    ["WIRE", 'VCC', (1,"b")],
    ["RESISTOR1", (1,"c"), (5,"c")],
    ["RESISTOR2", (5,"d"), (9,"d")],
    ["WIRE", (9,"b"), 'GND'],
    ["PROBE", (5,"a"), 'GND'],
]
[BBSIM] circuit: closed and valid | Vout = 8.0000 V ∠ 0.0°  @ 50 Hz  (source 12 V ∠ 0°)
```

## 1. Requirements / what to set up in Blender

| Item | Needed? | Notes |
|---|---|---|
| Blender (`/Applications/Blender.app`) | yes | The copy on this Mac is **5.2.0 LTS** (bundled Python 3.13) — everything here was re-verified on it on 2026-08-23. Originally written against 4.1. |
| numpy inside Blender | yes | Bundled with Blender — nothing to install. |
| matplotlib inside Blender | **no** | `AC_Circuit_Solver.py` imports it; `blender_sim/netlist.py` installs a harmless stub when it is missing, so the backend imports cleanly. Installed on 2026-08-23 with Blender's own interpreter: `"/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13" -m pip install matplotlib` (the folder/version must match the Blender you have — check with `ls /Applications/Blender.app/Contents/Resources/`). |
| Blender add-on install | **no** | The package is loaded from this folder by `start_sim.py`; nothing to copy into Blender's add-ons directory. |
| Auto-run scripts preference | no | Not needed when you use `launch_blender.sh` or run `start_sim.py` yourself. |
| Terminal | yes | On macOS, `print()` output from Blender only appears in the Terminal that launched it (there is no "Toggle System Console" on macOS). Use the launcher below. |
| MCP / blender-mcp | no | Not required; everything is plain `bpy`. |

## 2. Run it

```bash
cd "/Users/imira/Desktop/Claude Projects/Oscilloscope Circuits"
./launch_blender.sh            # opens breadboard_sim.blend and runs toggle_buttons.py + place_components.py
./launch_blender.sh --build    # rebuilds breadboard_sim.blend headless first, then swaps in the buttons.blend selector
```

`launch_blender.sh` runs `Blender breadboard_sim.blend --python toggle_buttons.py --python place_components.py`
(two scripts, one session — same trick as `launch_buttons.sh`). The component list and solver output are
printed in that Terminal window.

**The selector is the one from `buttons.blend`** (8 buttons: R 250Ω/500Ω/1kΩ, C 0.47µF/47µF/470µF, Wire, Probe).
`swap_selector.py` appends those objects into `breadboard_sim.blend` (read-only access to `buttons.blend`,
which is never modified) and parents them to the Empty `PANEL_user`, lying flat on the bench beside the board
(the phase-1 tilted console is deleted). `toggle_buttons.py`
arms a button and writes its key to `bpy.context.scene.armed_component`; `place_components.py` reads that
property and creates the part. The older N-panel/HUD session (`blender_sim/interaction.py`, `start_sim.py`)
is no longer launched — it expects the old `BTN_*` buttons.

Rebuilding the .blend from scratch: `"/Applications/Blender.app/Contents/MacOS/Blender" -b --python build_scene.py -- --out breadboard_sim.blend [--layout STANDARD|END_TO_END] [--columns 60] [--render preview.png]`
followed by `"/Applications/Blender.app/Contents/MacOS/Blender" -b breadboard_sim.blend --python swap_selector.py`.

## 3. Using the simulator

1. **Start** — both scripts start automatically from the launcher (the viewport switches to Material Preview / camera view).
2. **Arm a component** — click one of your 3D buttons on the panel beside the board; it turns green and sinks.
   Clicking it again releases it (`toggle_buttons.py` radio behaviour).
3. **Place** — move the mouse: a cyan ring snaps to the nearest hole. Click hole A: an orange ring marks it and
   nothing else happens (no rubber band). Click hole B: the armed part is created between A and B, the list
   prints and the circuit is solved. Rail holes count as `VCC` / `GND`. Same hole / same rail as A is rejected.
   `Esc` or right-click forgets hole A; `X` deletes the most recently placed part (list re-printed, re-solved).
   `Esc` with nothing pending stops both scripts.
4. **Probe** — placing a second probe replaces the first (one probe at a time).
5. **Source** — 12 V ∠ 0° at 50 Hz (the defaults in `blender_sim/netlist.py`; no N-panel in this flow).
6. Orbit/zoom with the middle mouse / trackpad as usual while the scripts run.

The hole table the scene uses is also exported as `breadboard_holes.json` (`"65c": [x, y, z]` in mm,
plus rail hole lists) — the single source of truth for the frontend/backend handshake.

## 4. Layout conventions (matches the backend)

* Two halves, each 60 columns × rows a–e. **LHS → logical 1–60, RHS → logical 61–120**; the netlist
  always carries the logical column, e.g. RHS physical column 5 row c → `(65,"c")`.
* Default layout `STANDARD`: the halves flank the centre channel like a real 830-point board seen in portrait
  (columns run away from the camera, column 1 nearest); both halves read `a b c d e` left→right.
  `END_TO_END` lays the 120 columns in one line (`--layout END_TO_END`). Switching layouts changes only
  geometry — the netlist is identical.
* Rails run `+ − | + −` across the board exactly like `Breadboard model example.png`: on the LHS edge
  `VCC` (+, red) is the outer rail and `GND` (−, blue) the inner one; on the RHS edge `VCC` is inner and
  `GND` outer. Clicking any hole of a rail yields `VCC` / `GND` in the netlist. All four rails are
  pre-wired from the carrier's binding posts (`RAIL_*` objects, fixed).
* Column count: the spec/backend use **60 columns per half** (logical 1–60 / 61–120), which is what
  `breadboard_sim.blend` contains. The reference picture shows a 30-column (400-point) board; build that
  variant with `--columns 30` (logical 1–30 / 61–90 — the RHS offset stays 60 for the parser).

## 5. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| No text appears in the Terminal | Blender was opened by double-click. Quit it and use `./launch_blender.sh` (macOS has no in-app console). |
| Clicks select objects instead of placing | The scripts are not running (an earlier `Esc` stopped them) — relaunch with `./launch_blender.sh`. |
| A click on a hole only prints "nothing armed" | No button armed — click one of the component buttons first. |
| "same hole / same rail as A" | Endpoint B equals A, or both ends are on the same rail (electrically one node). |
| Buttons missing / old `BTN_*` buttons back | `breadboard_sim.blend` was rebuilt without the swap — run `./launch_blender.sh --build` (or `swap_selector.py`). |
| Scene looks flat/grey | Switch the viewport to Material Preview (the launcher does this automatically). |
| Backend reports `singular circuit` | An ideal zero-impedance path shorts the source (e.g. an inductor at ~0 Hz); change the circuit or frequency. |
| Saved the file mid-session | Harmless — the running flag is reset on load. |

Rendered previews are in `docs/` (`preview_user_selector.png` = current scene with the buttons.blend selector;
`preview_render.png`, `preview_closeup.png`, `preview_components.png`, `preview_blender_session.png` = phase-1 scene).

## 6. Final product — `OscilloscopeCircuit.blend`

```bash
./launch_oscilloscope.sh            # opens OscilloscopeCircuit.blend + the three scripts below
./launch_oscilloscope.sh --build    # rebuilds it from breadboard_sim.blend + oscilloscope.blend first
```

`build_oscilloscope_scene.py` appends the parts of `oscilloscope.blend` (read-only) that matter — chassis
(shortened), screen, softkeys, the functional knobs with their labels, BNC row, power button; the decorative
buttons/pins/labels are left out — under the Empty `SCOPE_root` (×8, facing the camera, on the bench behind
the board), adds the `SCOPE_display` plane in the
bezel opening, bezel readouts, `fn` tags + pointer marks on the functional knobs, the two fixed leads
(Gen Out → binding posts, CH1 → probe pick-up on a holder) and a wider camera, then saves the new file.
`breadboard_sim.blend` and `oscilloscope.blend` are never written.

Runtime = `toggle_buttons.py` + `place_components.py` (as above) + `oscilloscope_sim.py`:

| Control | Effect |
|---|---|
| **Screen** | the PNG that **your** `AC_Circuit_Solver.plot_voltage` draws — wave-gen trace always; CH1/probe trace when your parser reports a closed, valid circuit with a measurable probe. `plt.show()` is swapped for `savefig()` during the call (Agg backend), then the image texture is reloaded. |
| **Turning any knob** | click-**drag** it up/down (mouse or trackpad), two-finger scroll over it, or mouse wheel over it |
| **Horizontal knob** | `x_scale_mult` — 1-2-5 steps 0.1…10; plain click = back to ×1 |
| **CH1 vertical knob** | `y_scale_mult` — same steps; plain click = ×1 |
| **Softkeys** under the screen (or their labels) | select Frequency / Amplitude / Phase (highlighted yellow) |
| **Entry knob** | adjust the selected wave-gen parameter (f ×1.25, ±0.5 V, ±5° per step); click = next parameter. `↑`/`↓` keys do the same from anywhere. Every change re-solves with your backend |
| **Power button** | display on/off (screen, readouts, LED) |
| N-panel **Oscilloscope** tab | amplitude / frequency / phase sliders, power, re-solve |
| keys `1` `2` `3` | overview / board / screen views |
| CH2 scale, CH1/CH2 position knobs | turn, but `plot_voltage` has no parameter for them |

`graph_size` is set to the screen's aspect (7.8 × 6.0 in); the display PNG is `OscilloscopeCircuit_display.png`
next to the .blend. The top bezel shows `V ×… t ×…` plus the CH1 reading when the probe measures something
(blank otherwise — the reason, e.g. "open circuit", is printed in the Terminal); the bottom bezel is the wave-gen menu.

## 7. Files

```
OscilloscopeCircuit.blend   FINAL product = breadboard_sim.blend + oscilloscope.blend (+ leads, display, camera)
oscilloscope.blend          YOUR oscilloscope model — read only, never modified
build_oscilloscope_scene.py one-off headless assembly of OscilloscopeCircuit.blend
oscilloscope_sim.py         scope runtime: screen = plot_voltage PNG, knobs, wave gen, power, views
launch_oscilloscope.sh      Terminal launcher for the final product (three scripts, one session)
buttons.blend           YOUR component selector (8 buttons carrying `arms`) — read only, never modified
toggle_buttons.py       YOUR button handler: click = arm (green, sunk), writes scene.armed_component
place_components.py     hover ring + two-click creation; reads scene.armed_component, prints list, solves
swap_selector.py        one-off: appends buttons.blend's objects into breadboard_sim.blend (PANEL_user)
launch_blender.sh       Terminal launcher: breadboard_sim.blend + the two scripts above (shows print() output)
blender_sim/            the package (board_layout, materials, bpy_utils, scene_builder,
                        component_meshes, netlist, interaction, CONTRACT.md, RESEARCH_NOTES.md);
                        place_components.py uses component_meshes + netlist only
build_scene.py          headless scene build → breadboard_sim.blend (+ breadboard_holes.json); run swap_selector.py after it
start_sim.py            the old phase-1 session (N-panel/HUD/rubber band) — not launched any more
tests/                  python3 tests (board layout, netlist format) + headless Blender tests
AC_Circuit_Solver.py, Breadboard_Circuit_Parser.py   backend — unchanged
```

Single-file source bundle: `ALL_PYTHON_SOURCES.md` contains every script above (entry points, package,
tests, unchanged backend) with a linked table of contents — regenerate after edits with
`python3 tools/make_source_bundle.py`.

Tests: `python3 tests/test_board_layout.py`, `python3 tests/test_netlist_format.py`,
`"/Applications/Blender.app/Contents/MacOS/Blender" -b --python tests/blender_smoke_test.py`.
