# Breadboard Circuit Simulator — Frontend & 3D Modelling Specification

A fully-simulated electrical-engineering practical, built in **Blender + Python**,
that behaves like an **interactive game**: the student starts a simulation session,
clicks 3D buttons to arm a component type, then clicks two points on a breadboard to
place components and wires. An adjustable AC source drives the circuit and the output
voltage is drawn on a 3D oscilloscope.

This document specifies the **frontend, interaction model, and 3D modelling**. The
circuit-solving backend is complete; its two scripts are authoritative (see §2).

---

## 1. Project Overview

| | |
|---|---|
| **Goal** | Let students see how changes to input voltage and to a passive filter circuit change the output voltage, on a realistic, interactive 3D bench. |
| **Environment** | Entirely rendered and driven inside Blender; the viewport *is* the application. |
| **Interaction** | Game-like: start session → click buttons to arm a mode → two clicks to place. |
| **Stack** | Blender (`bpy`: scene, geometry, modal interaction) + Python circuit engine (built). |
| **Components** | Resistors, capacitors, inductors, jumper wires. |
| **Source** | Single AC voltage source (adjustable amplitude, phase, frequency) between the fixed VCC/GND rails. |
| **Output** | Voltage across the oscilloscope probe, drawn as a live animated waveform. |

---

## 2. Backend Contract (already built — do not re-implement)

The frontend's only job is to (a) assemble a **raw netlist** from the scene and
(b) push the returned waveform to the scope.

> **Authoritative backend sources.** The two backend scripts are the definitive
> documentation for everything below the netlist boundary — read them, don't
> re-derive their behaviour:
> - **`AC Circuit Solver`** — the `Component` class hierarchy (Resistor,
>   Capacitor, Inductor, VoltageSource, CurrentSource), complex impedance /
>   admittance, and `solve_nodal` (Modified Nodal Analysis with phasors, a GMIN
>   leak so floating nodes don't go singular, DC/AC handling). Defines component
>   values, units, and the solve contract.
> - **`Breadboard circuit parser.py`** — hole → node reduction, the LHS/RHS column
>   transform (§5.3), wire merging (union-find), the `PROBE` row, the closed-circuit
>   validity check, and assembly of the `raw` netlist into `Component` objects.
>   This is where the frontend's hole reports become a solvable circuit **and where
>   output-trace visibility is decided**.
>
> When this document and a script docstring disagree, **the scripts win** — update
> this document to match them, quoting the scripts' own identifiers.

**One call the frontend makes:**

```python
result = solve_breadboard(raw, CLASS_MAP, solve_nodal, VoltageSource,
                          freq_hz=<slider>, source=(amplitude, phase_deg))
```

**Raw netlist format** — a list of rows, each `[NAME, holeA, holeB]`:

- `NAME` is a palette key: `"RESISTOR_1"`, `"CAPACITOR_2"`, `"INDUCTOR_3"`,
  `"WIRE"`, or `"PROBE"`.
- A hole is either a **rail name** (`"VCC"`, `"GND"`) or a **(column, row)**
  tuple such as `(5, "c")`, where **column ∈ 1..120** (the *logical* column after
  the LHS/RHS transform in §5.3) and row ∈ {a,b,c,d,e}.
- The board physically shows **two halves each numbered 1–60**; the parser maps
  **LHS → 1–60, RHS → 61–120**. The frontend emits logical columns directly.

```python
raw = [
    ["WIRE", "VCC", (1, "b")],
    ["RESISTOR_1", (1, "c"), (5, "c")],
    ["CAPACITOR_2", (5, "c"), (7, "c")],
    ["WIRE", (7, "b"), "GND"],
    ["PROBE", (5, "c"), "GND"],
]
```

**Returned dict** the scope reads directly:

| Key | Meaning |
|---|---|
| `ok` | `True` if the circuit is closed/solvable; else no output trace + `reason`. |
| `reason` | `"closed and valid"`, `"open circuit …"`, `"VCC is wired directly to GND"`. |
| `amp`, `phase_deg` | Output magnitude (V) and phase (°) across the probe. |
| `Vout` | Output phasor (complex); `None`/undefined if the probe reads nothing. |
| `v_nodes` | All nodal voltages; a stranded probe node reads `NaN`. |

> **Frontend invariant:** the interaction layer only ever reports *which holes*
> each component/wire/probe touches. Node numbering, wire merging, and validity are
> all `Breadboard circuit parser.py`'s job.

---

## 3. Interaction & Session Model (game-like)

### 3.1 Simulation session
- The experience runs as an **interactive session**, started by the student (e.g. a
  "Start Simulation" button or on file load). Starting the session launches the
  **master modal operator** (§6.1) that captures input continuously — this is the
  game loop.
- While the session runs, the student can: click 3D UI buttons, place components and
  wires, move the probe, adjust source controls, and toggle the oscilloscope.

### 3.2 Arm-a-mode, then two-click placement (replaces drag-and-drop)
The old "hold an instance and snap it to the grid" model is **replaced** by a
button-armed, two-click model:

1. **Click a mode button** — on-screen 3D (or panel) buttons: **Resistor**,
   **Capacitor**, **Inductor**, **Jumper Wire**. This *arms* that component type;
   the armed mode is shown in the HUD.
2. **Click two holes** on the breadboard. The first click sets endpoint A (shown
   with a highlight/marker); an optional rubber-band line follows the cursor; the
   second click sets endpoint B.
3. On the second click the component/wire mesh is **spawned spanning the two holes**,
   custom properties are written, and a new **`[NAME, holeA, holeB]`** row is
   appended to the netlist in the format `Breadboard circuit parser.py` expects.
4. The parser + solver re-run and the scope refreshes.

- **Value selection:** for resistor/capacitor/inductor with multiple values, either
  separate buttons per value (`Resistor 250Ω`, …) or a value picker that sets the
  armed key (`RESISTOR_1/2/3`).
- **Cancel / rejection:** right-click or `Esc` cancels the current placement (after
  one click, discards endpoint A). A second click on the *same* hole is rejected.
  Between the two clicks the view can still be orbited/zoomed.
- **Delete:** clicking an existing placed component while a "delete" mode is armed
  (or a modifier-click) removes its mesh and its netlist row, then re-solves.

### 3.3 3D clickable buttons
- Mode buttons can be **real 3D objects** in the scene (panel meshes with labels)
  detected by **raycasting the click** against them, giving the game-engine feel; or
  a Blender **N-panel** with operator buttons; or both.
- A hovered/armed button should give visual feedback (highlight, colour, slight
  push-in) so the student knows what's active.

---

## 4. Feature Specifications

### 4.1 Adjustable input voltage (amplitude + phase + frequency)
- Controls expose **amplitude** (V), **phase** (°), and **frequency** (Hz).
- Editing any re-runs the solve with `source=(amplitude, phase)` and `freq_hz`, and
  refreshes the scope. Values feed the source argument — **not** baked into a
  component.
- Suggested ranges: amplitude 0–24 V, phase −180…+180°, frequency 1 Hz–1 MHz (log).

### 4.2 Component placement (two-click)
- Armed via button (§3.2); placed by two hole clicks; spans exactly the two holes.
- Each component occupies two holes (its two pins) and records them as custom props.
- Invalid placement (same hole, or a hole off-board) is rejected with a visual cue.

### 4.3 Jumper wires
- Same two-click flow with `NAME = "WIRE"`; rendered as a coloured curve/tube arcing
  between the two holes.
- Electrically a **node merge** — handled by the parser; the frontend records holes.

### 4.4 Fixed leads & probe
- **VCC/GND rails are pre-wired** (see §5.1a) and not student-editable.
- The **oscilloscope probe** measures output. Minimum viable: probe positive is
  student-placeable on any hole (a two-click or single-click place), probe negative
  fixed to GND, emitting `["PROBE", holeP, "GND"]`. If both movable, emit both holes.

### 4.5 Oscilloscope display — the centrepiece

> **This is the hero of the prototype and must be genuinely high-quality and
> animated.** The waveform graphs are the whole point of the practical. Budget the
> most polish here — treat the screen as a real, smoothly-animated instrument.

**Two traces, two different rules:**

| Trace | Channel | When it shows | Driven by |
|---|---|---|---|
| **Input waveform** | Wave generator | **Always** — responds live to amplitude/phase/frequency at any time. | Source sliders directly (circuit-independent). |
| **Output waveform** | Channel 1 | **Only when the circuit is valid AND the probe actually reads an output.** | Backend result across the probe. |

- The **input trace is unconditional**: it animates with the source controls
  regardless of what's on the board, so a reference signal is always moving.
- The **output trace is conditional** — drawn only when `Breadboard circuit
  parser.py` confirms:
  - the closed-circuit check passes (a VCC→GND path exists), **and**
  - the probe's resolved node is part of the connected circuit (not stranded — i.e.
    `v_nodes[probe]` is a real value, not `NaN`), **and**
  - a real output results.
  - If any fail: **draw no output trace** (input still shows) and surface `reason`.
- **Animation requirements:** smooth interpolated redraw (no per-frame snapping);
  phosphor-style emissive glow with optional trace persistence; graticule with
  volts/div & time/div feel; amp/phase readouts when output is live; distinct
  per-channel colours (e.g. CH1 output yellow, wave-gen input a second colour).

### 4.6 Oscilloscope power on/off
- A power control toggles the scope with a polished **animation** (screen glow ramps
  up, graticule illuminates, traces fade in; reverse on power-down).
- When **off**: dark screen, no trace, regardless of circuit state.

---

## 5. 3D Blender Modelling Requirements

### 5.1 Scene layout
- Bench surface (plane) as the ground.
- **Breadboard** centred, flat, mounted on a **carrier board** (backing board that
  also carries the supply connections).
- **Wave generator** unit connected by a **real modelled cable** to the carrier
  board (§5.6). This is the AC source.
- **Oscilloscope** upper-left/back, screen angled to camera, with a **real modelled
  Channel-1 cable** to the probe (§5.6).
- **Mode buttons** (Resistor / Capacitor / Inductor / Jumper Wire, + value/delete)
  as clickable 3D panels and/or an N-panel.
- One primary **camera** framing board + scope; three-point or HDRI lighting.

### 5.1a Fixed signal path (pre-wired, not student-editable)

```
[Wave generator] --cable--> [carrier board] --pre-set jumpers--> [+ / - rails]
                                                                      │
                                                   student builds circuit here
                                                                      │
[Oscilloscope CH1] --cable--> [probe] --> student places tip on a hole
```

- The wave-gen → board → rails chain is **static geometry + fixed netlist rows** the
  student can't move or delete; it always contributes the VCC/GND rail holes.
- Student-controlled electrical elements are only: placed components, jumper wires,
  and the probe tip position.

### 5.2 (reserved)

### 5.3 Breadboard model — the coordinate anchor

**Physical vs logical layout.** The board is displayed as **two halves, each
numbered 1–60** (LHS and RHS), each with rows **a, b, c, d, e**. That's what the
student sees and the model renders.

**The logical transform (`Breadboard circuit parser.py`).** The two halves are
flattened into a single column range so every hole is unique:

```
LHS hole (column c, row r)   ->  logical (c,       r)     # 1..60  unchanged
RHS hole (column c, row r)   ->  logical (c + 60,  r)     # 1..60 -> 61..120
```

RHS column 1 → logical **61**, RHS column 60 → logical **120**. Rows a–e span both
sides. The parser then reduces this to nodes (rows a–e on a column collapse to one
node; `VCC→1`, `GND→0`, with the `+1` column offset — see the parser docstrings).

- **Holes generated programmatically** (a script placing a hole at each physical
  `(side, column, row)`); the export table carries the **logical** column so the
  frontend never redoes the transform:

  ```
  (logical_column, row_letter) -> (x, y, z)
  # LHS: (5,  "c") -> ( ... )      RHS: (65, "c") -> ( ... )   # physical RHS col 5
  ```

- This table is the **single source of truth** for nearest-hole click resolution,
  component/wire endpoints, and probe placement. A wire from `(5,"c")` to `(65,"c")`
  (across the halves) is expressed and merged with no special-casing.
- Uniform hole pitch within each half. The **centre divide is a physical gap only**
  with no electrical meaning — cross it with jumper wires, as on a real board.

### 5.4 Component models
Low-poly, two pin tips aligning to holes. Keep geometry light — everything updates
live.

| Component | Model notes | Distinguishing feature |
|---|---|---|
| **Resistor** | Cylindrical body, axial leads to two pins. | Colour bands per value. |
| **Capacitor** | Ceramic disc or electrolytic can, two pins. | Body colour/value; polarity stripe if electrolytic. |
| **Inductor** | Coil around a core, two pins. | Visible coil turns. |
| **Jumper wire** | Curve/tube between two holes. | Arcs over the board. |

- Pins sit exactly on hole centres from the coordinate table.
- Distinct base colours; PBR-lite is fine. Palette/preview instances match placed ones.

### 5.5 Oscilloscope model — *refer to the UQ oscilloscope PNG and `oscilloscope function requirements.png`*
- Match the **UQ oscilloscope PNG** (to be supplied): body proportions, bezel,
  knob layout, colour.
- **Check `oscilloscope function requirements.png` for which controls must be
  functional.** The **highlighted areas are the interactive/functional controls** in
  the prototype. **Every other button, knob, and port is aesthetic** — modelled and
  labelled but non-interactive. Don't spend interaction budget on un-highlighted
  controls.
- **Screen** is a separate flat plane, mesh/material driven at runtime for the
  waveforms (emissive; high-polish per §4.5).
- **Power control** is a named object toggled by the on/off operator, keyed for the
  power animation.
- **Graticule** overlay on the screen.
- **Probe** (body + tip + lead) is a separate object; its tip defines the
  measurement hole.

### 5.6 Cables (actual modelled geometry)
| Cable | From → To | Notes |
|---|---|---|
| **Wave-generator cable** | Wave gen output → carrier board | Part of the fixed pre-wired path. |
| **Channel-1 cable** | Scope CH1 port → probe | Board end **tracks the probe** as it moves. |

- Curve/tube geometry with connector ends seated in the correct ports (BNC-style or
  matching the UQ oscilloscope PNG). Other ports are aesthetic unless highlighted in
  `oscilloscope function requirements.png`.

### 5.7 Naming & custom properties (the frontend/backend handshake)
| Object | Custom properties |
|---|---|
| Placed component | `comp_type` (`"RESISTOR_1"`…), `pin_a` = `(col,row)`, `pin_b` = `(col,row)`, `uid` |
| Jumper wire | `pin_a`, `pin_b` |
| Probe | `pin_p`, `pin_m` (m may be fixed `"GND"`) |
| Fixed rail jumpers | `rail` = `"VCC"`/`"GND"`, `hole` = `(col,row)` — **pre-wired, not editable** |
| Wave-gen / CH1 cables | `endpoint` refs (static; CH1 board-end tracks the probe) |
| Mode button | `arms` = component key (`"RESISTOR_1"`, `"WIRE"`, …) |

- Object-name prefixes per type (`COMP_`, `WIRE_`, `PROBE_`, `RAIL_`, `BTN_`) so a
  scene walk filters fast.
- The netlist builder produces exactly the `raw` list from §2 by reading these props.

---

## 6. Frontend Interaction Layer (`bpy`)

### 6.1 Master modal operator (the game loop)
- Started when the simulation session begins; added via
  `window_manager.modal_handler_add`. Runs until the session ends.
- Handles: clicks on 3D mode buttons (raycast), the two-click placement sequence,
  probe placement, delete mode, and passing through view navigation.
- Holds session state: `armed_type` (which button is active) and `pending_hole`
  (first click of a pair, or `None`).

### 6.2 Two-click placement operator
- **Arm:** a mode button sets `armed_type`.
- **Click → hole:** raycast the mouse into the scene; intersect the board plane
  (`view3d_utils.region_2d_to_origin_3d/vector_3d` + `intersect_line_plane`), then
  snap to the nearest entry in the hole-coordinate table.
- **First click:** store `pending_hole`, show a marker, optional rubber-band line.
- **Second click:** spawn mesh spanning the two holes, write custom props, append
  the `[NAME, holeA, holeB]` row, clear `pending_hole`, re-solve.
- `Esc`/right-click cancels; same-hole second click rejected.

### 6.3 3D button hit-testing
- Raycast the click ray against button meshes (`scene.ray_cast` or bounds test). A
  hit sets `armed_type` from the button's `arms` property and updates the HUD.

### 6.4 Control panel
- Float properties: `amplitude`, `phase`, `frequency`; per-component value edit when
  selected. Each has an `update` callback that re-solves and refreshes the scope.

### 6.5 Scope trace rendering
- **Input trace (wave gen):** computed from the source sliders and drawn **every
  update, unconditionally**.
- **Output trace (CH1):** drawn only when `result["ok"]` **and** the probe node
  voltage is not `NaN` (probe lands on a connected, driven node). Otherwise input
  only.
- Sample the phasor(s) into `v(t)` over ~2 cycles; write to screen curve/mesh
  vertices; update via a throttled `bpy.app.timers` / `depsgraph` handler (not every
  frame), ≲ 1–2 k points, interpolated for smooth animation.

### 6.6 Re-solve trigger points
Placing/moving/deleting a component, adding/removing a wire, moving the probe, or
changing any source/value control. **The input trace also updates on source changes
even when the circuit is invalid** — the generator signal always responds.

---

## 7. Data Flow (per update)

```
Scene walk (read custom props)                         [FRONTEND]
        │  build raw netlist  [NAME, holeA, holeB], …    (logical columns 1..120)
        ▼
Breadboard circuit parser.py                           [BACKEND script 1]
        │  LHS/RHS transform, wire merge, hole->node, closed-circuit check
        ▼
AC Circuit Solver: solve_nodal(components, omega)      [BACKEND script 2]
        │  MNA with phasors -> {ok, reason, amp, phase_deg, Vout, v_nodes}
        ▼
input trace: always redrawn from source sliders        [FRONTEND]
output trace: drawn only if ok AND probe node not NaN
```

The frontend touches only the top and bottom rows; the two middle stages live in
`Breadboard circuit parser.py` and `AC Circuit Solver`.

---

## 8. UI / Scope States

| Condition | Scope behaviour |
|---|---|
| Scope OFF | Dark screen, no trace. |
| ON, changing source sliders | **Input trace always animates**, circuit-independent. |
| ON, valid circuit + probe on a driven node | Input **and** live output (CH1) + amp/phase readout. |
| ON, valid circuit but probe on a stranded/floating hole | Input only; no output. |
| ON, open circuit | Input only; text: "open circuit — VCC not connected to GND". |
| ON, shorted supply | Input only; text: "VCC wired directly to GND". |
| ON, mid-placement (stranded parts) | Input live; output solves the connected part, stranded parts ignored (parser/GMIN). |

---

## 9. Do I need MCP servers?

**Not required, but the Blender MCP server smooths AI-assisted scene building.**

- **With `blender-mcp`:** Claude connects to a running Blender, creates geometry,
  sets materials, positions the camera, and runs `bpy` live — best for building the
  breadboard grid, component models, and the oscilloscope from the reference PNGs
  interactively.
  - Setup: install the `blender-mcp` addon, run its socket server, add the MCP server
    to Claude's connectors.
- **Without MCP:** Claude writes complete `bpy` scripts you paste into Blender's
  Scripting workspace. No dependencies; you lose the live feedback loop.
- **Image → model:** neither path auto-generates a mesh from a photo. Use the UQ
  oscilloscope PNG / `oscilloscope function requirements.png` as **modelling and
  functional references**.
- **Runtime interaction (buttons, two-click, scope) needs no MCP** — it's plain
  `bpy` modal-operator code in your addon.

**Recommendation:** use `blender-mcp` for the geometry/scene phase; keep the modal
interaction, netlist builder, and scope logic as MCP-free `bpy` so the running app
has no external dependency.

---

## 10. Asset Checklist

- [ ] Breadboard mesh — two halves each 1–60, rows a–e, centre gap; programmatic hole
      grid + exported table keyed by **logical** column (LHS 1–60, RHS 61–120)
- [ ] Resistor / Capacitor / Inductor models (×3 value variants each)
- [ ] Jumper wire generator (curve/tube between two holes)
- [ ] Oscilloscope model (UQ oscilloscope PNG); functional controls per
      **`oscilloscope function requirements.png`** (highlighted = functional, rest
      aesthetic) + animated, drivable screen (§4.5)
- [ ] Wave generator unit + carrier board
- [ ] **Wave-generator cable** and **Channel-1 cable** (real geometry; CH1 tracks probe)
- [ ] Pre-wired + / − rail jumpers (fixed)
- [ ] Probe model (movable tip)
- [ ] Mode buttons (Resistor / Capacitor / Inductor / Jumper Wire / value / delete)
- [ ] Bench, lighting, camera, materials
- [ ] Power on/off animation on the scope

## 11. Suggested Build Order (frontend)

1. Breadboard + hole-coordinate export (unblocks everything).
2. Component + wire models; oscilloscope + drivable screen plane.
3. Master modal operator + 3D mode buttons (arm a type).
4. Two-click placement operator (raycast → hole → spawn → netlist append).
5. Scene-walk netlist builder → call `Breadboard circuit parser.py` → print result.
6. Scope trace rendering: input (always) + output (conditional on validity).
7. Control panel (amplitude/phase/frequency) + re-solve wiring.
8. Power on/off animation + UI state messages + cables.
9. Polish: materials, lighting, animation quality, demo circuits (RC low-pass,
   RC high-pass, RLC band-pass).
