# Oscilloscope — 3D Model & Functional Specification

Reference instrument: **Keysight/Agilent InfiniiVision MSO/DSO-X 2000-series**
(the UQ lab oscilloscope). Built from four reference images:

| Image | File | Use |
|---|---|---|
| 1 | `UQ_Oscilloscope.png` | Close-up of the control panel; labels Horizontal Scale (s/Div) and Vertical Scale (V/Div) knobs. |
| 2 | `Uq_oscillioscope_2.png` | Screen reference — yellow sinusoid, graticule, on-screen readouts, waveform-generator menu. |
| 3 | `UQ_Oscilloscope_3.png` | Full front view; labels Function Generator output, CH1 input, Entry knob, Channel Settings. |
| 4 | `Oscilloscope_functional_requirements.jpeg` | **Defines what must be functional** — green-highlighted controls (below). |

> **Rule for the prototype:** only the **green-highlighted** controls in image 4 are
> **interactive/functional**. Everything else on the instrument is modelled and
> labelled for visual accuracy but is **aesthetic (non-interactive)**.

---

## 1. Functional controls (green-highlighted in image 4)

These are the only controls wired to behaviour in the prototype.

| # | Control | Location | Function in the sim |
|---|---|---|---|
| F1 | **Power button** | Bottom-left, round green button | Toggles the scope on/off with the power animation (screen glow ramps up/down, traces fade). When off: dark screen, no traces. |
| F2 | **Function Generator output** | Bottom-left BNC, beside power | Source of the input signal. The **wave-generator cable** plugs in here and runs to the carrier board. Represents the AC source feeding VCC/GND. |
| F3 | **CH1 input (BNC)** | Bottom, green-ringed "1" connector | The measurement input. The **Channel-1 cable** runs from here to the probe. The output waveform shown is what CH1 "sees" at the probe. |
| F4 | **CH1 Vertical Scale knob** (large "1") | Vertical section, green | Sets **Volts/Div** for CH1 — rescales the output trace's vertical size on screen. |
| F5 | **CH1 Vertical Position knob** (small, below "1") | Below CH1 scale knob, green | Moves the CH1 (output) trace **up/down** on screen. "Push to Zero" recentres it. |
| F6 | **CH2 Vertical Scale knob** (large "2") | Vertical section, green | Sets **Volts/Div** for CH2 — rescales the input/reference trace vertically. |
| F7 | **CH2 Vertical Position knob** (small, below "2") | Below CH2 scale knob, green | Moves the CH2 (input) trace **up/down** on screen. |

> **Channel assignment for this sim:** CH1 = measured **output** (via probe), CH2 =
> **input**/reference (wave-generator signal). The two green channel columns in
> image 4 map to these two traces.

### Optional-but-recommended functional knobs (labelled in images 1 & 3)
Not green in image 4, but they control the *scale* of the displayed waveform, which
is core to the practical. Implement if time allows; otherwise leave aesthetic.

| # | Control | Ref image | Function |
|---|---|---|---|
| O1 | **Horizontal Scale (s/Div)** | Image 1 (top-left, circled) | Sets time/Div — zooms the waveform horizontally in time. |
| O2 | **Entry knob** | Image 3 (circled, centre) | Adjusts the selected wave-generator parameter (amplitude/frequency) in the on-screen menu. |

---

## 2. Aesthetic (non-interactive) controls
Model and label for realism; **no behaviour**. From images 1, 3, 4:

- **Run Control:** Run/Stop, Single buttons (top-right).
- **Trigger** section: Trigger, Force Trigger, Level, Mode/Coupling.
- **Measure** section: Cursors, Meas.
- **Tools:** Utility, Quick Action, Analyze.
- **Waveform:** Acquire, Display.
- **File:** Save/Recall, Print.
- **Right-column** softkeys: Serial, Digital, Math, Ref + their knobs.
- **Default Setup**, **Auto Scale** buttons.
- **Horiz/Search/Navigate** buttons and navigation arrows (▲ ■ ▶).
- **CH1/CH2 Label** and **Help** buttons.
- **Digital/USB/LAN ports**, secondary BNCs, and back-panel details.
- Brand text (**Keysight/Agilent InfiniiVision**, model, bandwidth).

---

## 3. Screen specification (image 2 is the reference)

The screen is the **hero element** — a separate flat plane with an emissive,
animated material. Match image 2's look.

**Layout to reproduce:**
- **Graticule:** grid of divisions (≈ 8 vertical × ~10 horizontal), faint grid
  lines, brighter centre cross-hairs.
- **Waveform traces:** bright **yellow** primary trace (CH1 output); a second
  distinct colour for CH2 (input/reference). Phosphor-style glow; optional slight
  persistence.
- **Top status bar:** left = **Vertical Scale (V/Div)** readout (e.g. `500%/`),
  right = **Horizontal Scale (s/Div)** readout (e.g. `100.0%/`), plus trigger/mode
  text (`Auto`), and level (`0.0V`).
- **Right info panel:** Acquisition mode (`Normal`), sample rate, **Channels** block
  showing per-channel scale (`1.00:1`, `10.0:1`), coupling (`DC`).
- **Bottom Waveform Generator Menu:** softkey labels — **Waveform** (Sine),
  **Frequency**, **Amplitude**, **Offset**, **Settings** — reflecting the source
  the student controls.

**Driven at runtime:**
- Trace vertices rewritten from the sampled `v(t)` each update (see the main sim
  spec §4.5 / §6.5).
- V/Div and s/Div readouts update when F4/F6 (and O1) change.
- Amplitude/Frequency menu values reflect the current source settings.

---

## 4. Trace behaviour (ties to the circuit backend)

| Trace | Channel | Colour | When shown |
|---|---|---|---|
| **Input / wave-gen** | CH2 | secondary | **Always** — animates live with amplitude/phase/frequency, circuit-independent. |
| **Output / measured** | CH1 | yellow | **Only if** `Breadboard circuit parser.py` reports a valid circuit **and** the probe resolves to a real driven node (`v_nodes[probe]` not `NaN`). |

- Invalid/open/short circuit, or probe on a stranded hole → **no output trace**
  (input still shows) + on-screen `reason` text.
- F4/F5 (CH1 scale/position) transform only the output trace; F6/F7 only the input
  trace.

---

## 5. Model / object breakdown (for Blender)

| Object | Notes | Interactive? |
|---|---|---|
| `SCOPE_body` | Main chassis matching UQ oscilloscope proportions/colour. | No |
| `SCOPE_screen` | Flat plane, emissive, driven material — the animated display. | Driven |
| `SCOPE_graticule` | Grid overlay on the screen. | No |
| `BTN_power` | Green power button. | **Yes (F1)** |
| `PORT_funcgen` | Function-generator BNC; wave-gen cable seats here. | **Yes (F2)** |
| `PORT_ch1` | CH1 BNC; Channel-1 cable seats here. | **Yes (F3)** |
| `KNOB_ch1_scale` / `KNOB_ch1_pos` | CH1 vertical scale/position. | **Yes (F4/F5)** |
| `KNOB_ch2_scale` / `KNOB_ch2_pos` | CH2 vertical scale/position. | **Yes (F6/F7)** |
| `KNOB_horiz_scale` | Horizontal s/Div. | Optional (O1) |
| `KNOB_entry` | Entry knob. | Optional (O2) |
| `AES_*` | All aesthetic buttons/knobs/ports from §2. | No |

- Prefix interactive controls so the modal operator's raycast hit-test can filter
  them (`BTN_`, `KNOB_`, `PORT_`); aesthetic parts use `AES_`.
- Each interactive knob/button carries a custom prop naming its function
  (`fn = "CH1_SCALE"`, `"POWER"`, …) so one hit-handler routes them all.

---

## 6. Cables (real geometry, from image 3)

| Cable | From → To | Notes |
|---|---|---|
| **Wave-generator cable** | `PORT_funcgen` → carrier board | Delivers the AC source; part of the fixed pre-wired path. |
| **Channel-1 cable** | `PORT_ch1` → probe | Board/probe end **tracks the probe** as the student moves it. |

BNC-style connector ends seated in the ports as shown in image 3.

---

## 7. Interaction summary

- **Power (F1):** click → toggle on/off animation.
- **Vertical scale/position (F4–F7):** click-drag or scroll on the knob → change
  V/Div or trace offset; "Push to Zero" recentres.
- **Ports (F2/F3):** connection points for the two cables; visually seated, not
  reconfigurable by the student.
- **Everything else:** aesthetic — clickable feedback optional, but no function.

All interactive controls are hit-tested by the master modal operator's raycast (see
main sim spec §6.1–6.3); none require MCP at runtime.

---

## 8. Aesthetic completeness — model the *whole* instrument

The prototype must look like a **real lab oscilloscope**, not a stripped-down mock.
Every control visible in the reference images is modelled, even if non-functional —
a bench instrument with missing buttons reads as fake immediately.

**Model all of the following as full geometry (aesthetic, from images 1, 3, 4):**
- **Run Control** cluster: Run/Stop (lit green), Single, Default Setup, Auto Scale.
- **Horizontal** cluster: Horiz, Search, Navigate, zoom (⊙) button, nav arrows
  (◀ ■ ▶), the horizontal scale + position knobs.
- **Trigger** cluster: Trigger, Force Trigger, Level knob, Mode/Coupling.
- **Measure** cluster: Cursors, Meas, Cursors knob.
- **Tools:** Utility, Quick Action, Analyze; **Waveform:** Acquire, Display;
  **File:** Save/Recall, Print.
- **Right-hand softkey column:** Serial, Digital, Math, Ref, plus the two "Push for
  Fine / Push to Zero" knobs.
- **Vertical** cluster: full CH1 + CH2 knob stacks, Label and Help buttons, the
  channel number tiles ("1" yellow, "2" green/grey).
- **Front-panel I/O row:** power, function-gen BNC, digital connector bank, USB,
  LAN, secondary BNCs, demo/ground terminals, the fold-down handle/feet.
- **Branding & text:** Keysight/Agilent InfiniiVision logo, model number, bandwidth
  (e.g. "70 MHz" / "200 MHz"), "MegaZoom", channel labels — as legible decals.

**Fidelity requirements for aesthetic parts:**
- Correct **relative placement and grouping** (the section headers Horizontal /
  Trigger / Measure / Vertical must sit where the images show them).
- Buttons slightly proud of the fascia; knobs with grip ridges and a pointer mark;
  BNC connectors with the bayonet collar; illuminated buttons (Run/Stop, the blue
  Intensity ring) use faint emissive materials.
- Screen bezel, seams, vents, and the off-white/grey two-tone casing matched to the
  reference photos.

## 9. Wave-generator & channel wiring — realistic cables

Model the **cables as real, physically-plausible geometry**, matching a genuine lab
setup (image 3 shows the connections):

| Cable | Route | Look |
|---|---|---|
| **Wave-generator lead** | Function-gen BNC (F2) → carrier board input | BNC or banana-to-alligator lead; coaxial or twin lead with insulation colour (often red/black pair). |
| **Channel-1 probe lead** | CH1 BNC (F3) → probe body → probe tip | Scope-probe style: BNC at the scope, coax body, probe barrel, sprung tip + ground clip. Board/tip end **tracks the probe** as it moves. |

**Cable realism requirements:**
- Cables **hang and drape** with gentle catenary sag (use a curve with slight droop,
  not a taut straight line) so they read as physical.
- **Connector ends seated** properly: BNC collars clicked onto the ports, strain
  relief at the plug.
- Consistent cable **radius, insulation material** (slightly glossy PVC), and colour
  coding (e.g. yellow-ringed probe matching the CH1 yellow tile).
- The Channel-1 lead re-routes smoothly when the probe tip is placed on a new hole —
  a rigged curve (hook/parent the board-end to the probe object).

## 10. Rendering quality bar (high-fidelity)

The whole instrument must render at a **high, presentation-grade quality**:

- **Renderer:** EEVEE (real-time, for the interactive session) tuned to look close to
  Cycles; use screen-space reflections, ambient occlusion, soft shadows, and bloom
  (for the glowing screen and lit buttons). Cycles for any beauty/marketing stills.
- **Materials (PBR):** distinct, accurate materials — matte textured plastic fascia,
  glossy screen glass, brushed-metal BNC collars, rubberised knob grips, emissive
  screen and indicator LEDs. No flat single-colour placeholders.
- **Text & labels:** all panel text as crisp decals/texttures (normal or alpha
  maps), legible at the working camera distance.
- **Geometry:** bevelled edges on the chassis and knobs (no razor-sharp CG edges);
  chamfers catch light realistically. Keep poly budget sensible — bevels + normal
  maps rather than dense meshes so EEVEE stays real-time.
- **Lighting:** studio/bench three-point or HDRI so plastics and metals read
  correctly; subtle reflections on the screen glass without obscuring the trace.
- **The screen is emissive and the star:** it should visibly glow and cast a faint
  colour onto the bezel; the yellow trace blooms slightly.

## 11. Dial/knob functionality (make the functional knobs feel real)

The functional knobs (F4–F7, and O1/O2 if implemented) must **behave like real
rotary controls**, not click-toggles:

- **Rotate on interaction:** the knob mesh **visibly turns** as the student
  click-drags (or scrolls) on it, about its axis, matching the value change.
- **Continuous control:** dragging changes the value smoothly; scroll-wheel steps in
  fixed increments (e.g. 1-2-5 sequence for V/Div and s/Div, as real scopes do).
- **Push-to-Zero / Push-to-Select:** clicking (pushing) the CH knobs recentres the
  trace (position) — model a small push-in animation.
- **Live coupling to the screen:** turning F4/F6 rescales the corresponding trace's
  V/Div (and updates the on-screen V/Div readout); F5/F7 shifts the trace up/down;
  O1 rescales time (s/Div readout). The change is immediate and animated.
- **Tactile feedback cues:** a pointer notch on each knob so rotation is visible; a
  subtle highlight when hovered; optional detent "click" feel via stepped scroll.
- **Hit-testing:** each functional knob carries its `fn` custom prop
  (`"CH1_SCALE"`, `"CH1_POS"`, `"CH2_SCALE"`, `"CH2_POS"`, `"HORIZ_SCALE"`,
  `"ENTRY"`, `"POWER"`); the master modal operator raycasts the click, reads `fn`,
  and routes to the matching handler — one dispatch for all dials.
