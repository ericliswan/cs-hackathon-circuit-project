#!/bin/zsh
# Launch Blender from the Terminal so that the component list printed by the simulator is visible.
# Usage: ./launch_blender.sh            (opens breadboard_sim.blend, runs toggle_buttons.py then place_components.py)
#        ./launch_blender.sh --build    (rebuilds breadboard_sim.blend headless first, then swaps in buttons.blend's selector)
#
# Both scripts run in the SAME Blender session: toggle_buttons.py arms a button and writes
# bpy.context.scene.armed_component; place_components.py reads it on the second hole click.
# buttons.blend itself is never opened for writing — swap_selector.py only reads it.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
BLENDER="${BLENDER:-/Applications/Blender.app/Contents/MacOS/Blender}"
if [[ ! -x "$BLENDER" ]]; then
  echo "Blender not found at $BLENDER — set BLENDER=/path/to/Blender" >&2; exit 1
fi
cd "$HERE"
if [[ "$1" == "--build" || ! -f "$HERE/breadboard_sim.blend" ]]; then
  echo "[launch] building breadboard_sim.blend ..."
  "$BLENDER" -b --python "$HERE/build_scene.py" -- --out "$HERE/breadboard_sim.blend"
  echo "[launch] swapping in the selector from buttons.blend ..."
  "$BLENDER" -b "$HERE/breadboard_sim.blend" --python "$HERE/swap_selector.py"
fi
exec "$BLENDER" "$HERE/breadboard_sim.blend" \
    --python "$HERE/toggle_buttons.py" \
    --python "$HERE/place_components.py"
